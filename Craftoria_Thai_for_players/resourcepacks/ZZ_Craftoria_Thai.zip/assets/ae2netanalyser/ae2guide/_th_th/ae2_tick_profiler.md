---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:tick_analyser
    title: ME Tick Profiler
categories:
- tools
item_ids:
- ae2netanalyser:tick_analyser
---

# วัดอัตรา Tick ของ ME

<ItemImage id="ae2netanalyser:tick_analyser" scale="4"></ItemImage>

บางครั้งเกมอาจกระตุกเมื่อ ME network ใหญ่มาก แต่การหาต้นเหตุของอาการกระตุกจาก network ค่อนข้างยาก ตอนนี้คุณหาตัวการได้ง่าย ๆ ด้วย ME Tick Profiler

## อะไรทำให้เกมกระตุก

อุปกรณ์ AE บางตัวทำงานระหว่าง tick ของเกม ME Tick Profiler วัดเวลา (μs/tick) ที่อุปกรณ์เหล่านั้นใช้ทำงานให้เสร็จ และแสดงตัวเลขในโลกของเกม ช่วยให้คุณหาตัวที่ใช้เวลานานที่สุด

**ในเซิร์ฟเวอร์มัลติเพลเยอร์ คุณต้องมีสิทธิ์ OP จึงจะใช้งานได้ เพื่อป้องกันการใช้ในทางที่ผิด**

![overview](./pic/tick_rate.png)

สีบอกระดับความกระตุกของบล็อก ยิ่งแดงยิ่งกระตุกมาก

ตัวเลขบอกอัตรา tick ของบล็อกนี้ เกมจะกระตุกเมื่อ TPS (tick ต่อวินาที) ต่ำกว่า 20 กล่าวอีกอย่างคือ อัตรา tick ของเกมควรต่ำกว่า 50000 μs/tick เสมอ

โดยทั่วไป อัตรา tick ของบล็อกส่วนใหญ่ควรต่ำกว่า 100 μs/tick ไม่เช่นนั้นอาจทำให้เกมกระตุก

## ปรับแต่งการแสดงผล

คุณควบคุมการแสดงอัตรา tick ระดับต่าง ๆ ในโลกของเกมได้ใน Config GUI

![gui](./pic/gui2.png)

จุดสีเขียวหมายถึงแสดงบล็อกที่อยู่ในช่วงอัตรา tick นั้น คลิกจุดเพื่อเปิดหรือปิดการแสดงผล
