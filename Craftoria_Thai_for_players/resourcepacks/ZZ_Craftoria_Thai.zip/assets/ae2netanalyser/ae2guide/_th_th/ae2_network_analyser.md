---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:network_analyser
    title: ME Network Analyser
categories:
- tools
item_ids:
- ae2netanalyser:network_analyser
---

# วิเคราะห์ ME Network

<ItemImage id="ae2netanalyser:network_analyser" scale="4"></ItemImage>

เคยหาไม่เจอว่าอุปกรณ์ตัวไหนใน ME network ออฟไลน์ หรืออยากดูว่า network ทำงานเป็นอย่างไรไหม ME Network Analyser ช่วยได้

## ME network ของฉันเกิดอะไรขึ้น

คลิกบล็อก สายเคเบิล หรืออุปกรณ์ใดก็ได้ที่เชื่อมกับ ME network คุณจะเห็นสถานะของอุปกรณ์ทุกตัวและวิธีที่เชื่อมต่อกัน

![overview](./pic/showoff.png)

สีและรูปทรงที่ต่างกันบอกสถานะที่ต่างกัน
- ลูกบาศก์สีน้ำเงิน: อุปกรณ์ ME ปกติ มี channel เพียงพอและส่งผ่านได้ 8 channel
- ลูกบาศก์สีเหลือง: อุปกรณ์ ME แบบ Dense มี channel เพียงพอและส่งผ่านได้ 32 channel
- ลูกบาศก์สีแดง: อุปกรณ์ ME ที่ออฟไลน์ เพราะ channel ไม่พอ
- เส้นเชื่อมสีน้ำเงิน: เส้นเชื่อมนี้รองรับได้สูงสุด 8 channel
- เส้นเชื่อมสีเหลือง: เส้นเชื่อมนี้รองรับได้สูงสุด 32 channel
- เส้นเชื่อมสีชมพู: เป็นเส้นเชื่อม ME P2P
- ตัวเลข: จำนวน channel ที่เส้นเชื่อมนี้ส่งผ่าน

โปรดทราบว่าจำนวน channel สูงสุดที่แท้จริงขึ้นกับ ME Channel Mode ของคุณ Analyser จะไม่แสดงตัวเลข channel เมื่อเปิดโหมด Infinity Channel

## ปรับแต่งการแสดงผล

คุณเปลี่ยนโหมดการวิเคราะห์และสีได้ใน Config GUI

![gui](./pic/gui.png)

ME Network Analyser มี 5 โหมด
- Full: แสดงสถานะทั้งหมดของ network
- Nodes: แสดงเฉพาะสถานะของ node
- Links: แสดงเฉพาะสถานะของเส้นเชื่อม
- No Number: ไม่แสดงตัวเลข channel
- P2P: แสดงเฉพาะเส้นเชื่อม ME P2P

คุณเปลี่ยนสีของ node หรือเส้นเชื่อมได้เช่นกัน

![gui2](./pic/color.png)

