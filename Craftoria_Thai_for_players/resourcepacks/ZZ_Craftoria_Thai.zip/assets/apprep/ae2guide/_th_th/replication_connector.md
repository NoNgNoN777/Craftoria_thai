---
navigation:
    title: ME Replication Connector
    icon: replication_connector
    parent: index.md
item_ids:
    - replication_connector
---

# Applied Replicatics: ME Replication Connector

<BlockImage id="replication_connector" scale="4" />

บล็อกนี้เชื่อมเครือข่าย Replication เข้ากับเครือข่าย ME

เก็บ matter จากเครือข่าย Replication เข้าเครือข่าย ME ได้ และดึง matter จากเครือข่าย ME กลับไปยังเครือข่าย Replication ได้เช่นกัน

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/replication_connector_basic.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Autocrafting

Pattern ที่เก็บใน Chip Storage จะถูกลงทะเบียนเป็นของที่คราฟต์ได้ในเครือข่าย ME ผลลัพธ์จาก Replicator จะถูกส่งเข้าเครือข่าย ME ผ่าน ME Replication Connector

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/auto_craft.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <BlockAnnotation color="#dddddd" x="0" y="0" z="1">
    Autocrafting ใช้ matter ที่เก็บใน ME Matter Storage Cell
  </BlockAnnotation>
</GameScene>
