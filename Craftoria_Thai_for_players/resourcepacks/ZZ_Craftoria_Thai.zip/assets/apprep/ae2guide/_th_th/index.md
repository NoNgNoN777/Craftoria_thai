---
navigation:
    title: "Add-on: Applied Replicatics"
    position: 256
---

# Applied Replicatics

ส่วนเสริมที่เชื่อม Applied Energistics 2 เข้ากับ Replication

<SubPages />
