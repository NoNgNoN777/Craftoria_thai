---
navigation:
    title: ME Matter Storage Cell
    icon: matter_cell_256k
    parent: index.md
item_ids:
    - matter_cell_housing
    - matter_cell_1k
    - matter_cell_4k
    - matter_cell_16k
    - matter_cell_64k
    - matter_cell_256k
    - mega_matter_cell_housing
    - matter_cell_1m
    - matter_cell_4m
    - matter_cell_16m
    - matter_cell_64m
    - matter_cell_256m
---

# Applied Replicatics: ME Matter Storage Cell

<Row>
  <ItemImage id="matter_cell_housing" scale="4"/>
  <ItemImage id="matter_cell_1k" scale="4"/>
  <ItemImage id="matter_cell_4k" scale="4"/>
  <ItemImage id="matter_cell_16k" scale="4"/>
  <ItemImage id="matter_cell_64k" scale="4"/>
  <ItemImage id="matter_cell_256k" scale="4"/>
</Row>

[Storage Cell](ae2:items-blocks-machines/storage_cells.md) ที่เก็บ matter ของ Replication ได้

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="structures/matter_cells.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 0.3">
    ใช้ Matter Tank ที่เติมเต็มแล้วสองครั้งเพื่อให้ปรากฏ
  </BoxAnnotation>
</GameScene>


ข้อมูลจำเพาะพื้นฐานเหมือน [Storage Cell](ae2:items-blocks-machines/storage_cells.md) แต่ใช้ 1 ไบต์ต่อ matter 256 หน่วย

เนื่องจากเชื่อมกับ MEGA Cells จึงมี MEGA Storage Cell ให้ใช้ด้วย

---

## หมายเหตุ

การแลก matter กับเครือข่าย Replication ต้องใช้ <ItemLink id="replication_connector" /> โปรดทราบว่าใช้ร่วมกับบล็อกของม็อดอื่นที่ทำหน้าที่คล้ายกันไม่ได้
