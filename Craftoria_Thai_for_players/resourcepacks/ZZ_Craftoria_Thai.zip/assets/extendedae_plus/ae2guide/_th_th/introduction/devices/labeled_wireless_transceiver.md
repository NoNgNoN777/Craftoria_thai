---
navigation:
  parent: introduction/index.md
  title: Labeled Wireless Transceiver
  position: 2
  icon: extendedae_plus:labeled_wireless_transceiver
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:labeled_wireless_transceiver
---

# Labeled Wireless Transceiver

<BlockImage id="extendedae_plus:labeled_wireless_transceiver" scale="5" />

**Labeled Wireless Transceiver** ต่อยอดจากการส่ง channel ข้ามมิติของ Wireless Transceiver และเพิ่ม**เครือข่ายป้ายชื่อ (label)** คุณผูกป้ายข้อความเพื่อสร้าง channel เฉพาะอัตโนมัติ อุปกรณ์ที่ใช้ป้ายเดียวกันจึงเชื่อมกันได้โดยไม่ต้องจูนความถี่เอง

## กลไกการทำงาน

- **การแมปป้ายชื่อเป็น channel:** ใส่ป้ายเพื่อลงทะเบียนหรือดึง channel เฉพาะจากทะเบียนป้าย อุปกรณ์จะปรับความถี่ให้อัตโนมัติ
- **channel ร่วม:** อุปกรณ์หลายตัวที่ใช้ป้ายเดียวกันจะเข้า channel เดียวกัน ทำให้เชื่อมแบบหนึ่งต่อหลายหรือหลายต่อหลายได้
- **แยกตามเจ้าของ:** ป้ายจำจากผู้วาง (หรือทีม) ป้ายชื่อเดียวกันของผู้เล่น/ทีมต่างกันจะไม่เชื่อมกัน channel จึงแยกจากกัน
- **ข้ามมิติ:** เหมือน Wireless Transceiver รองรับการข้ามมิติ ต้องโหลดทั้งสองชังก์ไว้

## คู่มือการใช้งาน

### จัดการป้ายชื่อ

- **ช่องใส่/ค้นหา:** พิมพ์ป้ายทางด้านซ้ายเพื่อกรองรายการ
- **New:** คลิก **New** เพื่อลงทะเบียนป้ายที่พิมพ์และผูกอุปกรณ์นี้กับป้ายนั้น
- **Set:** เลือกป้ายในรายการแล้วคลิก **Set** เพื่อเปลี่ยนอุปกรณ์นี้ไปใช้ channel นั้น
- **Delete:** เลือกป้ายแล้วคลิก **Delete** เพื่อลบออกจากทะเบียน (ใช้ได้เฉพาะป้ายที่คุณเป็นเจ้าของหรือมีสิทธิ์)
- **Disconnect:** คลิก **Disconnect** เพื่อล้างป้ายปัจจุบันและตัดการเชื่อมไร้สาย

### แผงข้อมูล

แผงด้านขวาแสดง
- ป้ายปัจจุบันและเจ้าของ
- จำนวนอุปกรณ์ที่ออนไลน์
- การใช้ channel (ใช้ไป / สูงสุด)
