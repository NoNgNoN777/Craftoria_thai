---
navigation:
  parent: introduction/index.md
  title: "Devourer of Cosmic Silence"
  position: 7
  icon: extendedae_plus:infinity_biginteger_cell
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:infinity_biginteger_cell
---

# Devourer of Cosmic Silence

<ItemImage id="extendedae_plus:infinity_biginteger_cell" scale="4" />

**Devourer of Cosmic Silence** คือดิสก์เก็บของ ME ขั้นสุดยอด ที่รองรับชนิดไอเทมและความจุแบบไม่จำกัดจริง ๆ

## ฟีเจอร์

- **ชนิดไม่จำกัด**:  
  เก็บจำนวนชนิดไอเทมได้**ไม่มีขีดจำกัด**
- **ความจุไม่จำกัด**:  
  ความจุอิงจากชนิดข้อมูล **BigInteger** จึงไม่มีขีดจำกัดโดยปริยาย
- **ข้อจำกัดการแสดงผล**:  
  เนื่องจากข้อจำกัดอินเทอร์เฟซของ AE2 terminal ME แสดงค่าที่เก็บได้สูงสุด **9.2E (9,223,372,036,854,775,808)**  
  แต่ดิสก์ **ยังรับไอเทมต่อได้** เกินตัวเลขที่แสดงไปมาก
- **เข้ากันได้กว้าง**:  
  เก็บทรัพยากรต่าง ๆ ที่ม็อดเสริมนำเข้า AE2 ได้ (เช่น *Applied Flux*, *Applied Mekanistics* เป็นต้น) รวมถึง FE, สารเคมีของ Mekanism, มานาของ Ars Nouveau และอื่น ๆ  
  การเก็บทรัพยากรเหล่านี้ต้องติดตั้งม็อดเสริมที่เกี่ยวข้อง

## ความปลอดภัยและการกู้ข้อมูล

ดิสก์นี้มีกลไกป้องกันข้อมูลในตัว
- ใช้คำสั่ง `/eap give_infinity_disks` เพื่อรับสำเนาดิสก์ที่ตรงกับข้อมูลที่เก็บไว้ในโลกปัจจุบัน
- เป็น**มาตรการสำรอง** ให้คุณ**กู้ข้อมูลที่เก็บไว้** ได้หากดิสก์ต้นฉบับหายโดยไม่ตั้งใจ