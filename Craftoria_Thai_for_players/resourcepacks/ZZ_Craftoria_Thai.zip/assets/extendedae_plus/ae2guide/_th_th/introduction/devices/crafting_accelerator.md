---
navigation:
  parent: introduction/index.md
  title: Parallel Processing Unit
  position: 5
  icon: extendedae_plus:1024x_crafting_accelerator
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:4x_crafting_accelerator
  - extendedae_plus:16x_crafting_accelerator
  - extendedae_plus:64x_crafting_accelerator
  - extendedae_plus:256x_crafting_accelerator
  - extendedae_plus:1024x_crafting_accelerator
---

# Parallel Processing Unit

ม็อดนี้เพิ่ม **Parallel Processing Unit** ระดับสูงห้าแบบ ซึ่งเป็นการอัปเกรดแบบอัดแน่นของยูนิตต้นฉบับ ให้ความสามารถประมวลผลขนานสูงขึ้นมาก

<Row>
  <BlockImage id="extendedae_plus:4x_crafting_accelerator" scale="5" />
  <BlockImage id="extendedae_plus:16x_crafting_accelerator" scale="5" />
  <BlockImage id="extendedae_plus:64x_crafting_accelerator" scale="5" />
  <BlockImage id="extendedae_plus:256x_crafting_accelerator" scale="5" />
  <BlockImage id="extendedae_plus:1024x_crafting_accelerator" scale="5" />
</Row>

## สูตรคราฟต์

### 4x Parallel Processing Unit
<Recipe id="extendedae_plus:4x_crafting_accelerator" />

### 16x Parallel Processing Unit
<Recipe id="extendedae_plus:16x_crafting_accelerator" />

### 64x Parallel Processing Unit
<Recipe id="extendedae_plus:64x_crafting_accelerator" />

### 256x Parallel Processing Unit
<Recipe id="extendedae_plus:256x_crafting_accelerator" />

### 1024x Parallel Processing Unit
<Recipe id="extendedae_plus:1024x_crafting_accelerator" />
