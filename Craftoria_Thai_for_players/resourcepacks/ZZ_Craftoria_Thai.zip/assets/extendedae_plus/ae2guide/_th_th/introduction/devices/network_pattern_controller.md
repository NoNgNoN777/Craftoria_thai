---
navigation:
  parent: introduction/index.md
  title: Pattern Provider Status Controller
  position: 3
  icon: extendedae_plus:network_pattern_controller
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:network_pattern_controller
---

# Pattern Provider Status Controller

<BlockImage id="extendedae_plus:network_pattern_controller" scale="5" />

**Pattern Provider Status Controller** คือหน่วยควบคุมกลางที่ให้คุณจัดการโหมดการทำงานของ Pattern Provider ทั้งหมดในเครือข่ายผ่านอินเทอร์เฟซเดียว

## อินเทอร์เฟซและการใช้งาน

![Pattern Provider Status Controller Interface](../../picture/network_pattern_controller_en.png)

UI ของ controller มีตัวเลือกควบคุมดังนี้

### สลับโหมด
- **Toggle Blocking Mode:** เปิดหรือปิด "Blocking Mode" ให้ Pattern Provider ทั้งหมดพร้อมกัน
- **Toggle Advanced Blocking:** สลับ "Advanced Blocking Mode" ทั้งหมดพร้อมกัน
- **Toggle Smart Multiplication:** เปิดหรือปิดฟีเจอร์ "Smart Multiplication" ทั้งหมดพร้อมกัน

### การทำงานเป็นชุด
- **Enable All:** คลิกเดียวเปิดทั้งสามฟีเจอร์ให้ Pattern Provider ทุกตัวในเครือข่าย
- **Disable All:** คลิกเดียวปิดทั้งสามฟีเจอร์ให้ Pattern Provider ทุกตัวในเครือข่าย

## วิธีใช้
1. วาง **Pattern Provider Status Controller** ในเครือข่าย ME ของคุณ
2. คลิกขวาที่ controller เพื่อเปิดอินเทอร์เฟซตั้งค่า
3. คลิกปุ่มที่ต้องการ เพื่อปรับสถานะของ Pattern Provider ทั้งหมดพร้อมกันตามที่คุณต้องการจัดการ

> **หมายเหตุ:** controller นี้มีผลกับ Pattern Provider **ทุกตัว** ในเครือข่าย หากต้องการตั้งค่าแต่ละตัวแยกกัน ยังต้องใช้ UI ของ provider ตัวนั้น
