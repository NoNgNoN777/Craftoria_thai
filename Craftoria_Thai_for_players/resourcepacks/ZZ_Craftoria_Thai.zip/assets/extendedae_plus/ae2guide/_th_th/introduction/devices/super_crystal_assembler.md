---
navigation:
  parent: introduction/index.md
  title: Super Crystal Assembler
  position: 9
  icon: extendedae_plus:crystal_assembler_plus
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:crystal_assembler_plus
---

# Super Crystal Assembler

<BlockImage id="extendedae_plus:crystal_assembler_plus" scale="5" />

**Super Crystal Assembler** ประมวลผลสูตรของ crystal assembler ได้สูงสุด **8 การทำงานขนาน** ต่อรอบ

## การใช้งาน

- ใส่ไอเทมสูตรในช่องอินพุต 9 ช่อง และใส่ของเหลวที่ต้องใช้ในถังภายใน
- แต่ละรอบจะรันสูตรเดียวกันตั้งแต่ 1 ถึง 8 ชุดอัตโนมัติ ตามอินพุต ของเหลว และที่ว่างเอาต์พุตที่มี
- วัตถุดิบ ของเหลว และพลังงาน AE ถูกใช้ตามสัดส่วนของการทำงานขนานที่เสร็จ
- ช่องเอาต์พุตช่องเดียวรวมผลิตภัณฑ์ทั้งหมด หากใส่ไม่พอทั้งแบตช์ เครื่องจะลดจำนวนขนานให้อัตโนมัติ

## พลังงานและอัปเกรด

เครื่องมีบัฟเฟอร์ภายใน **64,000 AE** และรับ AE2 Speed Card ได้สูงสุด 4 ใบ Speed Card ลดเวลาประมวลผล ขีดจำกัดขนานยังเป็น 8 สูตรต่อรอบ

เปิด **Auto-Export** ในอินเทอร์เฟซของเครื่อง เพื่อส่งผลิตภัณฑ์ที่เสร็จแล้วไปยังคลังที่อยู่ติดกัน
