---
navigation:
  title: แนะนำ Extendedae_plus
  position: 60
---
# คู่มือ Extendedae_plus

ยินดีต้อนรับสู่ **Extendedae_plus**  
เป็นม็อดเสริมสำหรับ Applied Energistics 2 (AE2) สร้างต่อยอดจาก **ExtendedAE** พร้อมฟังก์ชันที่ดีขึ้น เน้นปรับปรุง **Pattern Provider** และประสบการณ์ผู้เล่น โดยยังเข้ากันได้กับระบบม็อดเสริม AE2 หลายตัว (เช่น AAE เป็นต้น)  
ให้พฤติกรรมการรัน Pattern ที่ยืดหยุ่นและควบคุมได้มากขึ้น พร้อม GUI ที่ใช้งานง่ายและเข้าใจได้ตรงไปตรงมากว่า

## สารบัญคู่มือ

### ฟีเจอร์
<CategoryIndex category="extendedae_plus features"></CategoryIndex>

### อุปกรณ์
<CategoryIndex category="extendedae_plus devices"></CategoryIndex>

### ไอเทม
<CategoryIndex category="extendedae_plus items"></CategoryIndex>

หากต้องการคำแนะนำด้านการพัฒนา/บิลด์อย่างละเอียด หรือแก้ปัญหา โปรดแจ้งที่นี่  
[ExtendedAE_Plus GitHub](https://github.com/GaLicn/ExtendedAE_Plus)
