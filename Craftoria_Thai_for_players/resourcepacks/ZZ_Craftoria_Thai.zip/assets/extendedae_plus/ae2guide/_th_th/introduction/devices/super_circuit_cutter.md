---
navigation:
  parent: introduction/index.md
  title: Super Circuit Cutter
  position: 10
  icon: extendedae_plus:circuit_cutter_plus
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:circuit_cutter_plus
---

# Super Circuit Cutter

<BlockImage id="extendedae_plus:circuit_cutter_plus" scale="5" />

**Super Circuit Cutter** คือ circuit cutter แบบเร่งความเร็วที่ประมวลผลสูตรของ cutter ได้สูงสุด **8 ชุด** ในแต่ละรอบ

## การใช้งาน

- ใส่วัตถุดิบของสูตรในช่องอินพุต
- แต่ละรอบจะกำหนดจำนวนขนานตั้งแต่ 1 ถึง 8 อัตโนมัติตามอินพุตและที่ว่างเอาต์พุต
- อินพุตและพลังงาน AE ถูกใช้ตามทุกการทำงานขนาน และผลลัพธ์ทั้งหมดรวมกันในช่องเอาต์พุต
- เมื่อที่ว่างเอาต์พุตจำกัด จะประมวลผลเฉพาะจำนวนสูตรที่ใส่พอ

## พลังงานและอัปเกรด

เครื่องเก็บพลังงานได้ **64,000 AE** และรองรับ AE2 Speed Card สูงสุด 4 ใบ Speed Card ลดเวลาต่อรอบ โดยไม่เปลี่ยนขีดจำกัดขนาน 8 สูตร

เปิด **Auto-Export** ในอินเทอร์เฟซของเครื่อง เพื่อส่งผลิตภัณฑ์ที่เสร็จแล้วไปยังคลังที่อยู่ติดกัน
