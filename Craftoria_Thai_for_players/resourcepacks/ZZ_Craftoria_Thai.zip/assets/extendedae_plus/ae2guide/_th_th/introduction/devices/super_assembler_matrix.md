---
navigation:
  parent: introduction/index.md
  title: Super Assembler Matrix
  position: 10
  icon: extendedae_plus:assembler_matrix_hybrid_plus
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:super_assembler_matrix_frame
  - extendedae_plus:super_assembler_matrix_wall
  - extendedae_plus:assembler_matrix_hybrid_plus
  - extendedae_plus:assembler_matrix_upload_core
---

# Super Assembler Matrix

<Row>
  <BlockImage id="extendedae_plus:super_assembler_matrix_frame" scale="4" />
  <BlockImage id="extendedae_plus:super_assembler_matrix_wall" scale="4" />
  <BlockImage id="extendedae_plus:assembler_matrix_hybrid_plus" scale="4" />
</Row>

**Super Assembler Matrix** เป็นมัลติบล็อกผู้ให้บริการคราฟต์สำหรับ AE2 เมื่อสร้างสำเร็จ ให้เชื่อมบล็อกของ matrix ที่ทำงานอยู่ตัวใดก็ได้เข้ากับเครือข่าย ME แล้วใช้ Pattern คราฟต์ที่เก็บไว้ผ่านระบบ autocrafting ปกติของ AE2

## ตัวอย่างโครงสร้าง

<GameScene zoom="5" background="transparent" interactive={true}>
  <ImportStructure src="../../structure/super_assembler_matrix.snbt"></ImportStructure>
</GameScene>

## โครงสร้างมาตรฐาน

สร้างทรงกล่องปิดสนิทขนาดตั้งแต่ **3x3x3** ถึง **9x9x9** บล็อก

- ทุกขอบด้านนอกต้องใช้ **Super Assembler Matrix Frame**
- ทุกบล็อกผิวด้านนอกที่ไม่ใช่ขอบต้องใช้ **Super Assembler Matrix Wall** หรือบล็อก ExtendedAE Assembler Matrix Glass
- ทุกตำแหน่งภายในต้องใช้ **Super Assembler Matrix Hybrid Core**
- ทุกตำแหน่งภายในต้องเติมด้วย Hybrid Core ใช้ core ของ ExtendedAE matrix ดั้งเดิมสร้างโครงสร้างนี้ไม่ได้

Hybrid Core แต่ละตัวรวมผลของ Pattern Core, Crafting Core และ Speed Core อย่างละหนึ่งตัว ให้ **72 ช่อง Pattern** **512 งานคราฟต์** และผลความเร็วเท่า **Speed Core ปกติห้าตัว** ใส่ได้เฉพาะ Pattern คราฟต์ที่ใช้กับ molecular assembler ของ AE2 ได้

<Recipe id="extendedae_plus:super_assembler_matrix_frame" />

<Recipe id="extendedae_plus:super_assembler_matrix_wall" />

## โครงสร้างขั้นสุดยอด

**Ultimate Super Assembler Matrix** เป็นโครงสร้างตายตัวขนาด **14x16x14** ผังที่ถูกต้องประกอบด้วย Hybrid Core 312 ตัวและ Assembly Matrix Upload Core สี่ตัว

เมื่อสร้างสำเร็จ จะให้ **22,464 ช่อง Pattern** และงบคราฟต์แบบขนานที่แทบไม่จำกัด (`2,147,483,647`) ผังที่ถูกต้องออกแบบให้วางด้วย <ItemLink id="extendedae_plus:ultimate_super_assembler_matrix_builder" />

> ตำแหน่งว่างในผังตายตัวไม่ใช่ส่วนของโครงสร้าง วางบล็อกอื่นไว้ได้โดยไม่กีดขวางการสร้าง Ultimate Matrix
