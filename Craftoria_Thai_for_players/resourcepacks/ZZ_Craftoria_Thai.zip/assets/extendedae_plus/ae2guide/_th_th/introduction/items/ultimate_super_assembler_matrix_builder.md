---
navigation:
  parent: introduction/index.md
  title: Ultimate Super Assembler Matrix Builder
  position: 13
  icon: extendedae_plus:ultimate_super_assembler_matrix_builder
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:ultimate_super_assembler_matrix_builder
---

# Ultimate Super Assembler Matrix Builder

<ItemImage id="extendedae_plus:ultimate_super_assembler_matrix_builder" scale="4" />

**Ultimate Super Assembler Matrix Builder** วางและสร้างโครงสร้าง Ultimate Super Assembler Matrix แบบตายตัวให้สำเร็จทันที เมื่อเลือกจุดเริ่มแล้วจะมีตัวอย่างล็อกไว้ให้ดู กด **Ctrl** ค้างขณะดูตัวอย่างเพื่อแสดงชิ้นส่วนโครงสร้างทีละส่วน

## ขั้นตอนการสร้าง

1. คลิกขวาที่ด้านหนึ่งของบล็อก เพื่อเลือกบล็อกว่างที่อยู่ติดกันเป็นจุดเริ่มสร้าง
2. ตรวจตัวอย่าง ย่อตัวแล้วคลิกขวาที่บล็อกอื่นเพื่อเปลี่ยนจุดเริ่มที่เลือก
3. คลิกขวาที่บล็อกอีกครั้งเพื่อสร้างที่จุดเริ่มที่เลือก
4. ย่อตัวแล้วคลิกขวากลางอากาศ เพื่อยกเลิกจุดเริ่มที่เลือกโดยไม่สร้าง

Builder จะตรวจทุกตำแหน่งบล็อกที่ต้องใช้ก่อนวางอะไร จะไม่เขียนทับบล็อกที่มีอยู่ และถ้าวางไม่สำเร็จ โลกจะไม่เปลี่ยนแปลง

## การใช้ในโหมด Creative และ Survival

ในโหมด Creative จะวางโครงสร้างโดยไม่ใช้วัสดุ

ในโหมด Survival ให้ย่อตัวแล้วคลิกขวาที่ **ME Interface** ก่อน เพื่อผูกกับเครือข่าย ME ของมัน ก่อนสร้าง เครื่องมือจะจำลองต้นทุนวัสดุทั้งหมดในเครือข่ายนั้น หากมีวัสดุครบ จะดึงออกและวางโครงสร้างทั้งชุด หากไม่ครบ แชตจะแสดงทุกไอเทมที่ขาดและจำนวน โดยไม่ใช้วัสดุใดเลย

<Recipe id="extendedae_plus:ultimate_super_assembler_matrix_builder" />

> เครื่องมือเก็บจุดเริ่มที่เลือกและ ME Interface ที่ผูกไว้ในตัวมันเอง หากจะวางต่อจากที่ค้างอยู่ ให้ใช้ไอเทม builder ชิ้นเดิม

