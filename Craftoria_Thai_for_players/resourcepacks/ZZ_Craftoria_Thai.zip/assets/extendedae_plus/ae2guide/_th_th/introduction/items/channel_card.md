---
navigation:
  parent: introduction/index.md
  title: Channel Card
  position: 2
  icon: extendedae_plus:channel_card
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:channel_card
---

# Channel Card

<ItemImage id="extendedae_plus:channel_card" scale="4" />

**Channel Card** คือการ์ดอัปเกรดที่รวมฟังก์ชันฝั่ง slave ของ <ItemLink id="extendedae_plus:wireless_transceiver" /> ไว้ในรูปแบบกะทัดรัด  
เมื่อติดตั้งในอุปกรณ์ AE ที่เข้ากันได้ จะเชื่อมกับ master ของ wireless transceiver ที่ความถี่เดียวกันได้โดยตรง ไม่ต้องใช้สาย

## ฟังก์ชันและการใช้งาน

### ฟีเจอร์พื้นฐาน
- **การเชื่อมต่อไร้สาย**:  
  อุปกรณ์ AE ที่ติดตั้ง Channel Card จะค้นหาและเชื่อมกับ **master ของ wireless transceiver** ที่ทำงานใน**ความถี่เดียวกัน**อัตโนมัติ เพื่อเข้าถึง channel ของเครือข่าย ME ของมัน
- **ปรับความถี่**:
  - **คลิกขวาขณะถือการ์ด**: **เพิ่ม**ความถี่
  - **Shift + คลิกขวา**: **ลด**ความถี่

### ผูกความเป็นเจ้าของ (v1.4.4+)
- **วิธีผูก**:  
  ถือ Channel Card แล้ว **Shift + คลิกซ้าย** (โดยไม่เล็งบล็อก) เพื่อผูกกับ**ทีม**หรือ **UUID ส่วนตัว**ของคุณ
- **เงื่อนไขการผูก**:  
  การ์ด**ต้องผูกก่อน** จึงจะเชื่อมกับ master ของ wireless transceiver ที่เจ้าของตรงกันได้

### อุปกรณ์ที่รองรับ
ติดตั้ง Channel Card ในอุปกรณ์ AE ต่อไปนี้ (และรุ่น ExtendedAE ของมัน) เพื่อให้เชื่อมต่อไร้สายได้ เมื่อติดตั้งแล้ว อุปกรณ์จะพยายามเชื่อมกับ master ของ wireless transceiver ที่ความถี่เดียวกันอัตโนมัติ

- <ItemLink id="ae2:interface" />
- <ItemLink id="ae2:import_bus" />
- <ItemLink id="ae2:export_bus" />
- <ItemLink id="ae2:storage_bus" />
- <ItemLink id="ae2:pattern_provider" />

## ขั้นตอนการใช้งาน

1. ตรวจให้แน่ใจว่ามี **master** ของ wireless transceiver ที่ตั้งความถี่และโหมดที่ต้องการ เชื่อมกับเครือข่าย ME ต้นทาง
2. ถือ Channel Card แล้ว **Shift + คลิกซ้าย** เพื่อผูกความเป็นเจ้าของให้เสร็จ
3. ปรับความถี่ของการ์ดด้วย **คลิกขวา** หรือ **Shift + คลิกขวา**
4. ติดตั้ง Channel Card ลงในอุปกรณ์ AE เป้าหมาย (เช่น ME Interface)
5. อุปกรณ์จะเชื่อมกับ master ของ wireless transceiver ที่ความถี่เดียวกันและเจ้าของตรงกันอัตโนมัติ

> **หมายเหตุ**:  
> ทั้ง Channel Card และ master ของ wireless transceiver ต้องมี**ความถี่**และ**เจ้าของ** (v1.4.4+) ตรงกัน จึงจะเชื่อมต่อสำเร็จ