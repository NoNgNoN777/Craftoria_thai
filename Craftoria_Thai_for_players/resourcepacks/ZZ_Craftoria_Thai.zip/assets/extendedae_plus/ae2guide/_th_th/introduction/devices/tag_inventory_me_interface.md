---
navigation:
  parent: introduction/index.md
  title: Tag Inventory ME Interface
  position: 7
  icon: extendedae_plus:tag_inventory_me_interface
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:tag_inventory_me_interface
---

# Tag Inventory ME Interface

<BlockImage id="extendedae_plus:tag_inventory_me_interface" scale="5" />

**Tag Inventory ME Interface** เปิดไอเทมที่เลือกจากเครือข่าย ME เป็นคลังไอเทมให้เครื่องที่อยู่ติดกัน แทนที่จะตั้งค่าทีละช่องไอเทม จะเลือกไอเทมแบบไดนามิกด้วยนิพจน์แท็ก

## การตั้งค่า

คลิกขวาที่บล็อกเพื่อตั้งนิพจน์แท็กของ whitelist และ blacklist แล้วเลือก **Save** เพื่อใช้งาน

- `&` ต้องตรงทั้งสองเงื่อนไข
- `|` ตรงเงื่อนไขใดเงื่อนไขหนึ่งก็ได้
- `^` ตรงเพียงหนึ่งในสองเงื่อนไขพอดี
- `!` ปฏิเสธเงื่อนไขที่ตามหลัง
- `( )` จัดกลุ่มส่วนของนิพจน์
- `*` ใช้เป็นตัวแทนอักขระ (wildcard) ในชื่อแท็กได้

ตัวอย่างเช่น `c:ingots & !c:ingots/iron` เลือกแท่งโลหะที่มีแท็กทั้งหมดยกเว้นแท่งเหล็ก blacklist ใช้หลัง whitelist และตัดไอเทมที่ตรงออก หากทั้งสองนิพจน์ว่าง อินเทอร์เฟซจะไม่เปิดไอเทมใดเลย

## พฤติกรรมอัตโนมัติ

- เครื่องที่อยู่ติดกันดึงไอเทมที่ตรงจากที่เก็บ ME ได้โดยตรง
- ใส่ไอเทมเข้าเครือข่าย ME ผ่านอินเทอร์เฟซนี้ไม่ได้
- คลังที่เปิดอัปเดตแบบไดนามิกตามเนื้อหาเครือข่ายที่ตรงเงื่อนไข
- บล็อกต้องมีไฟและเชื่อมกับเครือข่าย ME ที่ทำงานอยู่ และใช้ channel หนึ่งช่อง
- ใช้ Wrench ที่เข้ากับ AE2 เพื่อถอดบล็อก โดยคงพฤติกรรม Wrench ปกติ

## สูตรคราฟต์

<Recipe id="extendedae_plus:tag_inventory_me_interface" />
