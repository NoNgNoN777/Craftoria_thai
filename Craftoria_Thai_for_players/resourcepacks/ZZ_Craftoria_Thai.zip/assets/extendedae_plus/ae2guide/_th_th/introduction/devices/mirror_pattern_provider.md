---
navigation:
  parent: introduction/index.md
  title: Mirror Pattern Provider
  position: 4
  icon: extendedae_plus:mirror_pattern_provider
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:mirror_pattern_provider
---

# Mirror Pattern Provider

<BlockImage id="extendedae_plus:mirror_pattern_provider" scale="5" />

**Mirror Pattern Provider** คือ Pattern Provider แบบอ่านอย่างเดียวที่ตาม Pattern Provider อีกตัวเป็น master โดยสะท้อน Pattern และการตั้งค่าของ master ทำให้เปิดชุด Pattern เดียวกันได้ในหลายตำแหน่ง โดยไม่ต้องคัดลอกหรือดูแลคลัง Pattern ซ้ำซ้อนเอง

## กลไกการทำงาน

- **ตาม master:** หลังผูกแล้ว mirror จะซิงค์ Pattern จาก Pattern Provider master ที่เลือกอัตโนมัติ
- **การตั้งค่าที่สะท้อน:** ลำดับความสำคัญ ชื่อที่ตั้งเอง การตั้งค่า provider และทิศทางดันบล็อก จะถูกคัดลอกจาก master เมื่อรองรับ
- **ไม่มี UI แยก:** mirror ไม่มีคลัง Pattern อิสระใน terminal คลิกขวาโดยไม่ถือไอเทมเพื่อดู master ที่ผูกอยู่
- **อ่านอย่างเดียว:** Wrench และ Memory Card แก้ mirror โดยตรงไม่ได้ ให้ตั้งค่าที่ provider master แทน
- **master ที่รองรับ:** ใช้บล็อก Pattern Provider และ part ของ Pattern Provider เป็น master ได้ ใช้ mirror เป็น master ของ mirror อีกตัวไม่ได้

## วิธีผูก

ใช้ **Mirror Pattern Binder** <ItemImage id="extendedae_plus:mirror_pattern_binding_tool" scale="1" /> ผูก mirror กับ Pattern Provider master

- **Shift + คลิกขวา** ที่ Pattern Provider master เพื่อเลือก
- **คลิกขวา** ที่ mirror ที่ยังไม่ผูก เพื่อผูกกับ master ที่เลือก
- **คลิกขวา** ที่ mirror ที่ผูกแล้ว เพื่อยกเลิกการผูก
- หลังสลับ binder เป็นโหมดผูกเป็นช่วง **Shift + คลิกขวา** สองจุดเพื่อเลือกช่วง แล้วผูก mirror ทั้งหมดในกล่องนั้นกับ master ที่เลือก
- **Shift + คลิกขวากลางอากาศ** ด้วย binder เพื่อล้าง master และช่วงที่เลือกไว้

## เคล็ดลับการใช้งาน

- แก้ Pattern และการตั้งค่าที่ **provider master** แล้ว mirror จะตามอัตโนมัติ
- โหลดชังก์ของ master ไว้ หาก master ใช้ไม่ได้ mirror จะลองซ้ำและกลับมาซิงค์เมื่อหา master เจออีกครั้ง
- หาก master ถูกลบขณะที่โหลดอยู่ mirror จะล้างการผูกและ Pattern ที่สะท้อน
- การทุบ mirror ไม่ทำให้ไอเทม Pattern ที่สะท้อนเพิ่มซ้ำ

## สูตรคราฟต์

### Mirror Pattern Provider
<Recipe id="extendedae_plus:mirror_pattern_provider" />

### Mirror Pattern Binder
<Recipe id="extendedae_plus:mirror_pattern_binding_tool" />
