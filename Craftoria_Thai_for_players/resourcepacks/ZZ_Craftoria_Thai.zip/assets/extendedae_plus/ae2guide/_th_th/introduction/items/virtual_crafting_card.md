---
navigation:
  parent: introduction/index.md
  title: Virtual Crafting Card
  position: 3
  icon: extendedae_plus:virtual_crafting_card
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:virtual_crafting_card
---

# Virtual Crafting Card

<Row>
  <ItemImage id="extendedae_plus:virtual_crafting_card" scale="4" />
</Row>

Virtual Crafting Card คืออัปเกรดเฉพาะทางสำหรับ Pattern Provider ที่ทำ "การส่งขั้นสุดท้าย" ให้เสร็จทันที สำหรับงานที่ผลผลิตไม่ต้องส่งกลับเข้าที่เก็บ

## ฟีเจอร์และผล

- **เสร็จอัตโนมัติ**: ทำเครื่องหมายงานว่าเสร็จทันที เมื่อ provider กำลังจะส่งแบตช์สุดท้าย และสูตรไม่ต้องส่งผลผลิตกลับเครือข่าย ME
- **ปล่อยคิว**: คืนหน่วยความจำคราฟต์ทันทีโดยไม่ต้องรอผลผลิตส่งกลับ เพื่อให้จัดคิวงานถัดไปได้
- **จำกัดหนึ่งใบ**: ติดตั้งได้เพียง 1 ใบต่อ Pattern Provider (รวมรุ่น extended)

## สถานการณ์การใช้งาน

| สถานการณ์ | ผล |
| :--- | :--- |
| การสร้างมัลติบล็อก | วัสดุถูกทำเครื่องหมายว่าส่งแล้วอัตโนมัติเมื่อส่งไปยังตำแหน่งเป้าหมาย ไม่ต้องรอยืนยันการส่งกลับ |
| ช่วยคราฟต์ด้วยมือ | วัสดุที่ทำอัตโนมัติไม่ได้ (เช่น Nether Star หนังสือเอนชานต์ ฯลฯ) ถูกส่งไปที่หีบใกล้โต๊ะคราฟต์ และงานเสร็จอัตโนมัติหลังคุณหยิบเอง |
| วางบล็อกจำนวนมาก | ส่งบล็อกก่อสร้างจำนวนมากตรงไปที่ hotbar และเสร็จอัตโนมัติหลังวาง |
| เติมสายการผลิตอัตโนมัติ | เสร็จอัตโนมัติหลังเติมของสิ้นเปลือง (เช่นเชื้อเพลิงเตา ขวด XP ฯลฯ) ให้สายการผลิตอัตโนมัติ |

## อุปกรณ์ที่รองรับ

- <ItemLink id="ae2:pattern_provider" />
- <ItemLink id="ae2:pattern_provider_part" />
- <ItemLink id="extendedae_plus:ex_pattern_provider" />
- <ItemLink id="extendedae_plus:ex_pattern_provider_part" />

## สูตรคราฟต์

<RecipeFor id="extendedae_plus:virtual_crafting_card" />
