---
navigation:
  parent: introduction/index.md
  title: Super Extended Pattern Provider Expansion Card
  position: 4
  icon: extendedae_plus:extended_pattern_provider_expansion_card_plus
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:extended_pattern_provider_expansion_card_plus
---

# Super Extended Pattern Provider Expansion Card

<ItemImage id="extendedae_plus:extended_pattern_provider_expansion_card_plus" scale="4" />

**Super Extended Pattern Provider Expansion Card** คือการ์ดอัปเกรดสำหรับ Extended Pattern Provider ของ ExtendedAE การ์ดแต่ละใบที่ติดตั้งจะปลดล็อกหน้า Pattern เพิ่มหนึ่งหน้า ช่วยให้จัดระบบอัตโนมัติขนาดใหญ่ให้เป็นระเบียบใน provider ตัวเดียวได้ง่ายขึ้น

## ฟังก์ชันและผล

- **หน้า Pattern เพิ่ม:** การ์ดแต่ละใบปลดล็อกช่อง Pattern เพิ่ม **1 หน้า**
- **ความจุช่อง:** แต่ละหน้ามี **36 ช่อง Pattern**
- **ขีดจำกัดการติดตั้ง:** ติดตั้งได้สูงสุด **3 ใบ** ใน provider ที่รองรับหนึ่งตัว
- **ความจุสูงสุด:** เมื่อติดตั้งครบ 3 ใบ Extended Pattern Provider ใช้ได้รวม **4 หน้า / 144 ช่อง Pattern**

## อุปกรณ์ที่รองรับ

- Extended Pattern Provider
- Extended Pattern Provider Part

## การป้องกันการถอด

หากการถอดการ์ดขยายจะทำให้หน้าที่ปลดล็อกที่เหลือเก็บ Pattern ปัจจุบันไม่พอ จะถอดการ์ดไม่ได้ ให้ย้ายหรือเอา Pattern ออกจากหน้าที่สูงกว่าก่อน แล้วลองถอดการ์ดอีกครั้ง

> **หมายเหตุ:** การ์ดนี้ขยายเฉพาะหน้า Pattern ของ Extended Pattern Provider ของ ExtendedAE ไม่เพิ่มความจุ Pattern ของ AE2 Pattern Provider ต้นฉบับ
