---
navigation:
  parent: introduction/index.md
  title: Entity Speed Card
  position: 6
  icon: extendedae_plus:entity_speed_card
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:entity_speed_card
---

# Entity Speed Card

<Row>
  <ItemImage id="extendedae_plus:entity_speed_card" tag="{'EAS:mult':2}" scale="3" />
  <ItemImage id="extendedae_plus:entity_speed_card" tag="{'EAS:mult':4}" scale="3" />
  <ItemImage id="extendedae_plus:entity_speed_card" tag="{'EAS:mult':8}" scale="3" />
  <ItemImage id="extendedae_plus:entity_speed_card" tag="{'EAS:mult':16}" scale="3" />
</Row>

**Entity Speed Card** คือชิ้นส่วนอัปเกรดที่ใส่ลงใน <ItemLink id="extendedae_plus:entity_speed_ticker" /> เพื่อให้ระดับการเร่งความเร็วต่าง ๆ  
ระดับของการ์ดกำหนด**ขีดจำกัดตัวคูณการเร่งสูงสุด**ที่ Entity Accelerator ทำได้โดยตรง

## ระดับการ์ดและผล

Entity Accelerator ใส่ **Speed Card** ได้พร้อมกันสูงสุด **4 ใบ**  
ตัวคูณการเร่งสุดท้ายเท่ากับ**ผลคูณของตัวคูณพื้นฐานของการ์ดทุกใบที่ใส่** แต่ **ไม่เกิน** **ขีดจำกัดความเร็วสูงสุด** ที่กำหนดโดย**การ์ดระดับสูงสุด**ที่ติดตั้ง

| ชนิดการ์ด | ตัวคูณพื้นฐาน | ขีดจำกัดความเร็วสูงสุด (ต่อการ์ด) |
| :--- | :--- | :--- |
| Entity Speed Card (x2) | ×2 | ×8 |
| Entity Speed Card (x4) | ×4 | ×64 |
| Entity Speed Card (x8) | ×8 | ×256 |
| Entity Speed Card (x16) | ×16 | ×1024 |

> **กฎการใส่ปนกัน**:  
> เมื่อใส่การ์ดต่างระดับปนกัน ตัวคูณรวมคือผลคูณของตัวคูณพื้นฐานทั้งหมด แต่ผลสุดท้าย **ไม่เกิน** **ขีดจำกัดความเร็วสูงสุด** ของการ์ดระดับสูงสุดที่ติดตั้ง
>
> **ตัวอย่าง**: ใส่ **การ์ด x2** หนึ่งใบและ **การ์ด x4** สามใบ
>
> - ตัวคูณที่คำนวณได้: 2 × 4³ = 128
> - การ์ดระดับสูงสุด: **x4** ขีดจำกัด **×64**
> - **ตัวคูณการเร่งสุดท้าย = ×64**

## สูตรคราฟต์
<RecipeFor id="extendedae_plus:entity_speed_card" />
