---
navigation:
  parent: introduction/index.md
  title: Assembler Matrix Plus Cores
  position: 12
  icon: extendedae_plus:assembler_matrix_speed_plus
categories:
  - extendedae_plus items
item_ids:
  - extendedae_plus:assembler_matrix_pattern_plus
  - extendedae_plus:assembler_matrix_crafter_plus
  - extendedae_plus:assembler_matrix_speed_plus
---

# Assembler Matrix Plus Cores

<Row>
  <ItemImage id="extendedae_plus:assembler_matrix_pattern_plus" scale="3" />
  <ItemImage id="extendedae_plus:assembler_matrix_crafter_plus" scale="3" />
  <ItemImage id="extendedae_plus:assembler_matrix_speed_plus" scale="3" />
</Row>

Assembler Matrix ได้รับ **“Plus Core”** สามแบบ ซึ่งเสริมความสามารถต่อยอดจาก core ดั้งเดิม  
บทบาทเหมือน core ของ ExtendedAE Assembler Matrix ดั้งเดิม แต่ค่าสถานะสูงขึ้นมาก

- **Assembler Matrix Pattern Core+**: แต่ละ core ให้ **72 ช่อง Pattern**  
- **Assembler Matrix Craft Core+**: แต่ละ core รัน **งานคราฟต์ขนานได้ 32 งาน**  
- **Assembler Matrix Speed Core+**: ให้ matrix ได้ผล **5 เท่าของ speed core ปกติ** (ก็คือพลังเพิ่มเป็นห้าเท่า วางเพียงตัวเดียวก็พอ)  


