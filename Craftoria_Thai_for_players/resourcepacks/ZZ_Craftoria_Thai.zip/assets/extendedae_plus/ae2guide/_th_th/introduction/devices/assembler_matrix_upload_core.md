---
navigation:
  parent: introduction/index.md
  title: Assembler Matrix Upload Core
  position: 8
  icon: extendedae_plus:assembler_matrix_upload_core
categories:
  - extendedae_plus devices
item_ids:
  - extendedae_plus:assembler_matrix_upload_core
---

# Assembler Matrix Upload Core

<BlockImage id="extendedae_plus:assembler_matrix_upload_core" scale="5" />

**Assembler Matrix Upload Core** เป็นโมดูลฟังก์ชันที่ทำให้ Assembler Matrix รับและอัปโหลด Pattern จาก Pattern Encoding Terminal ได้อัตโนมัติ

## ภาพรวมฟีเจอร์

เมื่อติดตั้งใน Assembler Matrix แล้ว Pattern ที่สร้างใน Pattern Encoding Terminal ไม่ว่าจะเป็น **Pattern คราฟต์** **Pattern Smithing Table** หรือ **Pattern Stonecutter** จะถูกอัปโหลดเข้าที่เก็บของ Assembler Matrix อัตโนมัติ โดยไม่ต้องย้ายเอง

## ประวัติเวอร์ชันและการเปลี่ยนแปลงสำคัญ

- **เวอร์ชัน 1.4.3**: เพิ่มไอเทมนี้เข้าเกม
- **การเปลี่ยนแปลงสำคัญ**: ก่อน **เวอร์ชัน 1.4.3** Assembler Matrix **ไม่ต้องใช้** core นี้ในการอัปโหลด Pattern ข้างต้นอัตโนมัติ
- **ข้อกำหนดปัจจุบัน**: ตั้งแต่ **เวอร์ชัน 1.4.3** คุณต้องติดตั้ง core นี้ใน Assembler Matrix เพื่อเปิดการอัปโหลดอัตโนมัติ

> **คำเตือน:** นี่เป็นการเปลี่ยนแปลงที่ทำให้ใช้ร่วมกับของเดิมไม่ได้ เมื่ออัปเดตจากเวอร์ชันเก่าเป็น 1.4.3 ขึ้นไป คุณต้องติดตั้ง core นี้ใน Assembler Matrix ทุกตัวที่ใช้ด้วยตัวเอง เพื่อให้การอัปโหลดอัตโนมัติกลับมาใช้ได้

> **หมายเหตุ:** core นี้มีผลเฉพาะ**การอัปโหลด Pattern อัตโนมัติจาก Pattern Encoding Terminal ไปยัง Assembler Matrix** ไม่กระทบตรรกะการอัปโหลด Pattern แบบ processing ไปยัง **Pattern Provider**
