---
navigation:
  title: แนะนำ EnderDrives
  position: 60
---

# EnderDrives!

EnderDrives เน้นวิธีเก็บไอเทมอีกแบบ ไดรฟ์เหล่านี้เชื่อมกันตามความถี่ที่ตั้งไว้ในแต่ละไดรฟ์ ไดรฟ์ทั้งหมดที่มีความถี่และความเป็นส่วนตัวเดียวกันจะใช้เนื้อหาร่วมกัน ไม่ว่าใครเป็นผู้คราฟต์ ไม่ว่าจะอยู่ในระบบ AE2 ของคุณ ในมิติอื่น หรือในระบบของผู้เล่นคนอื่น เนื้อหาก็ซิงค์กันทั่วโลก

ดูรายการบล็อกและไอเทมทั้งหมดได้จากหน้าคู่มือเหล่านี้

## EnderDrives

<CategoryIndex category="enderdrives"></CategoryIndex>

## TapeDrives

<CategoryIndex category="tapedrives"></CategoryIndex>

พบปัญหา หรืออยากได้ฟีเจอร์ที่ยังไม่มี
แจ้งได้ที่นี่
[EnderDrives GitHub](https://github.com/STS15/enderdrives)