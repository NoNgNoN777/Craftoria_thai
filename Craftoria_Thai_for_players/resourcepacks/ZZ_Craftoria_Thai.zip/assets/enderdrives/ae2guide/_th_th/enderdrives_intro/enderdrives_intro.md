---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: Ender Item Storage Cell
  icon: enderdrives:ender_disk_1k
categories:
  - enderdrives
item_ids:
  - enderdrives:ender_disk_1k
  - enderdrives:ender_disk_4k
  - enderdrives:ender_disk_16k
  - enderdrives:ender_disk_64k
  - enderdrives:ender_disk_256k
  - enderdrives:ender_disk_creative
  - enderdrives:ender_fluid_disk_1k
  - enderdrives:ender_fluid_disk_4k
  - enderdrives:ender_fluid_disk_16k
  - enderdrives:ender_fluid_disk_64k
  - enderdrives:ender_fluid_disk_256k
  - enderdrives:ender_fluid_disk_creative
---

# Ender Drives

Ender Drive คือไดรฟ์ทรงพลังที่ให้เก็บของแบบซิงค์ทั่วโลกข้ามระบบ ME ข้ามมิติ และข้ามผู้เล่นได้ผ่านความถี่

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_256k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_256k" />
  </Column>
</Row>


---

## วิธีทำงาน
EnderDrive แต่ละตัวตั้งค่าด้วยความถี่ ขอบเขต และโหมด
- **ความถี่ (Frequency)**: ไดรฟ์ที่มีความถี่เดียวกันใช้คลังของร่วมกัน
- **ขอบเขต (Scope)**: กำหนดว่าใครเข้าถึงไดรฟ์ได้ (Global, Private หรือ Team)
- **โหมด (Mode)**: ควบคุมทิศทางการไหลของไอเทม (Bidirectional, Input, Output)

ไดรฟ์ทั้งหมดที่มีความถี่และขอบเขตเดียวกันจะเข้าถึง**คลังเสมือนเดียวกัน** ไม่ว่าจะวางอยู่ที่ใด

---

## ขีดจำกัดชนิด
ต่างจากไดรฟ์ AE2 ทั่วไป ขีดจำกัดของ EnderDrive อิงจากจำนวนชนิดเท่านั้น เนื่องจากวิธีเก็บไอเทมฝั่งหลังบ้าน ข้อจำกัดตายตัวมีเพียงจำนวนชนิด คุณเก็บได้มากถึง 2^63 - 1 หรือ 9,223,372,036,854,775,807 ชิ้นต่อหนึ่งชนิดจริง ๆ แต่ระวังไว้ ค่าพลังงานจะเพิ่มตามจำนวนไอเทมที่เก็บในไดรฟ์ที่ความถี่นั้น

แต่ละเซิร์ฟเวอร์เริ่มหน่วงที่จำนวนชนิดไม่เท่ากัน คุณทดสอบเซิร์ฟเวอร์ได้ด้วยคำสั่ง autobenchmark ต้องเปิด terminal ที่มีไดรฟ์โหมด Private ตามความถี่ที่เลือกไว้ จึงจะได้ผลแม่นยำ การทดสอบจะทำต่อไปจนกว่า TPS ต่ำกว่า 18 ซึ่งอาจใช้เวลาไม่กี่นาที

ค่าเฉลี่ยของผู้เขียนอยู่ที่ราว 275,000 ชนิด 275,000/255 ≈ 1078 หมายความว่าต้องใส่ 256k Ender Drive และไอเทมที่มีชนิดเต็ม ME Drive ถึง 107.8 ตัว จึงจะเริ่มเห็นปัญหาด้านประสิทธิภาพ เคยเห็นค่าสูงสุดที่แนะนำทั้งสูงและต่ำกว่านี้ ขีดจำกัดนี้ใช้ร่วมกันระหว่างทุกฝ่ายที่ใช้ไดรฟ์ในโลกเดียวกัน

---

## โหมดไดรฟ์
ไดรฟ์แต่ละตัวตั้งเป็น**โหมดถ่ายโอน**ได้หนึ่งในสามแบบ

- ![PEGui1](../pic/transport_bidirectional_alt.png) **Bidirectional** _(ค่าเริ่มต้น)_  
  ทำงานเหมือน ME Drive ปกติ ใส่และดึงไอเทมได้อิสระ


- ![PEGui1](../pic/transport_input_alt.png) **Input-Only**  
  ใส่ไอเทมได้แต่ดึงออกไม่ได้ เหมาะกับบัฟเฟอร์หรือการซิงค์อินพุต


- ![PEGui1](../pic/transport_output_alt.png) **Output-Only**  
  ดึงไอเทมได้แต่ใส่ไม่ได้ เหมาะกับบัฟเฟอร์เอาต์พุตหรือการเข้าถึงแบบอ่านอย่างเดียว

---

## ขอบเขตและความเป็นส่วนตัว

ไดรฟ์แต่ละตัวมี**ขอบเขต (scope)** ซึ่งควบคุมว่าใครเข้าถึงคลังได้
-  **Global** _(ค่าเริ่มต้น)_  
   สาธารณะ ผู้เล่นคนใดก็ตามที่ใช้ความถี่เดียวกันเข้าถึงคลังร่วมนี้ได้


-  **Private**  
  ผูกกับ UUID ของคุณ มีแต่คุณที่สร้างไดรฟ์เพื่อเข้าถึงความถี่นี้ได้ ผู้ใช้ระบบ ME ของคุณคนอื่นยังเข้าถึงที่เก็บนี้ได้


-  **Team**  
  แชร์กับ FTB Team ของคุณ สมาชิกทุกคนสร้างไดรฟ์ที่เข้าถึงความถี่เดียวกันได้

