---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: นำเข้า ส่งออก และ Storage
---

# นำเข้า ส่งออก และ Storage

**ระบบ ME ของคุณกับโลก**

แนวคิดสำคัญใน AE2 คือ Network Storage เป็นที่เก็บเนื้อหาของเครือข่าย ซึ่งมักเป็น [storage cell](../items-blocks-machines/storage_cells.md) หรือช่องเก็บของใดก็ตามที่ <ItemLink id="storage_bus" /> เชื่อมอยู่ [อุปกรณ์](../ae2-mechanics/devices.md) ส่วนใหญ่ของ AE2 ทำงานกับมันไม่ทางใดก็ทางหนึ่ง

ตัวอย่างเช่น

*   <ItemLink id="import_bus" /> ดันของเข้า network storage
*   <ItemLink id="export_bus" /> ดึงของออกจาก network storage
*   <ItemLink id="interface" /> ทั้งดึงจากและดันเข้า network storage
*   [Terminal](../items-blocks-machines/terminals.md) ทั้งดันเข้าและดึงจาก network storage เมื่อคุณใส่หรือหยิบไอเทม หรือเติมช่องคราฟต์ใหม่
*   <ItemLink id="storage_bus" /> จริง ๆ แล้วไม่ได้ดันเข้าหรือดึงจาก storage แต่ดันเข้าหรือดึงจากช่องเก็บของที่เชื่อมอยู่
    เพื่อใช้เป็น network storage (ดังนั้นอุปกรณ์อื่นต่างหากที่ดันเข้าหรือดึงจาก *มัน*)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        Import Bus นำของจากช่องเก็บของที่มันหันไปหาเข้าสู่ network storage
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        การใส่ของจากช่องเก็บของของคุณเข้า terminal ถือเป็นการที่เครือข่ายนำเข้าของนั้น
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        Interface จะนำเข้าจากช่องเก็บของภายในของมัน ถ้าช่องนั้นไม่ได้ตั้งให้สต็อกอะไร หรือมีไอเทมในช่องนั้นมากกว่าที่ตั้งให้สต็อก
        จึงดันของเข้าไปเพื่อนำเข้าเครือข่ายได้
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        Pattern Provider จะนำเข้าจากช่องรับผลลัพธ์ภายในของมัน จึงดันของเข้าไปเพื่อนำเข้าเครือข่ายได้
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        Drive ให้ cell ที่ใส่ไว้เป็น network storage
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        Storage Bus ใช้ช่องเก็บของที่มันหันไปหาเป็น network storage
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        Export Bus ส่งของจาก network storage ออกไปยังช่องเก็บของที่มันหันไปหา
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        การหยิบของออกจาก terminal ถือเป็นการที่เครือข่ายส่งออกของนั้น
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        Interface จะส่งออกไปยังช่องเก็บของภายในของมัน ถ้าช่องนั้นตั้งให้สต็อกอะไรไว้
        จึงดึงของจากมันเพื่อนำออกจากเครือข่ายได้
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

การดันเข้าและดึงจาก network storage เป็นสิ่งที่ควรคำนึงถึงเมื่อออกแบบระบบอัตโนมัติและโลจิสติกส์

## Storage Priority

ตั้ง priority ได้โดยคลิกประแจที่มุมขวาบนของ GUI บางตัว ไอเทมที่เข้าสู่เครือข่ายจะเริ่มที่ storage ที่มี priority สูงสุดเป็นปลายทางแรก ถ้า storage สองตัวมี priority เท่ากัน และตัวหนึ่งมีไอเทมนั้นอยู่แล้ว จะเลือก storage ตัวนั้นก่อนตัวอื่น cell ที่เป็น Whitelist ทุกตัวจะถือว่ามีไอเทมนั้นอยู่แล้วเมื่ออยู่ในกลุ่ม priority เดียวกับ storage อื่น ส่วนไอเทมที่ถูกนำออกจาก storage จะถูกนำออกจาก storage ที่ priority ต่ำสุด ระบบ priority นี้ทำให้เมื่อใส่และนำไอเทมเข้าออก network storage แล้ว storage ที่ priority สูงกว่าจะเต็มขึ้น และที่ priority ต่ำกว่าจะว่างลง
