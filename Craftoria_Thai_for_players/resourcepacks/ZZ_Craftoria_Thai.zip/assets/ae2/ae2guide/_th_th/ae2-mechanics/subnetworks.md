---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Subnetworks
---

# Subnetworks

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
        Subnet ท่อไอเทม
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
        Subnet ท่อของเหลว
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
        Annihilation Plane แบบมีตัวกรอง
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
        Subnet ของ Formation Plane
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
        Subnet ที่ใช้การทำงานร่วมกันของ Interface กับ Storage Bus เป็นที่เก็บของย่อยในพื้นที่ ซึ่งเครือข่ายหลัก
เข้าถึงได้
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
        Subnet ท่อไอเทมอีกชุด เพื่อส่งไอเทมที่ชาร์จแล้วกลับไปที่ Pattern Provider
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

"Subnetwork" เป็นคำที่นิยามค่อนข้างหลวม แต่อาจพูดได้ว่า Subnetwork คือ[เครือข่าย](../ae2-mechanics/me-network-connections.md)ใด ๆ ที่เสริมเครือข่ายหลัก หรือทำงานเล็ก ๆ อย่างใดอย่างหนึ่ง
โดยทั่วไปมีขนาดเล็กพอจนไม่ต้องใช้ Controller การใช้งานหลัก 2 อย่างคือ:

* จำกัดว่า[อุปกรณ์](../ae2-mechanics/devices.md)ใดเข้าถึงที่เก็บของใดได้ (คุณไม่อยากให้ Import Bus บน Subnet แบบ "ท่อ" เข้าถึงที่เก็บของเครือข่ายหลัก
    ไม่เช่นนั้นมันจะใส่ไอเทมลง Storage Cell แทนที่จะใส่ในช่องเก็บของปลายทาง)
* ประหยัด Channel บนเครือข่ายหลัก เช่น ให้ Pattern Provider ส่งออกไปที่ Interface ที่ต่อกับ Storage
    Bus หลายตัวบนเครื่องหลายเครื่อง โดยใช้ 1 Channel แทนการวาง Pattern Provider ไว้ที่เครื่องแต่ละเครื่อง ซึ่งใช้หลาย Channel

สิ่งสำคัญมากในการสร้าง Subnet คือต้องตรวจ[การเชื่อมต่อของเครือข่าย](../ae2-mechanics/me-network-connections.md)ให้ดี
บ่อยครั้งผู้เล่นต่อ Interface กับ Bus ปนกันมั่วไปหมด แล้วคาดว่าเป็น Subnet ทั้งที่
อุปกรณ์ทุกตัวยังเชื่อมกับเครือข่ายหลักผ่านอุปกรณ์แบบบล็อกเต็มต่าง ๆ

สายคนละสีไม่เกี่ยวกับการสร้าง Subnetwork เลย นอกจากทำให้สายไม่เชื่อมต่อกัน

ตัวอย่างบางส่วน:

* ระบบที่มาแทน Trash Can/Void Upgrade ด้วยเครือข่าย AE2 ทั้งชุดที่ตัดสินใจว่าจะใช้ขยะของคุณอย่างไรให้คุ้มที่สุด ส่งไอเทมอย่างชาญฉลาด
  ไปยังชุด Composter หรือเครื่องรีไซเคิลของม็อดบางตัว ตามที่มีและตามความต้องการ
* สร้างนามธรรม จัดการรายละเอียดทั้งหมดของงานคราฟต์ซับซ้อนจาก Subnetwork ของคุณ เพื่อให้จากมุมมอง
  ของเครือข่ายหลัก โรงงานทั้งหมด "ดูเหมือน" เครื่องเดียว
* การทำงานคู่ขนาน เปลี่ยนเครื่องที่ช้าเป็นเครื่องช้าตัวเดิม 10 เครื่อง จากมุมมองของเครือข่ายหลัก
  ไม่มีอะไรเปลี่ยน และคุณยังไม่ต้องใช้ Channel เพิ่มด้วย
* Import Bus กับ Storage Bus ที่ตั้งให้ย้ายไอเทมหรือของเหลวจากตู้หนึ่งไปอีกตู้หนึ่ง เหมือนท่อไอเทมหรือท่อของเหลว
* Annihilation Plane กับ Storage Bus เพื่อให้ที่เดียวที่ Annihilation Plane ใส่ของที่ทุบได้คือ Storage Bus ทำให้คุณกรองสิ่งที่ Plane เก็บได้
* Interface กับ Formation Plane เพื่อให้ทุกอย่างที่ใส่เข้า Interface ถูกส่งไป Formation Plane แล้ววาง/ดรอปในโลก
* ระบบสร้าง Certus Quartz อัตโนมัติ ที่ควบคุมและกำกับด้วย <ItemLink id="level_emitter" /> บนเครือข่ายหลัก
* ระบบเก็บของเฉพาะทางที่เครือข่ายหลักเข้าถึงได้ผ่านการทำงานพิเศษแบบ Storage Bus บน Interface เพื่อเก็บผลผลิตของฟาร์มโดยไม่ล้นที่เก็บของหลักไม่หยุด
* และอื่น ๆ

สิ่งที่มีประโยชน์มากในการสร้าง Subnetwork คือ <ItemLink id="quartz_fiber" /> ส่งพลังงานระหว่างเครือข่ายโดย
ไม่ต้องเชื่อมต่อกัน ทำให้จ่ายไฟให้ Subnet ได้โดยไม่ต้องวางตัวรับพลังงานและสายไฟไปทุกที่
