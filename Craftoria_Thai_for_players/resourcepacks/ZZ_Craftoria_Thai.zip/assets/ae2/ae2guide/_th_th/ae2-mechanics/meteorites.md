---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Meteorites
  icon: sky_stone_block
---

# Meteorites

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Meteorite คือจุดเริ่มต้นของการใช้ AE2 ให้วัสดุสำคัญ คือ [budding certus block](../items-blocks-machines/budding_certus.md) หลายชนิด และ <ItemLink id="mysterious_cube" /> ที่ใจกลาง

[เริ่มต้นใช้งาน](../getting-started.md) บอกว่าควรทำอะไรต่อเมื่อคุณเจอมัน

## การหา Meteorite

Meteorite พบได้ค่อนข้างบ่อยและทิ้งหลุมขนาดใหญ่ไว้บนพื้น คุณอาจเจอมาบ้างแล้ว ถ้ายังไม่เจอ
<ItemLink id="meteorite_compass" /> จะชี้ไปทาง mysterious cube ที่ใกล้ที่สุด

![Meteorite Crater](../assets/assemblies/meteorite-crater.png)