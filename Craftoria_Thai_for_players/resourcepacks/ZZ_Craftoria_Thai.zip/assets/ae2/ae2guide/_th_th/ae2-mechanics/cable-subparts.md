---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: ชิ้นส่วนสายเคเบิล
icon: fluix_glass_cable
---

# ชิ้นส่วนสายเคเบิล

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ใน AE2 [อุปกรณ์](devices.md) และชิ้นส่วนบางอย่างวางบนสายเคเบิลในบล็อกเดียวกันได้ ซึ่งมีประโยชน์กับการจัดวางแบบกะทัดรัด กด Shift คลิกขวาด้วย <ItemLink id="certus_quartz_wrench" /> หรือ <ItemLink id="network_tool" /> เพื่อถอด subpart ชิ้นเดียว (หรือตัวสายเคเบิล) ออก โดยไม่ทำลายทุกอย่างในบล็อกนั้น
