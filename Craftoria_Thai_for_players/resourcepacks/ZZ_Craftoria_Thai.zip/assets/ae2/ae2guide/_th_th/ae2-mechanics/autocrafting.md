---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Autocrafting
  icon: pattern_provider
---

# Autocrafting

### ตัวหลักของระบบ

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Autocrafting เป็นหนึ่งในฟังก์ชันหลักของ AE2 แทนที่จะต้องคราฟต์ส่วนผสมย่อยแต่ละอย่างในจำนวนที่ถูกต้องด้วยมือ
และเหนื่อยเหมือน*สามัญชน* คุณสั่งให้ระบบ ME ทำให้ได้ หรือคราฟต์ไอเทมแล้วส่งออกไปที่ใดที่หนึ่งอัตโนมัติ
หรือรักษาจำนวนไอเทมบางอย่างให้มีสต็อกอัตโนมัติผ่านพฤติกรรมที่ฉลาด ใช้กับของเหลวได้ด้วย และถ้าคุณมี
Addon บางตัวสำหรับวัสดุประเภทพิเศษของม็อด เช่นแก๊สของ Mekanism ก็ใช้กับวัสดุเหล่านั้นได้เช่นกัน ยอดเยี่ยมมาก

เรื่องนี้ค่อนข้างซับซ้อน เตรียมตัวให้พร้อมแล้วไปกันเลย

ระบบ Autocrafting ประกอบด้วย 3 อย่าง:
- ตัวที่ส่งคำขอคราฟต์
- Crafting CPU
- <ItemLink id="pattern_provider" />

สิ่งที่เกิดขึ้นคือ:

1.  มีบางอย่างสร้างคำขอคราฟต์ อาจเป็นคุณในเทอร์มินัลที่คลิกไอเทมที่ Autocraft ได้
    หรือ Export Bus หรือ Interface ที่มี Crafting Card ขอไอเทมอย่างใดอย่างหนึ่งที่ตั้งให้ส่งออก/เก็บสต็อก

*   (**สำคัญ:** ใช้ปุ่มที่คุณตั้งไว้สำหรับ "pick block" (ปกติคือคลิกกลางเมาส์) เพื่อขอคราฟต์ไอเทมที่คุณมีสต็อกอยู่แล้ว ซึ่งอาจชนกับม็อดจัดเรียงช่องเก็บของ)

2.  ระบบ ME คำนวณส่วนผสมที่ต้องใช้และขั้นตอนคราฟต์ก่อนหน้าเพื่อทำตามคำขอ แล้วเก็บไว้ใน Crafting CPU ที่เลือก

3.  <ItemLink id="pattern_provider" /> ที่มี[แพตเทิร์น](../items-blocks-machines/patterns.md)ที่เกี่ยวข้อง ส่งส่วนผสมที่ระบุในแพตเทิร์นไปยังช่องเก็บของที่อยู่ติดกัน
    กรณีสูตรโต๊ะคราฟต์ ("Crafting Pattern") ปลายทางคือ <ItemLink id="molecular_assembler" />
    กรณีสูตรที่ไม่ใช่การคราฟต์ ("Processing Pattern") ปลายทางคือบล็อกหรือเครื่องอื่น หรือระบบเรดสโตนที่ซับซ้อน

4.  ผลลัพธ์ของการคราฟต์ถูกส่งกลับเข้าระบบด้วยวิธีใดวิธีหนึ่ง ไม่ว่าจะเป็น Import Bus, Interface หรือส่งผลลัพธ์กลับเข้า Pattern Provider
    **สังเกตว่าต้องเกิดเหตุการณ์ "ไอเทมเข้าระบบ" คุณจะส่งผลลัพธ์เข้าหีบที่มี <ItemLink id="storage_bus" /> ผ่านท่อเฉย ๆ ไม่ได้**

5.  ถ้าการคราฟต์นั้นเป็นขั้นตอนก่อนหน้าของการคราฟต์อื่นในคำขอ ไอเทมจะถูกเก็บใน Crafting CPU นั้นแล้วนำไปใช้ในการคราฟต์นั้น

## สูตรแบบวนซ้ำ

<ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="4" />

สิ่งที่อัลกอริทึม Autocrafting จัดการ*ไม่ได้*คือสูตรแบบวนซ้ำ เช่น สูตรเพิ่มจำนวนอย่าง
"Redstone Dust 1 = Redstone Dust 2" จากการโยน Redstone ลงใน Manapool ของ Botania อีกตัวอย่างคือ Smithing Template
ใน Minecraft ปกติ อย่างไรก็ตาม มี[วิธีจัดการสูตรเหล่านี้](../example-setups/recursive-crafting-setup.md)

# Patterns

<ItemImage id="crafting_pattern" scale="4" />

สร้าง Pattern ใน <ItemLink id="pattern_encoding_terminal" /> จาก Blank Pattern

Pattern มีหลายประเภทสำหรับงานต่างกัน:

*   <ItemLink id="crafting_pattern" /> เข้ารหัสสูตรที่ทำด้วยโต๊ะคราฟต์ ใส่ตรงใน <ItemLink id="molecular_assembler" /> ได้ เพื่อให้
    คราฟต์ผลลัพธ์ทุกครั้งที่ได้รับส่วนผสม แต่การใช้หลักคือใน <ItemLink id="pattern_provider" /> ที่อยู่ข้าง Molecular Assembler
    Pattern Provider มีพฤติกรรมพิเศษในกรณีนี้ และจะส่ง Pattern ที่เกี่ยวข้องพร้อมส่วนผสมไปยัง Assembler ที่อยู่ติดกัน
    เนื่องจาก Assembler ส่งผลลัพธ์ของการคราฟต์ออกไปยังช่องเก็บของที่อยู่ติดกันเอง การวาง Assembler ไว้ที่ Pattern Provider จึงเพียงพอสำหรับทำ Crafting Pattern ให้อัตโนมัติ

***

*   <ItemLink id="smithing_table_pattern" /> คล้าย Crafting Pattern มาก แต่เข้ารหัสสูตรโต๊ะ Smithing ทำให้อัตโนมัติด้วย Pattern
    Provider และ Molecular Assembler เช่นกัน และทำงานเหมือนกันทุกประการ จริง ๆ แล้ว Crafting, Smithing และ Stonecutting Pattern ใช้
    ในระบบเดียวกันได้

***

*   <ItemLink id="stonecutting_pattern" /> คล้าย Crafting Pattern มาก แต่เข้ารหัสสูตร Stonecutter ทำให้อัตโนมัติด้วย Pattern
    Provider และ Molecular Assembler เช่นกัน และทำงานเหมือนกันทุกประการ จริง ๆ แล้ว Crafting, Smithing และ Stonecutting Pattern ใช้
    ในระบบเดียวกันได้

***

*   <ItemLink id="processing_pattern" /> คือที่มาของความยืดหยุ่นส่วนใหญ่ของ Autocrafting เป็นประเภทที่ทั่วไปที่สุด เพียง
    บอกว่า "ถ้า Pattern Provider ส่งส่วนผสมเหล่านี้ไปยังช่องเก็บของที่อยู่ติดกัน ระบบ ME จะได้รับไอเทมเหล่านี้ในสักวัน
    ไม่ช้าก็เร็ว" ใช้ Autocraft กับเครื่องของม็อดเกือบทุกเครื่อง หรือเตาและอื่น ๆ เพราะใช้
    ได้กว้างและไม่สนว่าระหว่างส่งส่วนผสมกับรับผลลัพธ์จะเกิดอะไรขึ้น คุณจึงทำเรื่องแปลก ๆ ได้ เช่น ใส่
    ส่วนผสมเข้าสายการผลิตของโรงงานซับซ้อนทั้งชุด ซึ่งคัดแยกของ รับส่วนผสมอื่นจากฟาร์มที่ผลิตไม่หยุด
    พิมพ์สคริปต์ Bee Movie ทั้งเรื่อง ระบบ ME ไม่สนตราบใดที่ได้ผลลัพธ์ตามที่ Pattern ระบุ จริง ๆ แล้ว
    ระบบไม่สนด้วยซ้ำว่าส่วนผสมสัมพันธ์กับผลลัพธ์หรือไม่ คุณบอกระบบได้ว่า "Cherry Planks 1 = Nether Star 1" แล้วให้
    ฟาร์ม Wither ฆ่า Wither เมื่อได้รับ Cherry Planks ก็ใช้งานได้

<ItemLink id="pattern_provider" /> หลายตัวที่มี Pattern เหมือนกันรองรับได้และทำงานคู่ขนานกัน นอกจากนี้ Pattern อาจระบุเช่น
Cobblestone 8 = Stone 8 แทน Cobblestone 1 = Stone 1 และ Pattern Provider จะใส่ Cobblestone 8 ก้อนเข้า
ระบบหลอมของคุณทุกครั้งที่ทำงาน แทนที่จะทีละก้อน

## รูปแบบทั่วไปที่สุดของ "Pattern"

จริง ๆ แล้วยังมี "Pattern" ที่ทั่วไปกว่า processing pattern อีก คือ <ItemLink id="level_emitter" /> ที่ใส่ crafting card ตั้งให้ส่งสัญญาณเรดสโตนเพื่อคราฟต์ของบางอย่างได้ "Pattern" แบบนี้ไม่กำหนดวัตถุดิบและไม่สนใจวัตถุดิบเลย มันบอกเพียงว่า "ถ้า level emitter นี้ส่งเรดสโตน ระบบ ME จะได้รับไอเทมนี้ในไม่ช้าก็นาน" มักใช้เปิดปิดฟาร์มไม่จำกัดที่ไม่ต้องใช้วัตถุดิบ หรือเปิดระบบที่จัดการสูตรวนซ้ำ (ซึ่ง autocrafting มาตรฐานไม่เข้าใจ) เช่น "1 cobblestone = 2 cobblestone" ถ้าคุณมีเครื่องที่ทำสำเนา cobblestone

# Crafting CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Crafting CPU จัดการคำขอหรืองานคราฟต์ โดยเก็บวัตถุดิบระหว่างทางไว้ขณะทำงานคราฟต์ที่มีหลายขั้นตอน และมีผลต่อขนาดงานที่ทำได้ รวมถึงความเร็วในการทำงานให้เสร็จในระดับหนึ่ง เป็นโครงสร้างหลายบล็อก (multiblock) ที่ต้องเป็นทรงสี่เหลี่ยมและมี crafting storage อย่างน้อย 1 ชิ้น

Crafting CPU ประกอบจาก

*   (จำเป็น) [Crafting storage](../items-blocks-machines/crafting_cpu_multiblock.md) มีให้เลือกทุกขนาด cell มาตรฐาน (1k, 4k, 16k, 64k, 256k) เก็บวัตถุดิบและ
    วัตถุดิบระหว่างทางของงานคราฟต์ ยิ่งมีขนาดใหญ่หรือมีมากชิ้น CPU ก็รับงานที่
    ใช้วัตถุดิบมากขึ้นได้
*   (ไม่บังคับ) <ItemLink id="crafting_accelerator" /> ทำให้ระบบส่งวัตถุดิบเป็นชุดจาก pattern provider ถี่ขึ้น
    เช่น pattern provider ที่ล้อมด้วย molecular assembler 6 ตัว จะส่งวัตถุดิบให้ใช้ได้ครบทั้ง 6 ตัวพร้อมกัน แทนที่จะใช้ทีละตัว
*   (ไม่บังคับ) <ItemLink id="crafting_monitor" /> แสดงงานที่ CPU กำลังทำอยู่ และย้อมสีได้ด้วย <ItemLink id="color_applicator" />
*   (ไม่บังคับ) <ItemLink id="crafting_unit" /> ใช้เติมช่องว่างให้ CPU เป็นทรงสี่เหลี่ยมเท่านั้น

Crafting CPU แต่ละตัวรับ 1 คำขอหรือ 1 งาน ถ้าต้องการสั่ง calculation processor และ smooth stone 256 ชิ้นพร้อมกัน คุณต้องมี CPU multiblock 2 ชุด

ตั้งให้รับคำขอจากผู้เล่น ระบบอัตโนมัติ (export bus และ interface) หรือทั้งสองอย่างได้

# Pattern Provider

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

<ItemLink id="pattern_provider" /> คือช่องทางหลักที่ระบบ autocrafting ใช้ติดต่อกับโลก โดยส่งวัตถุดิบ
ตาม [pattern](../items-blocks-machines/patterns.md) ไปยังช่องเก็บของที่อยู่ติดกัน และใส่ไอเทมเข้าไปเพื่อส่งต่อเข้าเครือข่ายได้ มักประหยัด
channel ได้โดยต่อท่อผลลัพธ์ของเครื่องกลับเข้า pattern provider ที่อยู่ใกล้ (มักเป็นตัวที่ส่งวัตถุดิบมา)
แทนการใช้ <ItemLink id="import_bus" /> ดึงผลลัพธ์ของเครื่องเข้าเครือข่าย

ข้อควรรู้ เนื่องจาก pattern provider ส่งวัตถุดิบตรงจาก [crafting storage](../items-blocks-machines/crafting_cpu_multiblock.md#crafting-storage) ใน crafting CPU จึงไม่เคยมีวัตถุดิบอยู่ในช่องเก็บของของมันเลย คุณจึงต่อท่อดึงออกจากมันไม่ได้ ต้องให้ provider ส่งไปยังช่องเก็บของอื่น (เช่น barrel) แล้วค่อยต่อท่อจากตรงนั้น

อีกข้อ provider ต้องส่งวัตถุดิบ "ทั้งหมด" ในครั้งเดียว ส่งครึ่งชุดไม่ได้ ซึ่งนำไปใช้ประโยชน์ได้

Pattern provider มีปฏิสัมพันธ์พิเศษกับ interface บน [subnet](../ae2-mechanics/subnetworks.md) คือถ้า interface ไม่ได้ปรับแต่ง (ไม่มีอะไรในช่องคำขอ) provider จะข้าม interface ไปเลย แล้วส่งตรงเข้า [storage](../ae2-mechanics/import-export-storage.md) ของ subnet นั้น โดยไม่เติมชุดสูตรลงใน interface และที่สำคัญคือจะไม่ส่งชุดถัดไปจนกว่า storage จะมีที่ว่าง

รองรับ pattern provider หลายตัวที่มี pattern เหมือนกัน และทำงานขนานกัน

Pattern provider จะพยายามส่งชุดวัตถุดิบวนไปทุกด้านของมัน จึงใช้เครื่องที่ต่อกันอยู่ทั้งหมดขนานกัน

## รูปแบบต่าง ๆ

Pattern Provider มี 3 รูปแบบ คือ normal, directional และ flat ซึ่งต่างกันที่ด้านที่ส่งวัตถุดิบไป ด้านที่รับไอเทม
และด้านที่ให้การเชื่อมต่อเครือข่าย

*   Normal pattern provider ส่งวัตถุดิบออกทุกด้าน รับอินพุตจากทุกด้าน และเหมือนเครื่อง AE2 ส่วนใหญ่
    คือทำหน้าที่เป็นสายเคเบิลเชื่อมต่อเครือข่ายทุกด้าน

*   Directional pattern provider ทำได้โดยใช้ <ItemLink id="certus_quartz_wrench" /> กับ normal pattern provider เพื่อเปลี่ยนทิศ จะส่งวัตถุดิบเฉพาะด้านที่เลือก รับอินพุตจากทุกด้าน และไม่ให้การเชื่อมต่อเครือข่าย
    ในด้านที่เลือก ทำให้ส่งเข้าเครื่อง AE2 ได้โดยไม่เชื่อมเครือข่ายเข้าด้วยกัน
    ถ้าคุณต้องการสร้าง subnetwork

*   Flat pattern provider เป็น [ชิ้นส่วนสายเคเบิล](../ae2-mechanics/cable-subparts.md) จึงวางหลายตัวบนสายเคเบิลเดียวกันได้ เหมาะกับการจัดวางแบบกะทัดรัด
    ทำงานคล้ายด้านที่เลือกของ directional pattern provider คือให้ pattern รับอินพุต และไม่
    ให้การเชื่อมต่อเครือข่ายบนด้านหน้าของมัน

สลับ pattern provider ระหว่างแบบ normal กับ flat ได้ในช่องคราฟต์

## การตั้งค่า

Pattern provider มีโหมดให้เลือกหลายแบบ

*   **Blocking Mode** ไม่ให้ provider ส่งวัตถุดิบชุดใหม่ ถ้ามี
    วัตถุดิบอยู่ในเครื่องแล้ว
*   **Lock Crafting** ล็อก provider ภายใต้เงื่อนไขเรดสโตนต่าง ๆ หรือจนกว่าผลลัพธ์ของ
    การคราฟต์ครั้งก่อนจะถูกใส่กลับเข้า pattern provider ตัวนั้นเอง
*   ตั้งให้ provider แสดงหรือซ่อนบน <ItemLink id="pattern_access_terminal" /> ได้

## Priority

ตั้ง priority ได้โดยคลิกประแจที่มุมขวาบนของ GUI ถ้ามี [pattern](../items-blocks-machines/patterns.md) หลายอันสำหรับไอเทมเดียวกัน จะใช้ pattern ใน provider ที่ priority สูงกว่าก่อน pattern ใน provider ที่ priority ต่ำกว่า เว้นแต่เครือข่ายไม่มีวัตถุดิบสำหรับ pattern ที่ priority สูงกว่า

# Molecular Assembler

<BlockImage id="molecular_assembler" scale="4" />

<ItemLink id="molecular_assembler" /> รับไอเทมที่ใส่เข้ามาแล้วทำงานตามที่ <ItemLink id="pattern_provider" /> ที่อยู่ติดกันกำหนด
หรือตาม <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> หรือ <ItemLink id="stonecutting_pattern" /> ที่ใส่เข้าไป
จากนั้นส่งผลลัพธ์ไปยังช่องเก็บของที่อยู่ติดกัน

การใช้งานหลักคือวางข้าง <ItemLink id="pattern_provider" /> ซึ่ง pattern provider มีพฤติกรรมพิเศษในกรณีนี้ โดยจะส่งข้อมูล pattern ที่เกี่ยวข้องไปพร้อมวัตถุดิบให้ assembler ที่อยู่ติดกัน และเนื่องจาก assembler ดีดผลลัพธ์ของการคราฟต์ออกไปยังช่องเก็บของข้างเคียงเอง (จึงเข้าช่องรับผลลัพธ์ของ pattern provider) การวาง assembler ติดกับ pattern provider ก็เพียงพอสำหรับทำ pattern คราฟต์ให้อัตโนมัติ

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>
