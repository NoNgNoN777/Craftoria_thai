---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: การเติบโตของ Certus
  icon: quartz_cluster
---

# การเติบโตของ Certus

## คัดลอกมาจากหน้าเริ่มต้นใช้งานเกือบทั้งหมด

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

ผลึก Certus Quartz จะงอกจาก [budding certus block](../items-blocks-machines/budding_certus.md) คล้าย amethyst ถ้าคุณทุบผลึกที่ยังโตไม่เต็มที่
จะดรอป <ItemLink id="certus_quartz_dust" /> 1 ชิ้น โชคไม่มีผล ถ้าทุบกลุ่มผลึกที่โตเต็มที่แล้ว จะดรอป
<ItemLink id="certus_quartz_crystal" /> 4 ชิ้น และโชคเพิ่มจำนวนนี้ได้

Budding certus block มี 4 ระดับ คือ Flawless, Flawed, Chipped และ Damaged และคุณจะพบมันครั้งแรกใน [meteorite](../ae2-mechanics/meteorites.md)

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ทุกครั้งที่ผลึกโตขึ้นอีกขั้น budding block มีโอกาสเสื่อมลงหนึ่งระดับ จนสุดท้ายกลายเป็น certus quartz block ธรรมดา ซ่อมได้ (และสร้าง budding block ใหม่ได้) โดยโยน budding block (หรือ certus quartz block) ลงน้ำพร้อม <ItemLink id="charged_certus_quartz_crystal" /> อย่างน้อยหนึ่งชิ้น

<RecipeFor id="damaged_budding_quartz" />

Flawless budding certus block จะไม่เสื่อมและสร้าง certus ได้ไม่จำกัด แต่คราฟต์ไม่ได้ และย้ายด้วยพลั่วหรือที่ขุดไม่ได้ แม้ใช้ Silk Touch (แต่ย้ายด้วย [spatial storage](../ae2-mechanics/spatial-io.md) *ได้*)

ผลึก certus quartz โตช้ามากด้วยตัวเอง โชคดีที่ <ItemLink id="growth_accelerator" /> เร่งกระบวนการนี้ได้มหาศาลเมื่อวางติดกับ budding block คุณควรสร้างสักสองสามตัวเป็นอย่างแรก

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ปฏิสัมพันธ์ที่ซับซ้อนทำให้ทุกด้านของ budding block ที่ถูกบัง ลดอัตราการโตรวมของ budding block ซึ่งสุดท้ายจะกลบผลของ accelerator ที่เพิ่มขึ้น การทดสอบจริงให้ผลดังนี้

![Items/min for ratios](../assets/diagrams/certus_farm_speed_chart_1.png)

![common setups](../assets/diagrams/certus_farm_speed_chart_2.png)

ถ้าคุณมี quartz ไม่พอจะทำ <ItemLink id="energy_acceptor" /> หรือ <ItemLink id="vibration_chamber" /> ด้วย ให้ทำ <ItemLink id="crank" /> แล้วติดที่ปลาย accelerator ของคุณ

การเก็บเกี่ยว certus อัตโนมัติ [อธิบายไว้ที่นี่](../example-setups/simple-certus-farm.md)