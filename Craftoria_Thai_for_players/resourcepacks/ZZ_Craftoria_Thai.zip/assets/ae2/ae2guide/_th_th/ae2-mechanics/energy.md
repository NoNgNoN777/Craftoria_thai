---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Energy
  icon: energy_cell
---

# Energy

เครือข่ายของคุณต้องใช้พลังงานในการทำงาน เครือข่ายมีแหล่งพลังงานรวมที่[อุปกรณ์](../ae2-mechanics/devices.md)ดึงใช้โดยตรง และ
<ItemLink id="vibration_chamber" /> <ItemLink id="energy_acceptor" /> (และ <ItemLink id="controller" />) เป็นตัวเพิ่มเข้า คุณ
ดูสถิติพลังงานของเครือข่ายได้โดยคลิกขวาตรงจุดใดก็ได้บนเครือข่ายด้วย <ItemLink id="network_tool" /> หรือ
คลิกขวาที่ Controller ของเครือข่าย ถ้ามี การเก็บและกระจายพลังงานทั้งเครือข่ายแบบนี้ทำให้
ไม่มีขีดจำกัดอัตราการถ่ายโอนพลังงาน อุปกรณ์จึงดึงพลังงานได้สูงเท่าใดก็ได้ และ
Energy Acceptor รับพลังงานเข้าได้เร็วแทบไม่จำกัด ถูกจำกัดแค่ที่เก็บพลังงานของคุณ

## การรับพลังงาน

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
  
  <BlockImage id="crystal_resonance_generator" scale="4" />
</Row>

AE2 ไม่ได้ใช้ Forge Energy (บน Forge) หรือ TechReborn Energy (บน Fabric) ภายในโดยตรง แต่แปลงเป็น
หน่วยของตัวเองคือ AE การแปลงนี้ทำได้ทางเดียว <ItemLink id="energy_acceptor" /> และ
<ItemLink id="controller" /> แปลงพลังงานได้ แต่ด้านของ Controller ควรใช้เพิ่ม[Channel](../ae2-mechanics/channels.md)มากกว่า
นอกจากนี้ยังผลิตพลังงานได้จาก <ItemLink id="vibration_chamber" /> หรือแบบพาสซีฟด้วย <ItemLink id="crystal_resonance_generator" /> แต่ AE2 ออกแบบมา
ให้ใช้ร่วมกับม็อดสายเทคอื่นที่ผลิตพลังงานได้ดีกว่า

ทั้งหมดนี้หมายความว่า เมื่อวางโครงสร้างการกระจายพลังงานของฐาน ควรมองเครือข่าย AE2 เป็นเครื่องมัลติบล็อกขนาดใหญ่เครื่องเดียว

อัตราส่วนการแปลง Forge Energy และ Techreborn Energy คือ

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

## ที่เก็บพลังงาน

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

ด้วยเหตุผลที่ค่อนข้างชัดเจน เครือข่ายรับเข้าหรือใช้พลังงานใน 1 เกมทิกได้ไม่เกินที่เก็บได้ ถ้าเครือข่าย
เก็บได้เพียง 800 AE เมื่อ[อุปกรณ์](../ae2-mechanics/devices.md)ขอพลังงาน จะใช้ได้สูงสุด 800 AE (สมมติว่าที่เก็บเต็ม)
และ Energy Acceptor จะใส่พลังงานเข้าเครือข่ายได้สูงสุด 800 AE (สมมติว่าที่เก็บว่าง)

นี่เป็นสาเหตุทั่วไปของพฤติกรรมแปลก ๆ เช่น เมื่อสร้างเครือข่ายเล็ก ๆ ที่มีแค่ Energy Acceptor, Drive, Terminal และ
อุปกรณ์บางตัว แล้วพยายามทิ้ง Cobblestone เต็มช่องเก็บของลงเครือข่าย การใส่ Cobblestone ทั้งหมดพร้อมกันใน
1 เกมทิกต้องใช้พลังงานมากกว่าที่เครือข่ายเก็บไว้ ทำให้ใส่ Cobblestone ได้ไม่ครบ เครือข่าย
พลังงานหมด และรีบูต

**แก้ได้โดยเพิ่ม Energy Cell**

เครือข่ายมีบัฟเฟอร์พลังงานในตัว 25 AE ต่อสาย เครื่อง หรือชิ้นส่วนหนึ่งชิ้น

<ItemLink id="controller" /> มีที่เก็บพลังงานภายในเล็กน้อย 8,000 AE

<ItemLink id="energy_cell" /> เก็บได้ 200k AE และเพียงตัวเดียวก็พอสำหรับการใช้งานส่วนใหญ่ รับมือกับพลังงานที่พุ่งขึ้น
ในการใช้เครือข่ายปกติได้สบาย

<ItemLink id="dense_energy_cell" /> เก็บได้ 1.6M AE ใช้เมื่อคุณต้องการให้เครือข่ายทำงานจากพลังงานที่เก็บไว้ หรือ
รับมือกับการดึงพลังงานจำนวนมหาศาลทันทีของระบบ[Spatial Storage](spatial-io.md)ขนาดใหญ่

<ItemLink id="creative_energy_cell" /> เป็นไอเทม Creative สำหรับทดสอบ ให้พลังงานไม่จำกัด UNLIMITED POWAHHHH หรืออะไรทำนองนั้น
