---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Channels
  icon: controller
---

# Channels

[ME Network](me-network-connections.md) ของ Applied Energistics 2 ต้องใช้
Channel เพื่อรองรับ [อุปกรณ์](../ae2-mechanics/devices.md) ที่ใช้ที่เก็บของผ่านเครือข่าย หรือบริการอื่นของเครือข่าย
ลองนึกภาพ Channel เป็นสาย USB ไปยังอุปกรณ์ทุกตัว คอมพิวเตอร์มีพอร์ต USB จำกัด และรองรับ
อุปกรณ์ที่ต่ออยู่ได้จำกัด เครื่องส่วนใหญ่ อุปกรณ์แบบบล็อกเต็ม และสายมาตรฐานผ่านได้
สูงสุด 8 Channel คุณจะมองว่าอุปกรณ์แบบบล็อกเต็มและสายมาตรฐานเป็นมัดของ "สาย Channel" 8 เส้นก็ได้ ส่วน [Dense Cable](../items-blocks-machines/cables.md#dense-cable) รองรับ
ได้ถึง 32 Channel อุปกรณ์อื่นเพียงอย่างเดียวที่ส่งได้ 32 คือ <ItemLink id="me_p2p_tunnel" />
และ [Quantum Network Bridge](../items-blocks-machines/quantum_bridge.md) ทุกครั้งที่อุปกรณ์ใช้ Channel ไป ให้นึกภาพว่าดึงสาย USB ออกหนึ่งเส้นจาก
มัด ซึ่งหมายความว่าสายเส้นนั้นไม่เหลือให้อุปกรณ์ที่อยู่ถัดไปตามสาย

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
  Channel ทั้ง 8 ในสายถูกใช้หมดแล้ว Drive จึงไม่ได้รับ  
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
        Channel ทั้ง 8 ในสายถูกใช้หมดแล้ว Drive จึงไม่ได้รับ
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

วิธีง่าย ๆ ในการดูว่า Channel ถูกใช้และส่งผ่านเครือข่ายอย่างไร คือใช้[Smart Cable](../items-blocks-machines/cables.md) ซึ่งจะแสดงเส้นทางและการใช้ Channel บนสาย

Channel ใช้ 1⁄128 ae/t ต่อโหนดที่ผ่าน หมายความว่า
เมื่อเพิ่ม <ItemLink id="controller" /> ให้
เครือข่ายที่มีอุปกรณ์ 8 ชิ้นและมีมากกว่า 96 โหนด การใช้พลังงานอาจ
ลดลง เพราะการจัดสรร Channel เปลี่ยนไป

ข้อควรทราบ **CHANNEL ไม่เกี่ยวกับสีของสาย** สีของสายมีผลแค่ทำให้สายไม่เชื่อมต่อกัน

## Channel Routing

เมื่อใช้ <ItemLink id="controller" />
Channel จะส่งผ่าน 3 ขั้นตอน เริ่มจากไปตามเส้นทางสั้นที่สุด ผ่านเครื่องที่อยู่ติดกัน ไปยัง [สายปกติ](../items-blocks-machines/cables.md) ที่ใกล้ที่สุด
(Glass, Covered หรือ Smart) จากนั้นไปตามเส้นทางสั้นที่สุด ผ่านสายปกตินั้น ไปยัง [Dense Cable](../items-blocks-machines/cables.md) ที่ใกล้ที่สุด
(Dense หรือ Dense Smart) แล้วไปตามเส้นทางสั้นที่สุด ผ่าน Dense Cable นั้น ไปยัง <ItemLink id="controller" />
ถ้าเส้นทางที่สั้นที่สุดเต็มแล้ว [อุปกรณ์](devices.md) บางตัวอาจไม่ได้ Channel ที่ต้องการ ให้ใช้
สายสี Cable Anchor และ Tunnel ให้เป็นประโยชน์ เพื่อให้ Channel ไปตามเส้นทางที่คุณต้องการ

ตัวอย่างเช่น ในกรณีนี้ Drive บางตัวไม่ได้ Channel เพราะแม้สายจะมีความจุพอ
แต่ Channel พยายามไปทางเส้นทางสั้นที่สุด ทำให้สายบางเส้นล้นขณะที่เส้นอื่นว่าง

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
        มี Channel มากกว่า 8 พยายามผ่านจุดนี้ บางส่วนจึงถูกตัดออก
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

แก้ได้โดยจำกัดเส้นทางที่ Channel เดินได้ให้รัดกุมขึ้น เครือข่ายควรมีรูปร่างคล้ายต้นไม้ (หรือพุ่มไม้)
ควรลดวงวนและเส้นทาง Channel ที่กำกวมให้น้อยที่สุด

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## เครือข่าย Ad-Hoc

เครือข่ายที่ไม่มี <ItemLink id="controller" />
ถือเป็น Ad-Hoc และรองรับอุปกรณ์ที่ใช้ Channel ได้สูงสุด 8 ชิ้น
เมื่อเกิน 8 ชิ้น อุปกรณ์ที่ใช้ Channel ของเครือข่ายจะหยุดทำงาน
คุณลบอุปกรณ์ออก หรือเพิ่ม <ItemLink id="controller" /> ก็ได้

ต่างจากเครือข่ายที่มี Controller [Smart Cable](../items-blocks-machines/cables.md)บนเครือข่าย Ad-Hoc จะแสดงจำนวน
Channel ที่ใช้ทั้งเครือข่าย ไม่ใช่จำนวน Channel ที่ผ่านสายเส้นนั้น

เมื่อใช้เครือข่าย Ad-Hoc อุปกรณ์แต่ละตัวจะ
ใช้ 1 Channel ทั้งเครือข่าย ซึ่งต่างมากจากวิธีที่ <ItemLink id="controller" /> จัดสรร Channel ตาม
เส้นทางที่สั้นที่สุด

## การออกแบบ

ดังที่กล่าวไว้ใน[การส่ง Channel](channels.md#channel-routing) ควรออกแบบเครือข่ายเป็นโครงสร้างคล้ายต้นไม้ โดยให้ Dense Cable แตกออกจาก Controller สายปกติ
แตกออกจาก Dense และ[อุปกรณ์](../ae2-mechanics/devices.md)อยู่เป็นกลุ่มละไม่เกิน 8 ชิ้นบนสายปกติ

ตัวอย่างสิ่งที่ไม่ควรทำ:

ตามเส้นทาง Channel ไป

1. ทันทีที่ออกจาก Controller ไปทางขวา เกิดคอขวดที่ 8 Channel เพราะ Drive ทำงานเหมือนสายปกติ
แต่เนื่องจากตรงนี้ไม่ได้ใช้ Smart Cable เราจึงดูไม่ได้ว่าใช้ Channel ไปเท่าไร เหลือ 8 Channel
2. Drive ใช้ 1 Channel
เหลือ 7 Channel
3. 2 Channel ขึ้นไปที่ Terminal
เหลือ 5 Channel
4. ไปทางขวาต่อ Interface ใช้อีก 1 Channel
เหลือ 4 Channel
5. 1 Channel ขึ้นไปที่ Pattern Provider
เหลือ 3 Channel
6. ไปทางขวาต่อ 1 Channel ขึ้นไปที่ Import Bus
เหลือ 2 Channel
7. กลุ่ม Pattern Provider ที่ป้อนให้ Assembler ได้เพียง 2 Channel ดังนั้น Provider 2 ตัวจะไม่ได้ Channel

สุดท้ายข้อผิดพลาดอยู่ที่การทำให้ Channel เป็นคอขวด และไม่คิดให้ดีว่า Channel จะถูกกระจายอย่างไร

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 Channel
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  ไม่มี Channel
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  ไม่มี Channel
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

ตัวอย่างโครงสร้างที่ดี:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        สังเกตว่า Pattern Provider แยกเป็นกลุ่มละ 8
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        สายปกติที่เต็มไปด้วย Channel สองเส้นมาบรรจบกัน แปลว่าต้องใช้ Dense Cable
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        ใช้สายคนละสีเพื่อไม่ให้สายที่อยู่ติดกันเชื่อมต่อกัน
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## โหมด Channel

AE2 10.0.0 สำหรับ Minecraft 1.18 เพิ่มตัวเลือกใหม่สำหรับเปลี่ยนพฤติกรรม Channel ของ AE2 ในโลกของคุณ
มีตัวเลือกตั้งค่าใหม่ในส่วน general (`channels`) ที่ควบคุมตัวเลือกนี้ และมีคำสั่งใหม่ในเกม
สำหรับผู้ดูแลเพื่อเปลี่ยนโหมดและค่า config จากในเกม คำสั่งคือ `/ae2 channelmode <mode>`
เพื่อเปลี่ยน และ `/ae2 channelmode` เพื่อดูโหมดปัจจุบัน เมื่อเปลี่ยนโหมดในเกม Grid ที่มีอยู่ทั้งหมดจะ
รีบูตและใช้โหมดใหม่ทันที

ตัวเลือกนี้นำกลับมาและปรับปรุงจากตัวเลือกที่เคยมีใน Minecraft 1.12 และเพิ่มตัวเลือกที่ดีขึ้นสำหรับ
ผู้เล่นที่ต้องการเล่นสบายขึ้นอีกนิด แต่ไม่อยากให้กลไกนี้ถูกตัดทิ้งไปเลย

ตารางต่อไปนี้แสดงโหมดที่ใช้ได้ทั้งในไฟล์ config และในคำสั่ง

| ค่าตั้ง    | คำอธิบาย                                                                                                                                                                                                                                  |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | โหมดมาตรฐาน ความจุ Channel ของสายและเครือข่าย Ad-Hoc เป็นไปตามที่อธิบายไว้ทั่วเว็บไซต์นี้                                                                                                                                                   |
| `x2`       | ความจุ Channel ทั้งหมดเพิ่มเป็น 2 เท่า (16 บนสายปกติ, 64 บน Dense Cable, เครือข่าย Ad-Hoc รองรับ 16 Channel)                                                                                                                                  |
| `x3`       | ความจุ Channel ทั้งหมดเพิ่มเป็น 3 เท่า (24 บนสายปกติ, 92 บน Dense Cable, เครือข่าย Ad-Hoc รองรับ 24 Channel)                                                                                                                                  |
| `x4`       | ความจุ Channel ทั้งหมดเพิ่มเป็น 4 เท่า (32 บนสายปกติ, 128 บน Dense Cable, เครือข่าย Ad-Hoc รองรับ 32 Channel)                                                                                                                                 |
| `infinite` | ยกเลิกข้อจำกัด Channel ทั้งหมด Controller ยังช่วยลดการใช้พลังงานของ Grid ได้*อย่างมาก* Smart Cable จะสลับระหว่างปิดสนิท (ไม่มี Channel ผ่าน) กับเปิดสนิท (มี Channel ผ่าน 1 ช่องขึ้นไป) เท่านั้น |