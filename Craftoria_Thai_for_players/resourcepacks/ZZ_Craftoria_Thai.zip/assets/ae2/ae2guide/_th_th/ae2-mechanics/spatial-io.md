---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Spatial IO
  icon: spatial_storage_cell_2
---

# Spatial IO

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        ปริมาตรที่จะถูกย้าย
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

Spatial IO คือวิธีตัดแล้ววางปริมาตรพื้นที่จริงในโลกของคุณ ใช้ย้าย <ItemLink id="flawless_budding_quartz" /> ได้
มีห้องในฐานที่สลับภายในหลายแบบเพื่อใช้งานต่างวัตถุประสงค์ หรือแม้แต่ย้าย
End Portal!

ทำงานโดย*สลับ*ปริมาตรที่กำหนดกับปริมาตรขนาดเท่ากันในมิติ Spatial Storage ส่งทุกอย่างที่อยู่
ในชุด Pylon ไปยังมิติ Spatial Storage และส่งทุกอย่างในมิตินั้นมายังชุด Pylon

หมายความว่าหากคุณมีวิธีเดินทางระหว่างมิติ (Spatial IO *ใช้*สร้างเครื่องเทเลพอร์ตได้
แต่ซับซ้อนมาก ค่อนข้างเปราะบาง และเกินขอบเขตของคู่มือนี้) คุณใช้มันเหมือน Compact Machine หรือมิติกระเป๋า
ที่กำหนดขนาดเองได้

# การตั้ง Multiblock

Spatial IO ต้องจัดวางส่วนประกอบเป็นรูปแบบเฉพาะจึงจะทำงานได้ และกำหนดปริมาตรที่จะตัดแล้ววาง

ส่วนประกอบทั้งหมดต้องอยู่ใน[เครือข่าย](me-network-connections.md)เดียวกันจึงจะทำงานได้ และเครือข่ายหนึ่งมี
Spatial IO ได้เพียงชุดเดียว ดังนั้นแนะนำให้ใช้[Subnetwork](subnetworks.md)

## Spatial IO Port

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

<ItemLink id="spatial_io_port" /> ควบคุมการทำงานของ Spatial IO แสดงสถิติของ Multiblock และเก็บ
[Spatial Cell](../items-blocks-machines/spatial_cells.md)

แสดง
- [พลังงาน](energy.md)ที่เก็บอยู่และสูงสุดในเครือข่าย
- พลังงานที่ต้องใช้เพื่อทำงาน ค่านี้อาจสูงมากและใช้ทันที ดังนั้นต้องมั่นใจว่ามี
  [Energy Cell](../items-blocks-machines/energy_cells.md) พอเก็บทั้งหมด
- ประสิทธิภาพของชุด Pylon
- ขนาดของปริมาตรที่กำหนด

หากต้องการทำงาน Spatial IO ให้ใส่ Spatial Storage Cell ในช่องอินพุต แล้วส่งพัลส์เรดสโตนให้ Spatial IO Port
ระบบจะ*สลับ*ปริมาตรใน Pylon กับปริมาตรในมิติ Spatial Storage หมายความว่าถ้าคุณส่งบล็อกชุดหนึ่ง
ไปยังมิติ Spatial Storage *แล้ววางบล็อกอีกชุดใน Pylon* ใส่ Cell กลับช่องอินพุต
และสั่ง IO Port อีกครั้ง บล็อกชุดที่ 2 จะหายไปและบล็อกชุดที่ 1 จะกลับมา

**ระวัง! เอนทิตีทุกตัวในปริมาตรที่กำหนด รวมถึงตัวคุณ จะถูกพาไปด้วย และหากคุณไม่มีทางออก คุณจะติดอยู่
ในมิติ Spatial Storage ในกล่องมืดที่ไม่มีอะไรเลย** ใช้แกล้งเพื่อนได้!

## Pylon

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

<ItemLink id="spatial_pylon" /> เป็นส่วนหลักของ Spatial IO และกำหนดปริมาตรที่ได้รับผลกระทบ

ปริมาตรถูกกำหนดโดยกรอบล้อมด้านนอกของ Pylon แล้วหดเข้าด้านใน 1 บล็อกทุกทิศทาง

กฎคือ:
- ขนาดขั้นต่ำ 3x3x3 (กำหนดปริมาตร 1x1x1)
- Spatial Pylon ทั้งหมดต้องอยู่ในกรอบล้อมด้านนอก
- Spatial Pylon ทั้งหมดต้องอยู่ในเครือข่ายเดียวกัน
- Pylon ทุกตัวต้องยาวอย่างน้อย 2 บล็อก

ตัวอย่างเช่น ถ้าคุณต้องการกำหนดปริมาตร 3x3x3 ตามกฎข้อ 2 Pylon ทั้งหมดต้องอยู่ในเปลือก 5x5x5 รอบ
ปริมาตรที่คุณต้องการกำหนด จัดวางได้เกือบทุกรูปแบบ ตราบใดที่อยู่ในเปลือก 5x5x5
หนา 1 บล็อกนั้น

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        ปริมาตรที่จะถูกย้าย
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

รูปแบบที่สมเหตุสมผลกว่าคือแบบนี้:

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        ปริมาตรที่จะถูกย้าย
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## ประสิทธิภาพ

ประสิทธิภาพของชุด Pylon ขึ้นกับปริมาณเปลือกที่คุณเติมเต็ม การตั้งแบบน้อยที่สุดรอบปริมาตรใหญ่
จะไม่มีประสิทธิภาพมาก และอาจต้องใช้ AE *หลายพันล้าน*

## ขนาดของ Cell

เมื่อใช้ [Spatial Cell](../items-blocks-machines/spatial_cells.md) แล้ว จะได้ขนาด XYZ ที่กำหนดถาวร (เช่น 3x4x2)
และเชื่อมกับปริมาตรพื้นที่ในมิติ Spatial Storage **คุณรีเซ็ต ฟอร์แมต หรือปรับขนาด Spatial Cell ไม่ได้หลังจาก
ใช้แล้ว** ถ้าต้องการขนาดอื่น ให้สร้าง Cell ใหม่ 

ขนาดเหล่านี้ไม่ใช่ขนาดในชื่อของ Cell Cell 16^3 มีขนาดใดก็ได้ *ไม่เกิน* 16x16x16

สังเกตว่าปริมาตรนี้มีทิศทางและหมุนไม่ได้ ปริมาตร 2x2x3 ไม่เหมือนปริมาตร 3x2x2 แม้จะ
มีขนาดเท่ากัน

ถ้าขนาด XYZ ของ Cell ไม่ตรงกับปริมาตรที่กำหนด (ดูได้ใน IO Port) IO Port จะไม่ทำงาน