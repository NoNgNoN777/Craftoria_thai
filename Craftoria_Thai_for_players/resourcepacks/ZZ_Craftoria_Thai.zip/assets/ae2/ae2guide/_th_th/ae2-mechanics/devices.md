---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Devices
  icon: interface
---

# Devices

"Device" หมายถึงส่วนประกอบเครือข่าย AE2 ที่ทำหน้าที่บางอย่างเกี่ยวกับตัวเครือข่ายเอง เกือบทั้งหมด
ต้องใช้ Channel ยกเว้นที่เด่นคือ[Level Emitter](../items-blocks-machines/level_emitter.md)

ตัวอย่างเช่น:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
