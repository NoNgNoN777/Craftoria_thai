---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Network Connections
  icon: fluix_glass_cable
---

# Network Connections

## "Network" หมายถึงอะไร?

"Network" คือกลุ่ม[อุปกรณ์](../ae2-mechanics/devices.md)ที่เชื่อมกันด้วยบล็อกที่ส่ง[Channel](../ae2-mechanics/channels.md)ผ่านได้
เช่น[สาย](../items-blocks-machines/cables.md) หรือเครื่องแบบบล็อกเต็มและ[อุปกรณ์](../ae2-mechanics/devices.md) 
(<ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" /> ฯลฯ)
จริง ๆ แล้วสายเส้นเดียวก็ถือเป็นเครือข่ายได้ในทางเทคนิค

## เรื่องข้างเคียงเกี่ยวกับตำแหน่งอุปกรณ์

สำหรับ[อุปกรณ์](../ae2-mechanics/devices.md)ที่มีหน้าที่เฉพาะกับเครือข่าย (เช่น <ItemLink id="interface" />
ส่งเข้าและดึงออกจาก[ที่เก็บของเครือข่าย](../ae2-mechanics/import-export-storage.md), <ItemLink id="level_emitter" />
อ่านเนื้อหาของที่เก็บของเครือข่าย, <ItemLink id="drive" /> เป็นที่เก็บของเครือข่าย ฯลฯ)
ตำแหน่งจริงของอุปกรณ์ไม่สำคัญ

ย้ำอีกครั้ง **ตำแหน่งจริงของอุปกรณ์ไม่สำคัญ** สิ่งที่สำคัญคืออุปกรณ์ต้องเชื่อมกับเครือข่าย
(และแน่นอนว่าเชื่อมกับเครือข่ายไหน)

## การเชื่อมต่อของเครือข่าย

วิธีง่าย ๆ ในการดูว่าอะไรเชื่อมอยู่ในเครือข่ายคือใช้ <ItemLink id="network_tool" /> ซึ่งจะแสดงทุก
ส่วนประกอบในเครือข่าย ถ้าเห็นสิ่งที่ไม่ควรมี หรือไม่เห็นสิ่งที่ควรมี แสดงว่ามีปัญหา

ตัวอย่างนี้คือ 2 เครือข่ายแยกกัน

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        เครือข่าย 1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        เครือข่าย 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ตัวอย่างนี้ก็เป็น 2 เครือข่ายแยกกันเช่นกัน เพราะ <ItemLink id="quartz_fiber" /> แบ่งปัน[พลังงาน](../ae2-mechanics/energy.md)
โดยไม่ได้เชื่อมต่อเครือข่าย

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        เครือข่าย 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        เครือข่าย 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

แต่ตัวอย่างนี้เป็นเพียง 1 เครือข่าย ไม่ใช่ 2 เครือข่ายแยกกัน [Quantum Bridge](../items-blocks-machines/quantum_bridge.md) ทำงานเหมือน
[Dense Cable](../items-blocks-machines/cables.md#dense-cable) ไร้สาย ดังนั้นทั้งสองปลายอยู่ในเครือข่ายเดียวกัน

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        ทั้งหมดเป็น 1 เครือข่าย
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ตัวอย่างนี้ก็เป็นเพียง 1 เครือข่ายเช่นกัน เพราะสี[สาย](../items-blocks-machines/cables.md)ไม่เกี่ยวกับการเชื่อมต่อของเครือข่าย นอกจากสายคนละสีจะไม่
เชื่อมต่อกัน ทุกสีเชื่อมกับสาย Fluix (หรือ "ไม่มีสี") ได้

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        ทั้งหมดเป็น 1 เครือข่าย
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การเชื่อมต่อในบริบทของ Subnet

[Subnetwork](../ae2-mechanics/subnetworks.md) ใช้ประโยชน์จากการเชื่อมต่อของเครือข่าย (โดยเฉพาะการ**ไม่**เชื่อมต่อกัน)
เพื่อจำกัดว่า[อุปกรณ์](../ae2-mechanics/devices.md)ใดเข้าถึงอุปกรณ์อื่นใดได้

จริง ๆ แล้ว Subnet ก็คือเครือข่ายที่แยกออกมาเท่านั้น

ตัวอย่างเช่น [Automatic Ore Fortuner](../example-setups/ore-fortuner.md) มี 3 เครือข่ายแยกกัน
ซึ่งแต่ละเครือข่ายมีหน้าที่เฉพาะในระบบนี้

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        เครือข่าย 1 ทำงานเหมือน Subnet ท่อ จำกัดสิ่งที่ Import Bus เข้าถึงได้ เพื่อให้ "เก็บ" บล็อกแร่ผ่าน
        Formation Plane
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        เครือข่าย 2 ทำงานเหมือน Subnet ท่ออีกชุด จำกัดสิ่งที่ Annihilation Plane เข้าถึงได้ เพื่อให้เก็บ
        ก้อนแร่ที่ได้ Fortune ลงในถัง ไม่ใช่ในเครือข่ายหลักของคุณ และยังไม่ใช้ Channel ใด ๆ ของ
        เครือข่ายหลักด้วย
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        เครือข่าย 3 คือเครือข่ายหลักที่มีที่เก็บของและระบบคราฟต์ทั้งหมดของคุณ อยู่ตรงนี้เพื่อจ่ายไฟเป็นหลัก และโดยเฉพาะ
        *ไม่ได้* เชื่อมกับ 2 Subnet
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การเชื่อมต่อในบริบทของ P2P

[P2P Tunnel](../items-blocks-machines/p2p_tunnels.md) รุ่นหนึ่งเคลื่อนย้าย[Channel](channels.md) แทนไอเทม ของเหลว
หรือสัญญาณเรดสโตน และด้วยเหตุผลบางอย่างทำให้คนสับสน เครือข่ายที่ Tunnel ติดตั้งอยู่ไม่เกี่ยวกับ
เครือข่ายที่ Tunnel ส่งผ่านเลย สองเครือข่ายนี้เป็นเครือข่ายเดียวกัน*ได้* แต่ไม่จำเป็นต้องเป็น และโดยมากไม่ใช่

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        เครือข่าย 1 คือเครือข่ายที่ถูกส่งผ่าน (โดยมากคือเครือข่ายหลักของคุณ)
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        เครือข่าย 2 คือเครือข่ายที่ใช้ ME P2P Tunnel (โดยมาก*ไม่ใช่*เครือข่ายหลักของคุณ)
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        เครือข่าย 1 คือเครือข่ายที่ถูกส่งผ่าน (โดยมากคือเครือข่ายหลักของคุณ)
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การเชื่อมต่อที่ไม่ตรงสัญชาตญาณ

ในกรณีนี้เป็นเพียง 1 เครือข่าย เพราะ <ItemLink id="pattern_provider" /> ซึ่งเป็นอุปกรณ์แบบบล็อกเต็ม ทำงานเหมือน
สาย และ <ItemLink id="inscriber" /> ก็ทำนองเดียวกัน ดังนั้นการเชื่อมต่อของเครือข่ายจึงผ่าน
Provider และ Inscriber ไปได้

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        ทั้งหมดเป็น 1 เครือข่าย
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

เพื่อป้องกันเรื่องนี้ (มีประโยชน์กับระบบคราฟต์อัตโนมัติจำนวนมากที่ใช้[Subnetwork](../ae2-mechanics/subnetworks.md))
ให้คลิกขวาที่ Provider ด้วย <ItemLink id="certus_quartz_wrench" /> เพื่อทำให้มีทิศทาง ซึ่งจะ
ไม่ส่ง Channel ผ่านด้านใดด้านหนึ่ง

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        เครือข่าย 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        เครือข่าย 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        สังเกตว่าสายไม่เชื่อมต่อ
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

ชิ้นส่วนอื่นที่ไม่ให้การเชื่อมต่อเครือข่ายแบบมีทิศทาง คือ[ชิ้นส่วนย่อย](../ae2-mechanics/cable-subparts.md)
ประเภท[อุปกรณ์](../ae2-mechanics/devices.md)ส่วนใหญ่ เช่น <ItemLink id="import_bus" /> <ItemLink id="storage_bus" /> และ
<ItemLink id="cable_interface" />

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>