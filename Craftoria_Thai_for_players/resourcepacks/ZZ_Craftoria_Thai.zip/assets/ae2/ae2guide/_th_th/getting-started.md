---
navigation:
  title: เริ่มต้นใช้งาน (1.20+)
  position: 10
---

<div class="notification is-info">
  ข้อมูลต่อไปนี้ใช้กับ Applied Energistics 2 ใน Minecraft 1.20 ขึ้นไปเท่านั้น
</div>

# เริ่มต้นใช้งาน

## การเตรียมวัสดุเริ่มต้น

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

หากจะเริ่มเล่น Applied Energistics 2 คุณต้องหา [meteorite](ae2-mechanics/meteorites.md) ให้พบก่อน พบได้ค่อนข้างบ่อยและมักทิ้งหลุมขนาดใหญ่ไว้บนภูมิประเทศ คุณจึงน่าจะเคยเจอสักก้อนระหว่างเดินทาง
หากยังไม่เคยเจอ คุณคราฟต์ <ItemLink id="meteorite_compass" /> ซึ่งจะชี้ไปทาง <ItemLink id="mysterious_cube" /> ที่ใกล้ที่สุดได้

เมื่อพบ meteorite แล้ว ให้ขุดเข้าไปที่ศูนย์กลาง คุณจะพบ certus quartz cluster, certus quartz bud, [budding certus block](items-blocks-machines/budding_certus.md) หลายชนิด และ Mysterious Cube อยู่ตรงกลาง

ขุด certus quartz cluster และ certus quartz block ทุกอันที่พบ คุณเก็บ budding certus block ได้ด้วย แต่หากไม่มี Silk Touch มันจะเสื่อมลง 1 ระดับ

ห้ามทุบ Flawless Budding Certus เพราะแม้มี Silk Touch ก็จะเสื่อมเป็น Flawed Budding Certus และซ่อมกลับเป็น Flawless ไม่ได้

ขุด Mysterious Cube ตรงกลาง meteorite ด้วย เพื่อรับ Inscriber Press ทั้ง 4 ชนิด

## การปลูก Certus Quartz

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Certus quartz bud จะงอกจาก [budding certus block](items-blocks-machines/budding_certus.md) คล้ายอะเมทิสต์ หากคุณทุบ bud ที่ยังโตไม่เต็ม
จะดรอป <ItemLink id="certus_quartz_dust" /> 1 ชิ้น โดย Fortune ไม่มีผล หากทุบ cluster ที่โตเต็มที่แล้ว จะดรอป
<ItemLink id="certus_quartz_crystal" /> 4 ชิ้น และ Fortune จะเพิ่มจำนวนนี้

Budding certus block มี 4 ระดับ คือ Flawless, Flawed, Chipped และ Damaged

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

ทุกครั้งที่ bud โตขึ้นอีกหนึ่งระยะ budding block มีโอกาสเสื่อมลง 1 ระดับ จนในที่สุดกลายเป็น
certus quartz block ธรรมดา ซ่อมได้ (และสร้าง budding block ใหม่ได้) โดยโยน budding block (หรือ
certus quartz block) ลงน้ำพร้อม <ItemLink id="charged_certus_quartz_crystal" /> ตั้งแต่หนึ่งชิ้นขึ้นไป

<RecipeFor id="damaged_budding_quartz" />

Flawless budding certus block จะไม่เสื่อมและสร้าง certus ได้ไม่สิ้นสุด แต่คราฟต์หรือย้ายด้วย
พิคแอกซ์ไม่ได้ แม้มี Silk Touch (แต่ย้ายด้วย [spatial storage](ae2-mechanics/spatial-io.md) *ได้*)

เมื่ออยู่เฉย ๆ certus quartz bud จะโตช้ามาก โชคดีที่ <ItemLink id="growth_accelerator" /> เร่งกระบวนการนี้
ได้อย่างมหาศาลเมื่อวางติดกับ budding block คุณควรสร้างสักสองสามตัวเป็นอันดับแรก

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

หากคุณมี quartz ไม่พอที่จะสร้าง <ItemLink id="energy_acceptor" /> หรือ <ItemLink id="vibration_chamber" /> ด้วย
คุณทำ <ItemLink id="crank" /> แล้วติดไว้ที่ปลายของ accelerator ได้

การเก็บเกี่ยว certus แบบอัตโนมัติ[อธิบายไว้ที่นี่](example-setups/simple-certus-farm.md)

## เรื่องของ Fluix โดยสังเขป

วัสดุอีกอย่างที่คุณต้องใช้คือ Fluix ซึ่งคุณเคยเจอแล้วตอนทำ growth accelerator ทำได้โดยโยน charged certus เรดสโตน และ nether quartz ลงน้ำ ส่วนการทำแบบอัตโนมัติ "ปล่อยให้เป็นแบบฝึกหัดของผู้อ่าน"

ต้องใช้ <ItemLink id="charger" /> เพื่อผลิต <ItemLink id="charged_certus_quartz_crystal" /> หากคุณยังไม่ได้ทำ

## การสลัก Processor

ระหว่างที่คุณเก็บของจาก meteorite คุณจะได้ "press" ทั้งสี่ชนิดจากการทุบ Mysterious Cube ใช้ใน <ItemLink id="inscriber" /> เพื่อทำ processor ทั้งสามชนิด

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

Inscriber เป็นเครื่องจักรที่แยกตามด้าน เหมือนเตาหลอมของ Vanilla การใส่จากด้านบนหรือด้านล่างจะวางไอเทมในช่องบนหรือช่องล่าง และการใส่จากด้านข้างหรือด้านหลังจะเข้าช่องตรงกลาง ดึงผลลัพธ์ออกได้จากด้านข้างหรือด้านหลัง

เพื่อให้ทำออโต้ด้วย Hopper ได้สะดวก (และอาจลดความยุ่งเหยิงของท่อ) หมุน Inscriber ได้ด้วย <ItemLink id="certus_quartz_wrench" />

ผลิต processor แต่ละชนิดสักสองสามชิ้นเตรียมไว้สำหรับขั้นตอนถัดไป คือการสร้างระบบ ME พื้นฐานมาก การทำออโต้การผลิต processor นั้น "[ปล่อยให้เป็นแบบฝึกหัดของผู้อ่าน](example-setups/processor-automation.md)"

## เทคโนโลยี Matter Energy: เครือข่ายและ Storage ของ ME

### ME Storage คืออะไร

อ่านว่า เอ็ม-อี และย่อมาจาก Matter Energy

Matter Energy คือหัวใจหลักของ Applied Energistics 2 เป็นเหมือนหีบหลายบล็อกในแบบนักวิทยาศาสตร์บ้า
และเปลี่ยนวิธีจัดการที่เก็บของของคุณได้อย่างสิ้นเชิง ME ต่างจากระบบเก็บของอื่นใน Minecraft มาก
อาจต้องคิดนอกกรอบสักหน่อยจึงจะคุ้น แต่เมื่อเริ่มแล้ว พื้นที่เก็บของมหาศาลในที่เล็กนิดเดียว
และ terminal ที่เข้าถึงได้หลายจุด เป็นเพียงยอดภูเขาน้ำแข็งของสิ่งที่ทำได้

### ต้องรู้อะไรบ้างก่อนเริ่ม

อย่างแรก ME เก็บไอเทมไว้ข้างในไอเทมอีกชิ้น เรียกว่า [Storage cell](items-blocks-machines/storage_cells.md) มี 5 ระดับ ความจุเพิ่มขึ้นเรื่อย ๆ
การจะใช้ Storage Cell ได้ ต้องวางไว้ใน <ItemLink id="chest" />
หรือ <ItemLink id="drive" />

<ItemLink id="chest" /> แสดงเนื้อหาของ Cell ทันทีที่วางลงไป และ
คุณเพิ่มหรือนำไอเทมออกได้เหมือนใช้ <ItemLink id="minecraft:chest" /> เพียงแต่ไอเทมจริง ๆ
ถูกเก็บใน Storage cell ไม่ใช่ใน <ItemLink id="chest" /> เอง

<ItemLink id="chest" /> เหมาะกับบางสถานการณ์และมีประโยชน์จำกัด หากจะใช้ประโยชน์จาก AE2
อย่างเต็มที่ คุณต้องตั้ง [ME Network](ae2-mechanics/me-network-connections.md)

## ระบบ ME แรกของคุณ

เมื่อคุณมีวัสดุและเครื่องจักรพื้นฐานของ Applied Energistics 2 ครบแล้ว คุณสร้างระบบ ME (Matter Energy) ระบบแรกได้ ระบบนี้เป็นแบบพื้นฐานมาก ไม่มี autocrafting ไม่มี logistics มีแค่ที่เก็บของที่ใช้ง่ายและค้นหาได้

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   รายการส่วนผสมของคุณ
    * <ItemLink id="drive" /> 1 ชิ้น
    * <ItemLink id="terminal" /> หรือ <ItemLink id="crafting_terminal" /> 1 ชิ้น
    * <ItemLink id="energy_acceptor" /> 1 ชิ้น
    * [สายเคเบิล](items-blocks-machines/cables.md) สองสามเส้น เป็นแบบ glass, covered หรือ smart แต่ไม่ใช่ dense
    * [storage cell](items-blocks-machines/storage_cells.md) สองสามอัน แนะนำแบบ 4k เพื่อให้ได้ความจุและจำนวน type ที่สมดุล
    (จะมีประสิทธิภาพกว่าหาก[partition](items-blocks-machines/cell_workbench.md) ผสม 4k กับ 1k แต่เรื่องนั้นซับซ้อนเกินกว่าที่จะพูดถึงตอนนี้)
---
1.  วาง drive ลง
2.  Energy Acceptor (และ[อุปกรณ์](ae2-mechanics/devices.md) AE2 อื่นอีกหลายอย่าง) มี 2 โหมด คือแบบลูกบาศก์และแบบแบน สลับได้ในโต๊ะคราฟต์ หาก Energy Acceptor ของคุณเป็นแบบลูกบาศก์ ให้วางไว้ข้างๆ drive หากเป็นสี่เหลี่ยมแบน ให้วางสายเคเบิลบน drive แล้ววาง Acceptor บนสายนั้น
3.  ต่อพลังงานเข้า Energy Acceptor ด้วยสาย/ท่อ/conduit จากม็อดผลิตพลังงานที่คุณชอบ
4.  วางสายเคเบิลบน drive (หรือที่ระดับสายตา) แล้ววาง terminal หรือ crafting terminal ลงบนสายนั้น
5.  ใส่ storage cell ลงใน drive
6.  รับผลกำไร
7.  ลองปรับการตั้งค่าของ terminal เล่น
8.  ดื่มด่ำกับพลังและความสามารถสูงสุดของคุณ
9.  ตระหนักว่าเครือข่ายนี้ ในภาพรวมแล้ว ค่อนข้างเล็ก

### การขยายเครือข่าย

ตอนนี้คุณมีที่เก็บของพื้นฐานและเข้าถึงมันได้แล้ว นับเป็นจุดเริ่มต้นที่ดี แต่คุณคงอยากลอง
ทำออโต้การแปรรูปบางอย่าง

ตัวอย่างที่ดีคือวาง <ItemLink id="export_bus" /> ไว้ด้านบนของเตาหลอมเพื่อ
ใส่แร่ และวาง <ItemLink id="import_bus" />
ไว้ด้านล่างของเตาเพื่อดึงแร่ที่หลอมแล้วออกมา

<ItemLink id="export_bus" /> ให้คุณส่งไอเทมจากเครือข่ายเข้าไปในช่องเก็บ
ที่ติดอยู่ ส่วน <ItemLink id="import_bus" /> นำไอเทมจากช่องเก็บที่ติดอยู่เข้าสู่
เครือข่าย

### การทะลุข้อจำกัด

ถึงตอนนี้คุณน่าจะมี[อุปกรณ์](ae2-mechanics/devices.md)ราว 8 ชิ้น เมื่อถึงชิ้นที่ 9 คุณต้องเริ่ม
จัดการ [channel](ae2-mechanics/channels.md) อุปกรณ์หลายชนิดแต่ไม่ใช่ทั้งหมด ต้องใช้ channel
จึงจะทำงานได้

โดยปกติเครือข่ายรองรับ 8 channel เมื่อเกินขีดจำกัดนี้ คุณต้องเพิ่ม
<ItemLink id="controller" /> เข้าเครือข่าย ซึ่งช่วยให้ขยายเครือข่ายได้อย่างมาก
[Smart cable](items-blocks-machines/cables.md) ช่วยให้คุณเห็นว่า channel ถูกส่งผ่านเครือข่ายอย่างไร ใช้ให้มากตอนเริ่มต้นเพื่อเรียนรู้การทำงานของ channel หรือหากคุณมีเรดสโตนและ Glowstone เหลือเฟือ
