---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: คู่มือ
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# คู่มือ

<ItemImage id="guide" scale="8" />

### คู่มือที่คุณกำลังอ่านอยู่นี้ ครอบคลุมทุกเรื่องของ AE2

* เปิดแถบด้านซ้ายเพื่อดูสารบัญ
* หลายหน้ามีฉากแบบโต้ตอบ หากข้างฉากมีปุ่ม ![Plus](../assets/diagrams/plus.png)
  และ ![Minus](../assets/diagrams/minus.png) (ซูม) คุณหมุนและเลื่อนกล้องได้
  คลิกซ้ายแล้วลากเพื่อหมุน คลิกขวาแล้วลากเพื่อเลื่อน

## สูตรคราฟต์

<RecipeFor id="guide" />
