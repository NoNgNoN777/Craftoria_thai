---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Memory Card
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# Memory Card

<ItemImage id="memory_card" scale="4" />

Memory Card ใช้คัดลอกและวางการตั้งค่าระหว่าง[อุปกรณ์](../ae2-mechanics/devices.md) AE2 และเชื่อม
[P2P tunnel](p2p_tunnels.md) ยังวาง[การ์ดอัปเกรด](upgrade_cards.md)ลงในอุปกรณ์ได้ด้วย

- Shift + คลิกขวา เพื่อคัดลอกการตั้งค่าหรือสร้างความถี่เชื่อม P2P ใหม่
- คลิกขวา เพื่อวางการตั้งค่า การ์ดอัปเกรด หรือความถี่เชื่อม

## สูตรคราฟต์

<RecipeFor id="memory_card" />
