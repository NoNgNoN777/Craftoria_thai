---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Formation and Annihilation Cores
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Formation and Annihilation Cores

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

เป็นชิ้นส่วนหลักของ[อุปกรณ์](../ae2-mechanics/devices.md)นำเข้าและส่งออกของ AE2 ใช้พลังของ <ItemLink id="fluix_crystal" /> และ [logic processor](processors.md) ทำให้อุปกรณ์นำเข้าและส่งออกไอเทม บล็อก ของเหลว ฯลฯ ได้ (ไม่มีหน้าที่จริง เป็นเพียงวัตถุดิบระหว่างทางในการคราฟต์)

## สูตรคราฟต์

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
