---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crystal Resonance Generator
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# Crystal Resonance Generator

<BlockImage id="crystal_resonance_generator" scale="8" />

อุปกรณ์นี้ผลิตพลังงานให้เครือข่าย ME โดยไม่ต้องใช้เชื้อเพลิง เนื่องจากการสั่นสะเทือนของคริสตัลที่อุปกรณ์สร้างขึ้น จึงใช้ได้เพียง 1 ตัวต่อเครือข่าย การสั่นสะเทือนนี้ผ่าน <ItemLink id="quartz_fiber" /> ไปได้ด้วย

**อัตราการผลิต:** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## สูตรคราฟต์

<RecipeFor id="crystal_resonance_generator" />
