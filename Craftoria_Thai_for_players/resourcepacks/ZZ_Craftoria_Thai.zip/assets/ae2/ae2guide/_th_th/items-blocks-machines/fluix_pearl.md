---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Pearl
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Fluix Pearl

<ItemImage id="fluix_pearl" scale="4" />

Ender pearl ที่เคลือบด้วย <ItemLink id="fluix_crystal" /> ใช้ผลิต
ชิ้นส่วน AE2 หลายอย่าง

## สูตรคราฟต์

<RecipeFor id="fluix_pearl" />
