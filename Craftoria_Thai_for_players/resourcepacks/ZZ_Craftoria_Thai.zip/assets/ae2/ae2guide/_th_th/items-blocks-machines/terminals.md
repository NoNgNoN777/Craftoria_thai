---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminal
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ขณะที่ <ItemLink id="pattern_provider" />, <ItemLink id="import_bus" />, <ItemLink id="storage_bus" /> และอื่น ๆ เป็นวิธีหลักที่เครือข่าย AE2 ใช้ติดต่อกับโลกภายนอก Terminal ก็เป็นวิธีหลักที่เครือข่าย AE2 ใช้ติดต่อกับ *คุณ* มีหลายรุ่นที่หน้าที่ต่างกัน

Terminal จะรับสีของ[สายเคเบิล](cables.md)ที่ติดตั้งอยู่

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

## การวาง Terminal

เนื่องจาก terminal มักเป็น[ชิ้นส่วนย่อย](../ae2-mechanics/cable-subparts.md)ชิ้นแรกที่ผู้เล่นวาง จึงมักวางผิดและวาง terminal กลับด้าน นี่คือตัวอย่างว่าควรทำและไม่ควรทำอะไร

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

คุณยังมี terminal และ energy acceptor เหมือนเดิม แต่ตอนนี้ terminal หันถูกด้านและเชื่อมต่อกับเครือข่ายจริง ๆ และใช้พื้นที่เล็กลงด้วย

<a name="terminal-ui"></a>

# การค้นหาใน Terminal

ช่องค้นหารับ Regex ได้ ตัวอย่างเช่น พิมพ์ "gtceu:.*ore" เพื่อดูแร่ทั้งหมดจาก Gregtech ส่วนการเรียนรู้ Regex เป็นการบ้านของผู้อ่าน

# Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Terminal พื้นฐาน ให้คุณดูและเข้าถึงสิ่งที่อยู่ใน[คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md) และสั่งของจากระบบ [autocrafting](../ae2-mechanics/autocrafting.md) ของคุณ

## UI

UI ของ terminal พื้นฐานมีหลายส่วน

ส่วนตรงกลางให้เข้าถึงคลังของเครือข่าย คุณใส่ของเข้าและนำของออกได้ มีทางลัดเมาส์/คีย์หลายแบบ

*   คลิกซ้ายหยิบทั้งสแตก คลิกขวาหยิบครึ่งสแตก
*   หากไอเทมหรือของเหลวหรืออื่น ๆ [คราฟต์อัตโนมัติ](../ae2-mechanics/autocrafting.md)ได้
    ปุ่มที่คุณตั้งเป็น "pick block" (ปกติคือคลิกกลาง) จะเปิด UI ให้ระบุจำนวนที่จะคราฟต์ คุณพิมพ์สูตรอย่าง `3*64/2` ได้ด้วย
    หรือพิมพ์ `=32` เพื่อคราฟต์เฉพาะจำนวนที่ต้องใช้ให้ครบ 32 ในคลังของคุณ
*   กด shift ค้างเพื่อตรึงตำแหน่งไอเทมที่แสดง ไม่ให้จัดเรียงใหม่เมื่อจำนวนเปลี่ยนหรือมีไอเทมใหม่เข้าระบบ
*   คลิกขวาด้วย Bucket หรือภาชนะของเหลวอื่นเพื่อใส่ของเหลวลงไป คลิกซ้ายที่ของเหลวใน terminal ด้วย
    ภาชนะของเหลวที่ว่างเพื่อดึงของเหลวออก

ส่วนซ้ายมีปุ่มตั้งค่าสำหรับ

*   เรียงตามคุณสมบัติต่าง ๆ เช่น ชื่อ ม็อด และจำนวน
*   ดูของที่เก็บอยู่ ของที่คราฟต์ได้ หรือทั้งสองอย่าง
*   ดูไอเทม ของเหลว หรือทั้งสองอย่าง
*   เปลี่ยนลำดับการเรียง
*   เปิดหน้าต่างตั้งค่า terminal แบบละเอียด
*   เปลี่ยนความสูงของ UI ของ terminal

ทางขวามีช่องสำหรับ <ItemLink id="view_cell" />

มุมขวาบนของส่วนกลาง (ปุ่มค้อน) เปิด UI สถานะ [autocrafting](../ae2-mechanics/autocrafting.md) ให้คุณดูความคืบหน้าของงานคราฟต์อัตโนมัติ และสิ่งที่ [crafting CPU](crafting_cpu_multiblock.md) แต่ละตัวกำลังทำ

## สูตรคราฟต์

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# Crafting Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Crafting Terminal คล้าย terminal ปกติ มีการตั้งค่าและส่วนต่าง ๆ เหมือนกันทุกอย่าง แต่เพิ่มช่องคราฟต์ ที่เติมวัตถุดิบจาก [คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md) ใหม่ให้อัตโนมัติ ระวังเมื่อ shift คลิกที่ช่องผลลัพธ์!

ควรอัปเกรด terminal เป็น crafting terminal โดยเร็วที่สุด

## UI

Crafting terminal มี UI เหมือน terminal ปกติ แต่เพิ่มช่องคราฟต์ตรงกลาง

มีปุ่มเพิ่มอีก 2 ปุ่ม สำหรับเทของในช่องคราฟต์ ลงคลังของเครือข่าย หรือช่องเก็บของของคุณ

## สูตรคราฟต์

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# Pattern Encoding Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Pattern Encoding Terminal คล้าย terminal ปกติ มีการตั้งค่าและส่วนต่าง ๆ เหมือนกันทุกอย่าง แต่เพิ่มส่วนเข้ารหัส [pattern](patterns.md) หน้าตาคล้าย UI ของ crafting terminal แต่ช่องคราฟต์นี้ไม่ได้คราฟต์จริง

ควรมีตัวนี้เพิ่มจาก crafting terminal

## UI

Pattern encoding terminal มี UI เหมือน terminal ปกติ แต่เพิ่มส่วนเข้ารหัส [pattern](patterns.md)

ส่วนเข้ารหัส pattern มีหลายส่วน

ช่องสำหรับใส่ <ItemLink id="blank_pattern" />

ลูกศรใหญ่สำหรับเข้ารหัส pattern

ช่องสำหรับ pattern ที่เข้ารหัสแล้ว วาง pattern ที่เข้ารหัสไว้แล้วในช่องนี้เพื่อแก้ไข จากนั้นคลิกลูกศร "encode"

แท็บ 4 แท็บทางขวา สลับชนิดของ pattern ที่จะเข้ารหัสระหว่าง

*   Crafting
*   Processing
*   Smithing
*   Stonecutting

UI ตรงกลางเปลี่ยนไปตามชนิดของ pattern ที่จะเข้ารหัส

*   ในโหมด crafting
    *   คลิกซ้ายหรือลากจาก JEI/REI ใส่วัตถุดิบเพื่อสร้างสูตร คลิกขวาเพื่อเอาวัตถุดิบออก
    *   การเปิด substitution ทำให้คราฟต์ของอย่าง Stick จากไม้กระดานชนิดใดก็ได้ ควรใช้เฉพาะ
        เมื่อจำเป็นจริง ๆ
    *   Fluid substitution ให้ใช้ของเหลวที่เก็บไว้แทน Bucket ของของเหลว
    *   คุณเข้ารหัส pattern ตรงจากหน้าจอสูตรของ JEI/REI ได้เช่นกัน

*   ในโหมด processing
    * คลิกซ้ายหรือคลิกขวาใน หรือลากจาก JEI/REI ใส่วัตถุดิบ เพื่อกำหนดอินพุตและเอาต์พุตของสูตร
    * คลิกขวาด้วยภาชนะของเหลว (เช่น Bucket หรือ Fluid Tank) เพื่อตั้งของเหลวนั้นเป็นวัตถุดิบ แทนการตั้งเป็นตัวถังเอง
    * เมื่อถือสแตกอยู่ คลิกซ้ายวางทั้งสแตก คลิกขวาวางทีละชิ้น คลิกซ้ายที่สแตกวัตถุดิบที่มีอยู่เพื่อ
        เอาออกทั้งสแตก และคลิกขวาเพื่อลดทีละ 1 ปุ่มที่คุณตั้งเป็น "pick block" (ปกติคือคลิกกลาง)
        ให้คุณระบุจำนวนไอเทมหรือของเหลวที่แม่นยำได้
    * ช่องเอาต์พุตมีเอาต์พุตหลัก และที่ว่างสำหรับเอาต์พุตรองที่คุณอยากให้อัลกอริทึม autocrafting รู้
    * ทั้งช่องอินพุตและเอาต์พุตเลื่อนได้ จึงมีวัตถุดิบได้ 81 ชนิดและเอาต์พุตรอง 26 ชนิด
    * คุณเข้ารหัส pattern ตรงจากหน้าจอสูตรของ JEI/REI ได้เช่นกัน

*   UI โหมด smithing และ stonecutting ทำงานคล้ายโต๊ะ Smithing และ Stonecutter ตามลำดับ

## สูตรคราฟต์

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# Pattern Access Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Pattern Access Terminal ช่วยแก้ปัญหาเฉพาะอย่างหนึ่ง คือในหอที่แน่นไปด้วย <ItemLink id="pattern_provider" /> และ <ItemLink id="molecular_assembler" /> คุณเข้าถึง provider เพื่อใส่ pattern ใหม่ด้วยตัวเองไม่ได้ อีกทั้งบางทีคุณอาจขี้เกียจเดินข้ามฐานไปใส่ [pattern](patterns.md) Pattern access terminal เข้าถึง pattern provider ทั้งหมดในเครือข่ายได้

## UI

Terminal นี้มี UI ต่างจาก terminal อื่นทั้งหมด

มีการตั้งค่าความสูงของ terminal และ pattern provider ที่จะแสดง

แต่ละแถวใน terminal ตรงกับ pattern provider ตัวใดตัวหนึ่ง

Pattern provider ใน terminal เรียงตามบล็อกที่มันต่ออยู่ หรือชื่อที่คุณตั้งให้ (ในทั่งหรือด้วย <ItemLink id="name_press" />)

## สูตรคราฟต์

<RecipeFor id="pattern_access_terminal" />
