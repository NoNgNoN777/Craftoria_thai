---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Access Point
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# Wireless Access Point

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

ให้เข้าถึงแบบไร้สายผ่าน <ItemLink id="wireless_terminal" />
ระยะและการใช้พลังงานขึ้นอยู่กับจำนวน <ItemLink id="wireless_booster" /> ที่ติดตั้ง

เครือข่ายมี wireless access point กี่ตัวก็ได้ โดยแต่ละตัวมี
<ItemLink id="wireless_booster" /> กี่ชิ้นก็ได้ ทำให้คุณปรับการใช้พลังงาน
และระยะให้เหมาะสมได้ด้วยการเปลี่ยนชุดที่ติดตั้ง

ใช้ [channel](../ae2-mechanics/channels.md) 1 ช่อง

ใช้ผูก [wireless terminal](wireless_terminals.md) ด้วย

# Wireless Booster

<ItemImage id="wireless_booster" scale="2" />

ใช้เพิ่มระยะของ wireless access point

## สูตรคราฟต์

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
