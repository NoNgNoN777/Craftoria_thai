---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Tiny TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Tiny TNT

<BlockImage id="tiny_tnt" scale="8" />

TNT ขนาดเล็กสำหรับการระเบิดเล็ก ๆ ใช้ทำคู่ <ItemLink id="quantum_entangled_singularity" /> ได้

ปิดความเสียหายต่อบล็อกของมันได้ใน config เพื่อให้ทำ singularity ได้โดยไม่เสี่ยงถูกกลั่นแกล้งทำลายสิ่งก่อสร้าง หากคุณต้องการปิด TNT และ creeper บนเซิร์ฟเวอร์

## สูตรคราฟต์

<RecipeFor id="tiny_tnt" />
