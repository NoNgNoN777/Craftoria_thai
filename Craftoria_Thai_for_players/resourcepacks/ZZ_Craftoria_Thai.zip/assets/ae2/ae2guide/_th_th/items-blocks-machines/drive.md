---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Drive
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# ME Drive

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

Drive คือ[อุปกรณ์](../ae2-mechanics/devices.md)ที่คุณเสียบ [storage cell](storage_cells.md) เพื่อใช้เป็น[คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md) มี 10 ช่อง แต่ละช่องรับ cell ได้ 1 ตัว

หากมีเหตุผลบางอย่าง คุณใส่และดึง cell จากช่องเก็บของของมันได้ด้วยระบบขนย้ายไอเทมใดก็ได้ เช่น ฮอปเปอร์หรือ bus ของ AE2

หมุนได้ด้วย <ItemLink id="certus_quartz_wrench" />

## ไฟ LED สถานะของ Cell

cell ใน drive มีไฟ LED ที่แสดงสถานะของมัน

| สี     | สถานะ                                                                            |
| :----- | :------------------------------------------------------------------------------- |
| เขียว  | ว่าง                                                                             |
| น้ำเงิน | มีของอยู่บ้าง                                                                    |
| ส้ม    | [ชนิด](../ae2-mechanics/bytes-and-types.md)เต็ม เพิ่มชนิดใหม่ไม่ได้                  |
| แดง    | [Byte](../ae2-mechanics/bytes-and-types.md)เต็ม ใส่ไอเทมเพิ่มไม่ได้                   |
| ดำ     | ไม่มีพลังงาน หรือ drive ไม่มี [channel](../ae2-mechanics/channels.md)              |

## ลำดับความสำคัญ

ตั้งลำดับความสำคัญได้ด้วยการคลิกไอคอนประแจที่มุมขวาบนของ GUI ไอเทมที่เข้าเครือข่ายจะเริ่มที่ storage ที่มีลำดับสูงสุดเป็นปลายทางแรก หาก storage หรือ cell สองตัวมีลำดับเท่ากัน และตัวหนึ่งมีไอเทมนั้นอยู่แล้ว ไอเทมจะเข้า storage ตัวนั้นก่อนตัวอื่น cell ที่ตั้ง [partition](cell_workbench.md) ไว้จะถือว่ามีไอเทมนั้นอยู่แล้วเมื่ออยู่ในกลุ่มลำดับเดียวกับ storage อื่น ไอเทมที่ถูกนำออกจาก storage จะถูกนำออกจาก storage ที่มีลำดับต่ำสุดก่อน ระบบลำดับนี้ทำให้เมื่อมีการใส่และนำไอเทมเข้าออกคลังของเครือข่าย storage ลำดับสูงจะเต็มขึ้น และ storage ลำดับต่ำจะว่างลง

## สูตรคราฟต์

<RecipeFor id="drive" />
