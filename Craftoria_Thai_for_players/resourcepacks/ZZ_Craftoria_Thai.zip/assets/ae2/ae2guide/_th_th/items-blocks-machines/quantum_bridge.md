---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quantum Bridge
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# Quantum Network Bridge

![A formed Quantum Network Bridge](../assets/diagrams/quantum_bridge_demonstration.png)

Quantum Network Bridge ขยาย[เครือข่าย](../ae2-mechanics/me-network-connections.md)ได้ในระยะไม่จำกัด และข้ามมิติได้ด้วย
รองรับรวม 32 channel (ไม่ว่าสายเคเบิลจะเชื่อมกับแต่ละด้านอย่างไร) โดยทำหน้าที่เหมือน
[dense cable](cables.md#dense-cable) ไร้สาย

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        สายเคเบิลสมมติระหว่างปลายทั้งสอง
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ข้อสำคัญ **ทั้งสองฝั่งต้องโหลดชังก์ไว้** จึงต้องใช้ <ItemLink id="spatial_anchor" /> หรือตัวโหลดชังก์อื่น
หาก 2 ฝั่งอยู่ไกลกัน

# Quantum Ring

<BlockImage id="quantum_ring" scale="8" />

บล็อกชนิดนี้ 8 ชิ้นที่วางล้อมรอบ <ItemLink id="quantum_link" /> จะสร้าง
Quantum Network Bridge เฉพาะบล็อก <ItemLink id="quantum_ring" /> 4 ชิ้นที่อยู่ติดกับ
<ItemLink id="quantum_link" /> เท่านั้นที่รับการเชื่อมต่อเครือข่าย
ส่วนบล็อกมุมทั้ง 4 ไม่เชื่อมต่อกับสายเคเบิล

## สูตรคราฟต์

<RecipeFor id="quantum_ring" />

# Quantum Link Chamber

<BlockImage id="quantum_link" scale="8" />

บล็อกชนิดนี้ 1 ชิ้นที่มี <ItemLink id="quantum_ring" /> ล้อมรอบ
จะสร้าง Quantum Network Bridge บล็อกนี้ไม่เชื่อมต่อกับสายเคเบิลใด ๆ และจะลงทะเบียน
เป็นส่วนหนึ่งของเครือข่ายก็ต่อเมื่อสร้างบริดจ์ครบแล้วเท่านั้น

ช่องเก็บของบล็อกนี้ใส่ได้เพียง <ItemLink id="quantum_entangled_singularity" /> ชิ้นเดียว และ
เข้าถึงได้ด้วยระบบออโต้

## สูตรคราฟต์

<RecipeFor id="quantum_link" />
