---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Energy Acceptor
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# Energy Acceptor

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

Energy acceptor แปลงพลังงานรูปแบบทั่วไปจากม็อดเทคอื่นเป็น [พลังงาน](../ae2-mechanics/energy.md) รูปแบบภายในของ AE2
คือ AE แม้ <ItemLink id="controller" /> ก็ทำเรื่องนี้ได้ แต่ด้านของ controller มีค่า จึงมักดีกว่าที่จะใช้ energy
acceptor แทน

อัตราส่วนการแปลง Forge Energy และ Techreborn Energy คือ

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

ความเร็วในการแปลงขึ้นอยู่กับว่าเครือข่ายของคุณเก็บ AE ได้เท่าไรเท่านั้น ด้วยเหตุผลที่อธิบายไว้ใน
[หน้านี้](../ae2-mechanics/energy.md)

## รูปแบบ

Energy acceptor มี 2 รูปแบบ คือแบบปกติ และแบบแบน/[ส่วนย่อย](../ae2-mechanics/cable-subparts.md) ช่วยให้คุณทำบางชุดให้กะทัดรัดขึ้นได้

สลับ Energy Acceptor ระหว่างแบบปกติกับแบบแบนได้ในช่องคราฟต์

## สูตรคราฟต์

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />