---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Cannon
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# Matter Cannon

<ItemImage id="matter_cannon" scale="4" />

Matter cannon คือ railgun แบบพกพาที่ยิงไอเทมชิ้นเล็กเป็นกระสุนได้ เช่น <ItemLink id="matter_ball" /> และ nugget โลหะ ความเสียหาย
ขึ้นกับไอเทมที่ยิง ไอเทมที่ "หนัก" กว่าอย่าง gold nugget (ความเสียหาย 10) สร้างความเสียหายมากกว่าไอเทมเบาอย่าง matter ball (ความเสียหาย 2)
ใช้พลังงานพื้นฐาน 1600 AE ต่อนัด

เมื่อตัวเลือกคอนฟิก "matterCannonBlockDamage" เป็น true ปืนใหญ่จะทำลายบล็อกตามความแข็งของบล็อก และ
ความเสียหายของกระสุน

ชาร์จพลังงานได้ใน <ItemLink id="charger" />

Matter cannon ทำงานเหมือน [storage cell](storage_cells.md) และเติมแมกกาซีนกระสุนได้ง่ายที่สุดด้วยการเสียบ
ปืนใหญ่ลงในช่อง storage cell ของ <ItemLink id="chest" />

## อัปเกรด

Matter cannon รองรับ [อัปเกรด](upgrade_cards.md) ต่อไปนี้ ซึ่งใส่ผ่าน <ItemLink id="cell_workbench" />

*   <ItemLink id="fuzzy_card" /> ให้กำหนด partition ของ cell ตามระดับความเสียหาย และ/หรือข้าม NBT ของไอเทม
*   <ItemLink id="inverter_card" /> เปลี่ยนตัวกรองจาก whitelist เป็น blacklist
*   <ItemLink id="speed_card" /> เพิ่มพลังงานที่ใช้ต่อนัด ทำให้ยิงแรงขึ้น
*   <ItemLink id="void_card" /> ทิ้งไอเทมที่ใส่เข้าไปเมื่อ cell เต็ม ระวังกำหนด partition ให้ดี!
*   <ItemLink id="energy_card" /> เพิ่มความจุแบตเตอรี่

## สูตรคราฟต์

<RecipeFor id="matter_cannon" />
