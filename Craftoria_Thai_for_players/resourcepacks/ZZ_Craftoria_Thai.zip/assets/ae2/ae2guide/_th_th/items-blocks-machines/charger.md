---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charger
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# Charger

<BlockImage id="charger" scale="8" />

Charger ใช้ชาร์จเครื่องมือที่รองรับ และ <ItemLink id="certus_quartz_crystal" />

จ่ายไฟได้ทางด้านบนหรือด้านล่าง ผ่าน [สายเคเบิล](cables.md) ของ AE2 หรือสายพลังงานของม็อดอื่น รับได้ทั้งพลังงานของ AE2 (AE) หรือ Forge Energy (FE)
ใส่หรือนำไอเทมออกได้จากทุกด้าน นำออกได้เฉพาะผลลัพธ์ จึงไม่ต้องใช้ตัวกรองกันไม่ให้ดึง certus crystal ออกแทน certus ที่ชาร์จแล้ว
หมุนได้ด้วย
<ItemLink id="certus_quartz_wrench" /> เพื่อให้ทำออโต้ได้ง่าย

ใช้สร้าง <ItemLink id="charged_certus_quartz_crystal" />
จาก <ItemLink id="certus_quartz_crystal" /> และสร้าง <ItemLink id="meteorite_compass" /> จาก <ItemLink id="minecraft:compass" />

หากต้องการจ่ายไฟด้วยมือ ให้วาง <ItemLink id="crank" /> ไว้ด้านบนหรือด้านล่าง แล้วคลิกขวาซ้ำจนไอเทมชาร์จเต็ม

ยังเป็นโต๊ะทำงานของ [Fluix Researcher](fluix_researcher.md) อีกด้วย

## ออโต้แบบง่าย

ตัวอย่างเช่น การหมุน Charger ได้ทำให้ทำออโต้กึ่งอัตโนมัติได้ดังนี้

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## สูตรคราฟต์

<RecipeFor id="charger" />
