---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Color Applicator
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# Color Applicator

<ItemImage id="color_applicator" scale="4" />

Color applicator ใช้ทาสีบล็อกที่ย้อมสีได้ เช่น [สายเคเบิล](cables.md), ขนแกะ, terracotta, กระจก และคอนกรีต ใช้ [paintball](paintballs.md) หรือสีย้อม และใช้ก้อนหิมะล้างสีออกจากสายเคเบิลและรอยสี paintball ออกจากบล็อกได้

ชาร์จพลังงานได้ใน <ItemLink id="charger" />

Color applicator ทำงานเหมือน [storage cell](storage_cells.md) และเติมสีได้ง่ายที่สุดด้วยการใส่ applicator ลงในช่อง storage cell ของ <ItemLink id="chest" />

คลิกขวาที่เป้าหมายเพื่อทาสีที่เลือก หากต้องการเปลี่ยนสี ให้เลื่อนลูกกลิ้งเมาส์ขณะกด shift หรือคลิกขวาโดยไม่มีเป้าหมาย

## การอัปเกรด

Color Applicator รองรับ[การอัปเกรด](upgrade_cards.md)ต่อไปนี้ ซึ่งใส่ผ่าน <ItemLink id="cell_workbench" />

*   <ItemLink id="equal_distribution_card" /> แบ่งพื้นที่ byte ของ cell เท่า ๆ กันให้แต่ละชนิด ชนิดเดียวจึงเติมเต็ม cell ทั้งหมดไม่ได้
*   <ItemLink id="void_card" /> ทำลายไอเทมที่ใส่เข้ามาหาก cell เต็ม (หรือพื้นที่ที่จัดสรรให้ชนิดนั้น
    กรณีมี equal distribution card) ระวังเรื่องการกำหนด partition ด้วย!
*   <ItemLink id="energy_card" /> เพิ่มความจุแบตเตอรี่

## สูตรคราฟต์

<RecipeFor id="color_applicator" />
