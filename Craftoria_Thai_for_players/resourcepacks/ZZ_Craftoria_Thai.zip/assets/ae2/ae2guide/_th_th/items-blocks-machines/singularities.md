---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Singularity
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# Singularity

<ItemImage id="singularity" scale="4" />

ก้อนสสารที่อัดแน่นมาก

ทำจากไอเทมหรือถังของเหลว 256,000 หน่วยใน <ItemLink id="condenser" /> ในโหมด singularity

## Quantum Entangled Singularity

<ItemImage id="quantum_entangled_singularity" scale="4" />

จำเป็นสำหรับสร้างการเชื่อมต่อระหว่าง [Quantum Network Bridge](quantum_bridge.md) สองตัว และผลิตออกมาเป็นคู่เสมอ หากต้องการเชื่อมต่อ ให้ใส่ quantum entangled singularity 1 ชิ้นจากคู่ลงใน <ItemLink id="quantum_link" /> ของ bridge แต่ละฝั่ง

คราฟต์ได้ด้วยการทำให้ <ItemLink id="minecraft:ender_pearl" /> หรือ <ItemLink id="ender_dust" />\
ทำปฏิกิริยากับ <ItemLink id="singularity" /> แรงระเบิดใดก็ได้เพียงพอที่จะกระตุ้นปฏิกิริยา

<RecipeFor id="quantum_entangled_singularity" />

***ระเบิดเกือบทุกชนิด แม้แต่ creeper ก็ใช้ได้***

ผลิตเป็นคู่เสมอ แต่ใช้ <ItemLink id="singularity" /> เพียงชิ้นเดียว

ควรตั้งชื่อให้แต่ละชิ้นตอนสร้าง โดยใช้ทั่งของ vanilla
