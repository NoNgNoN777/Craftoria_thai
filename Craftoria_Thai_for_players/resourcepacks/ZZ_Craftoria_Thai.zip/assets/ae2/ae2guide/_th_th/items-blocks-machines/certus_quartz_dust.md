---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Dust
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Certus Quartz Dust

<ItemImage id="certus_quartz_dust" scale="4" />

<ItemLink id="certus_quartz_crystal" /> ที่ถูกบดด้วย <ItemLink id="inscriber" /> ใช้ผลิตวัสดุและชิ้นส่วน AE2 หลายอย่าง

## สูตรคราฟต์

<RecipeFor id="certus_quartz_dust" />
