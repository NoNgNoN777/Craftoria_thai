---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Level Emitter
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# Level Emitter

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

Level Emitter ส่งสัญญาณ redstone ตามจำนวนไอเทมใน [คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md)

ยังมีอีกรุ่นที่ส่งสัญญาณ redstone ตาม[พลังงาน](../ae2-mechanics/energy.md)ที่เก็บอยู่ในเครือข่ายของคุณ

ลากไอเทมและของเหลวจาก JEI/REI ใส่ช่องได้ แม้คุณจะไม่มีไอเทมนั้นอยู่จริง

คลิกขวาด้วยภาชนะของเหลว (เช่น Bucket หรือ Fluid Tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรอง แทนการตั้งเป็นตัวถังเอง

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

ต่างจาก[อุปกรณ์](../ae2-mechanics/devices.md)อื่น level emitter *ไม่ต้องใช้* [channel](../ae2-mechanics/channels.md)

## การตั้งค่า

*   ตั้ง Level Emitter ได้เป็นโหมด "มากกว่า/เท่ากับ" หรือ "น้อยกว่า"
*   เมื่อใส่ <ItemLink id="crafting_card" /> ตั้งได้เป็น "ส่ง redstone ขณะไอเทมกำลังถูกคราฟต์" หรือ
    "ส่ง redstone เพื่อสั่งคราฟต์ไอเทม"

## การอัปเกรด

Level emitter รองรับ[การอัปเกรด](upgrade_cards.md)ต่อไปนี้

*   <ItemLink id="fuzzy_card" /> ให้ emitter กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="crafting_card" /> เปิดฟังก์ชันการคราฟต์

## ฟังก์ชันการคราฟต์

หากใส่ <ItemLink id="crafting_card" /> emitter จะสลับเป็นโหมดคราฟต์

จะเปิดตัวเลือกสองอย่าง

ตัวเลือกแรก "ส่ง redstone ขณะไอเทมกำลังถูกคราฟต์" ทำให้ emitter ส่งสัญญาณ redstone ขณะ [autocrafting](../ae2-mechanics/autocrafting.md) ของคุณกำลังคราฟต์ไอเทมที่กำหนดผ่าน <ItemLink id="pattern_provider" /> มีประโยชน์สำหรับเปิดระบบอัตโนมัติที่กินไฟมากเฉพาะตอนที่ใช้งานจริง

ตัวเลือกที่สอง "ส่ง redstone เพื่อสั่งคราฟต์ไอเทม" มีประโยชน์มากกับกรณีเฉพาะ เช่น ฟาร์มไม่รู้จบ และระบบอัตโนมัติที่มีโอกาสได้ผลลัพธ์เท่านั้น ไม่ได้ผลลัพธ์แน่นอน การตั้งค่านี้สร้าง [pattern](patterns.md) เสมือนให้ [autocrafting](../ae2-mechanics/autocrafting.md) ใช้ สำหรับไอเทมใดก็ตามที่อยู่ในช่องกรองของ emitter (เพื่อให้ทำงานถูกต้อง **ไม่ควรมี** pattern จริงของไอเทมเดียวกันอยู่ใน <ItemLink id="pattern_provider" /> ของคุณ)

"pattern" นี้ไม่ได้กำหนดวัตถุดิบ และไม่สนใจวัตถุดิบด้วยซ้ำ สิ่งที่มันบอกมีเพียง "หากคุณส่ง redstone จาก level emitter ตัวนี้ ระบบ ME จะได้รับไอเทมนี้ในอนาคตอันใกล้หรือไกล" มักใช้เปิดและปิดฟาร์มไม่รู้จบที่ไม่ต้องใช้วัตถุดิบ หรือเปิด [ระบบที่จัดการสูตรแบบวนซ้ำ](../example-setups/recursive-crafting-setup.md) (ซึ่ง autocrafting มาตรฐานไม่เข้าใจ) เช่น "Cobblestone 1 ก้อน = Cobblestone 2 ก้อน" หากคุณมีเครื่องที่ทำสำเนา Cobblestone

## สูตรคราฟต์

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
