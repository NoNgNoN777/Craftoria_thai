---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Researcher (ชาวบ้าน)
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# Fluix Researcher

<Row>
![Fluix Researcher](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

Fluix Researcher เป็นอาชีพของชาวบ้าน และบล็อกประจำอาชีพคือ <ItemLink id="charger" />

## การค้าขาย

การค้าขายเป็นไปตามโครงสร้างของ Vanilla โดยปลดล็อกการแลกเปลี่ยนแบบสุ่ม 2 รายการต่อระดับ (ยกเว้นระดับที่มีการแลกเปลี่ยนที่เป็นไปได้เพียง 1 รายการ)

| ระดับ        | ไอเทมที่ต้องการ                                   | ไอเทมที่ได้                                     |
|------------|---------------------------------------------------|-------------------------------------------------|
| มือใหม่     | 3 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="certus_quartz_crystal" />       |
| มือใหม่     | 2 <ItemLink id="minecraft:emerald" />             | 1 <ItemLink id="meteorite_compass" />           |
|            |                                                   |                                                 |
| ผู้ฝึกหัด     | 3 <ItemLink id="charged_certus_quartz_crystal" /> | 1 <ItemLink id="minecraft:emerald" />           |
| ผู้ฝึกหัด     | 5 <ItemLink id="silicon" />                       | 1 <ItemLink id="minecraft:emerald" />           |
| ผู้ฝึกหัด     | 5 <ItemLink id="minecraft:emerald" />             | 8 <ItemLink id="sky_stone_block" />             |
|            |                                                   |                                                 |
| ช่างฝีมือ    | 2 <ItemLink id="quartz_glass" />                  | 1 <ItemLink id="minecraft:emerald" />           |
| ช่างฝีมือ    | 5 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="fluix_crystal" />               |
|            |                                                   |                                                 |
| ผู้เชี่ยวชาญ | 5 <ItemLink id="matter_ball" />                   | 1 <ItemLink id="minecraft:emerald" />           |
| ผู้เชี่ยวชาญ | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="silicon_press" />               |
| ผู้เชี่ยวชาญ | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="logic_processor_press" />       |
| ผู้เชี่ยวชาญ | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="calculation_processor_press" /> |
| ผู้เชี่ยวชาญ | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="engineering_processor_press" /> |
|            |                                                   |                                                 |
| ปรมาจารย์   | 8 <ItemLink id="minecraft:emerald" />             | 5 <ItemLink id="minecraft:slime_ball" />        |