---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: View Cell
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# View Cell

<ItemImage id="view_cell" scale="2" />

View Cell ใช้กรองการแสดงผลของ [terminal](terminals.md) คุณกำหนด partition ได้ใน <ItemLink id="cell_workbench" />

ตัวอย่างเช่น หากต้องการให้ terminal แสดงเฉพาะวัสดุก่อสร้างจากหินบางชนิด
ให้กำหนด partition ของ View Cell เป็นวัสดุเหล่านั้นแล้วใส่ใน terminal ก็จะแสดงเฉพาะไอเทมเหล่านั้น

View Cell ทำงานแบบสะสม หากคุณมี View Cell สำหรับ Oak Planks และอีกอันสำหรับ Cobblestone การใส่ทั้งสองอันจะแสดง
ทั้ง Oak Planks และ Cobblestone

## สูตรคราฟต์

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
