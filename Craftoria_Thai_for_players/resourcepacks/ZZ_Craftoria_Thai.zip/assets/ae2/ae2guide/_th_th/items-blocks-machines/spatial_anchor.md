---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Anchor
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# Spatial Anchor

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

เครือข่าย AE2 ต้องถูก chunkload จึงจะทำให้ [อุปกรณ์](../ae2-mechanics/devices.md) ใด ๆ ทำงานได้ และถ้าโหลดแค่บางส่วน
อาจทำงานผิดพลาด Spatial Anchor แก้ปัญหานี้ด้วยการ forceload chunk ที่เครือข่ายของมันครอบคลุมอยู่
สายเคเบิลเส้นเดียวที่ยื่นข้ามขอบ chunk ก็พอให้โหลด chunk ใหม่นั้นได้

การ "โหลด" จะส่งต่อผ่าน [quantum bridge](quantum_bridge.md) แต่ไม่ข้ามมิติ ดังนั้นถ้าคุณ
มี quantum bridge ไป Nether คุณต้องมี spatial anchor บนเครือข่ายในฐานของคุณ และบนเครือข่ายใน Nether

โดยค่าตั้งต้น มันจะเปิด random tick ใน chunk ที่โหลดด้วย ปิดได้ในคอนฟิกของ ae2

หมุนได้ด้วย <ItemLink id="certus_quartz_wrench" /> ถ้าคุณมีเหตุผลอยากทำ

## การตั้งค่า

*   Spatial anchor มีตัวเลือกตั้งค่าส่วนกลางสำหรับดูพลังงานเป็นหน่วย AE หรือ E/FE
*   แสดงโฮโลแกรมในโลกให้เห็น chunk ที่กำลังโหลดอยู่ได้

## พลังงาน

Spatial anchor ใช้ [พลังงาน](../ae2-mechanics/energy.md) ตามสมการนี้

e = 80 + (x\*(x+1))/2

โดย x คือจำนวน chunk ที่กำลังโหลด

## สูตรคราฟต์

<RecipeFor id="spatial_anchor" />
