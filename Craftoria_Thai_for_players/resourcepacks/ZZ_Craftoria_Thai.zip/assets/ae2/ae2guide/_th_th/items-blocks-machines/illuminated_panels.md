---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Illuminated Panels
  icon: semi_dark_monitor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:monitor
- ae2:semi_dark_monitor
- ae2:dark_monitor
---

# Illuminated Panels

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/illuminated_panels.snbt" />
  <IsometricCamera yaw="-75" pitch="30" />
</GameScene>

Illuminated panel เป็นแหล่งกำเนิดแสงสำหรับตกแต่ง และใช้ผลิต [terminal](terminals.md) ด้วย

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

## สูตรคราฟต์

<Row>
  <RecipeFor id="monitor" />

  <RecipeFor id="semi_dark_monitor" />

  <RecipeFor id="dark_monitor" />
</Row>
