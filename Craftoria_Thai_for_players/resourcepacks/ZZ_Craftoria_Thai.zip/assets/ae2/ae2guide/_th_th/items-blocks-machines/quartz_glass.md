---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Glass
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# Quartz Glass

<BlockImage id="quartz_glass" scale="8" />

กระจกที่ใสเกือบทั้งหมด ทำจาก <ItemLink id="certus_quartz_dust" /> ใช้ทำเครื่องจักรและไอเทม AE2 หลายอย่าง

มีอีกรุ่นคือ vibrant quartz glass ที่เปล่งแสงได้

## สูตรคราฟต์

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
