---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Staff
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# Charged Staff

<ItemImage id="charged_staff" scale="4" />

Charged Staff เป็นไม้เท้าที่มี <ItemLink id="charged_certus_quartz_crystal" /> ติดที่ปลาย สร้างความเสียหาย 6 และใช้ 300 AE ต่อการโจมตี 1 ครั้ง

ชาร์จพลังงานได้ใน <ItemLink id="charger" />

## สูตรคราฟต์

<RecipeFor id="charged_staff" />
