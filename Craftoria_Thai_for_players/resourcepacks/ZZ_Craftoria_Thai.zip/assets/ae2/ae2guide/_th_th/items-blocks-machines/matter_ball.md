---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Ball
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Matter Ball

<ItemImage id="matter_ball" scale="4" />

ก้อนสสารทั่วไป ใช้เป็นกระสุนของ <ItemLink id="matter_cannon" /> หรือใช้ผลิต [paintball](paintballs.md)

ทำจากไอเทมหรือถัง 256 หน่วยใน <ItemLink id="condenser" /> ในโหมด matter ball
