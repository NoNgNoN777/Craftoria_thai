---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Export Bus
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# Export Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

Export bus ดึงไอเทมและของเหลว (รวมถึงอย่างอื่นหากมี addon) จาก [คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md) แล้วส่งเข้าไปในช่องเก็บของที่มันแตะอยู่

เพื่อลดแลก หากนำเข้าไม่ได้ส่งออกอะไรมาสักพัก มันจะเข้าสู่ "โหมดหลับ" ที่ทำงานช้าลง และจะตื่นเร่งความเร็วเต็มที่ (4 ครั้งต่อวินาที) เมื่อส่งออกสำเร็จ

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

## การกรอง

โดยค่าเริ่มต้น bus จะไม่ส่งออกอะไรเลย ไอเทมที่ใส่ในช่องกรองจะทำหน้าที่เป็น whitelist ให้ส่งออกได้เฉพาะไอเทมเหล่านั้น

ลากไอเทมและของเหลวจาก JEI/REI ใส่ช่องได้ แม้คุณจะไม่มีไอเทมนั้นอยู่จริง

คลิกขวาด้วยภาชนะของเหลว (เช่น Bucket หรือ Fluid Tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรอง แทนการตั้งเป็นตัวถังเอง

## การอัปเกรด

Import bus รองรับ [การอัปเกรด](upgrade_cards.md) ดังนี้

*   <ItemLink id="capacity_card" /> เพิ่มจำนวนช่องกรอง และเปิดการตั้งค่าลำดับการส่งออกสิ่งที่กรองไว้
*   <ItemLink id="speed_card" /> เพิ่มจำนวนที่ย้ายต่อการทำงานหนึ่งครั้ง
*   <ItemLink id="fuzzy_card" /> ให้ bus กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="crafting_card" /> ให้ bus ส่งคำขอคราฟต์ไปยังระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
    เพื่อให้ได้ไอเทมที่ต้องการ ตั้งให้ดึงไอเทมจากคลังหากมี
    หรือให้ขอคราฟต์ไอเทมใหม่ทุกครั้งก็ได้
*   <ItemLink id="redstone_card" /> เพิ่มการควบคุมด้วย redstone ให้ทำงานเมื่อมีสัญญาณสูง สัญญาณต่ำ หรือหนึ่งครั้งต่อพัลส์

## ความเร็ว

| Acceleration Card | จำนวนไอเทมที่ย้ายต่อการทำงาน |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## สูตรคราฟต์

<RecipeFor id="import_bus" />
