---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wrench
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Wrench

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Wrench ใช้หมุนอุปกรณ์ AE2 (คลิกขวา) และรื้อบล็อก AE2 (shift คลิกขวา) ถอด[ชิ้นส่วนย่อย](../ae2-mechanics/cable-subparts.md)ออกจากสายได้โดยไม่ทำให้ทุกอย่างบนสายพัง (หรือถอดสายออกโดยไม่ทำให้ชิ้นส่วนย่อยพัง)

บล็อก AE2 จำนวนมากหมุนได้ ดังนั้นแม้คู่มือนี้ไม่ได้บอกว่าหมุนอะไรได้ ก็ไม่ได้แปลว่าหมุนไม่ได้

## สูตรคราฟต์

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
