---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Formation Plane
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# Formation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

Formation Plane วางบล็อกและทิ้งไอเทม ทำงานคล้าย <ItemLink id="storage_bus" /> แบบรับเข้าอย่างเดียว คือวางหรือทิ้งเมื่อมีของถูก "เก็บ" ลงไป โดย[อุปกรณ์](../ae2-mechanics/devices.md)ที่ใส่ของเข้า[คลังของเครือข่าย](../ae2-mechanics/import-export-storage.md) เช่น <ItemLink id="import_bus" /> และ <ItemLink id="interface" />

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

สังเกตว่าคล้ายกับท่อ import bus -> storage bus และ interface -> storage bus ใน [pipe subnet](../example-setups/pipe-subnet.md)

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

[อุปกรณ์](../ae2-mechanics/devices.md)นี้ใช้กลไกเดียวกับ storage bus ในสิ่งอย่าง [pipe subnet](../example-setups/pipe-subnet.md) และแทน storage bus ในระบบเหล่านั้นได้ หากคุณต้องการทิ้งไอเทมหรือวางบล็อกแทนการขนย้ายไอเทม

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

**อย่าลืมเปิดใช้ FAKE PLAYER ในพื้นที่ที่คุณจอง CHUNK ไว้**

## การกรอง

โดยค่าเริ่มต้น plane จะวางหรือทิ้งทุกอย่าง ไอเทมที่ใส่ในช่องกรองจะทำหน้าที่เป็น whitelist ให้วางได้เฉพาะไอเทมเหล่านั้น

ลากไอเทมและของเหลวจาก JEI/REI ใส่ช่องได้ แม้คุณจะไม่มีไอเทมนั้นอยู่จริง

คลิกขวาด้วยภาชนะของเหลว (เช่น Bucket หรือ Fluid Tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรอง แทนการตั้งเป็นตัวถังเอง

## ลำดับความสำคัญ

ตั้งลำดับความสำคัญได้ด้วยการคลิกไอคอนประแจที่มุมขวาบนของ GUI ไอเทมที่เข้าเครือข่ายจะเริ่มที่ storage ที่มีลำดับสูงสุด

## การตั้งค่า

*   ตั้ง plane ให้วางบล็อกในโลก หรือทิ้งไอเทมก็ได้

## การอัปเกรด

Formation plane รองรับ[การอัปเกรด](upgrade_cards.md)ต่อไปนี้

*   <ItemLink id="capacity_card" /> เพิ่มจำนวนช่องกรอง
*   <ItemLink id="fuzzy_card" /> ให้ plane กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="inverter_card" /> สลับตัวกรองจาก whitelist เป็น blacklist

## สูตรคราฟต์

<RecipeFor id="formation_plane" />
