---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cutting Knives
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# เครื่องมือ Quartz

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Cutting Knife ใช้ทำ <ItemLink id="name_press" /> และ <ItemLink id="cable_anchor" />

ถ้าจะคราฟต์ name press ให้คลิกขวาด้วย cutting knife แล้วใส่แท่งโลหะ จากนั้นพิมพ์ชื่อ
ที่ต้องการเขียนลงบนแผ่น แล้วหยิบแผ่นที่เสร็จออกมา

## สูตรคราฟต์

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
