---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crank
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# Crank

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Crank ใช้จ่ายพลังงานให้เครื่องจักรเมื่อคุณยังไม่มีแหล่งพลังงานอื่น (หรือ <ItemLink id="energy_acceptor" />) ช่วงต้นเกมก็ลำบากแบบนี้แหละ

## สูตรคราฟต์

<RecipeFor id="crank" />
