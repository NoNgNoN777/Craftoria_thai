---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: P2P Tunnel
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# Point To Point Tunnel

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2P tunnel เป็นวิธีย้ายสิ่งต่าง ๆ เช่น ไอเทม ของเหลว สัญญาณ redstone พลังงาน แสง และ [channel](../ae2-mechanics/channels.md) ไปรอบเครือข่ายโดยไม่ต้องโต้ตอบกับเครือข่ายโดยตรง P2P tunnel มีหลายรุ่น แต่แต่ละรุ่นขนส่งได้เฉพาะสิ่งของชนิดของมันเท่านั้น โดยพื้นฐานทำงานเหมือนประตูมิติที่เชื่อมสองด้านของบล็อกเข้าด้วยกันโดยตรงแม้อยู่ไกลกัน ไม่ใช่แบบสองทาง มีอินพุตและเอาต์พุตที่กำหนดไว้

![Portal](../assets/assemblies/p2p_portal.png)

ตัวอย่างเช่น ฮอปเปอร์ที่หันเข้าหา Item P2P จะทำงานเหมือนต่อตรงกับ Barrel และไอเทมจะไหลผ่าน

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

แต่ Barrel สองใบที่วางติดกันจะไม่ย้ายไอเทมถึงกัน

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ยังมีรุ่นอื่นอีก เช่น Redstone P2P

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

และ ME P2P ซึ่งย้าย channel

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## ชนิดของ P2P Tunnel และ Attunement

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

P2P tunnel มีหลายชนิด มีเพียง ME P2P tunnel ที่คราฟต์ได้โดยตรง ชนิดอื่นทำได้ด้วยการคลิกขวา
P2P tunnel อื่นด้วยไอเทมบางอย่าง
- ME P2P tunnel เลือกด้วยการคลิกขวาด้วย[สายเคเบิล](../items-blocks-machines/cables.md)ชนิดใดก็ได้
- Redstone P2P tunnel เลือกด้วยการคลิกขวาด้วยชิ้นส่วน redstone หลายชนิด
- Item P2P tunnel เลือกด้วยการคลิกขวาด้วยหีบหรือฮอปเปอร์
- Fluid P2P tunnel เลือกด้วยการคลิกขวาด้วย Bucket หรือขวด
- Energy P2P tunnel เลือกด้วยการคลิกขวาด้วยไอเทมที่เก็บพลังงานได้เกือบทุกชนิด
- Light P2P tunnel เลือกด้วยการคลิกขวาด้วยคบเพลิงหรือ glowstone

tunnel บางชนิดมีข้อควรรู้ เช่น channel ของ ME P2P tunnel ผ่าน ME P2P tunnel ตัวอื่นไม่ได้ และ Energy P2P tunnel ดึงภาษี 2.5% จาก FE ที่ไหลผ่านตัวเองทางอ้อม ด้วยการเพิ่มการดึง[พลังงาน](../ae2-mechanics/energy.md)ของมัน

## P2P รูปแบบที่ใช้บ่อยที่สุด

การใช้ P2P tunnel ที่พบบ่อยที่สุดคือใช้ ME P2P tunnel เพื่อบีบอัดการขนส่ง [channel](../ae2-mechanics/channels.md) แทนสาย dense หลายเส้น ใช้สาย dense เส้นเดียวพา channel จำนวนมากไปรอบ ๆ ได้

ในตัวอย่างนี้ ME P2P อินพุต 8 ตัวรับ 256 channel (8*32) จาก <ItemLink id="controller" /> ของเครือข่ายหลัก และ ME P2P เอาต์พุต 8 ตัว
ส่งออกไปที่อื่น สังเกตว่า P2P tunnel อินพุตหรือเอาต์พุตแต่ละตัวใช้ 1 channel เราจึงส่ง channel จำนวนมาก
ผ่านสายเส้นบางได้ และเนื่องจาก P2P tunnel ของเราอยู่บน [subnetwork](../ae2-mechanics/subnetworks.md) เฉพาะ เราจึงไม่ได้ใช้ channel
ของเครือข่ายหลักเลยด้วยซ้ำ! สังเกตด้วยว่า แม้วาง P2P tunnel ติด controller ได้โดยตรง ก็ยังวาง [dense smart cable](../items-blocks-machines/cables.md#smart-cable) คั่นตรงกลางเพื่อให้เห็น channel ชัดขึ้นได้

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        Quartz Fiber แบ่งพลังงานระหว่างเครือข่ายหลักกับ p2p subnetwork
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        วาง tunnel อินพุตติด controller โดยตรง หรือต่อสายเข้าไปก็ได้
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

สำหรับอีกตัวอย่างหนึ่ง (รวมการใช้ร่วมกับ [Quantum Bridge](quantum_bridge.md)) ดูภาพที่วาดด้วย MS Paint ซึ่งขี้เกียจแต่งให้สวย

![P2P and quantum bridges](../assets/diagrams/p2p_quantum_network.png)

## การซ้อน

แต่คุณใช้วิธีนี้ส่ง channel ไม่จำกัดผ่านสายเส้นเดียวไม่ได้ channel ของ ME P2P tunnel ผ่าน ME P2P tunnel ตัวอื่นไม่ได้ จึงซ้อนกันแบบวนซ้ำไม่ได้ สังเกตว่า ME P2P tunnel ชั้นนอกบนสายสีแดงออฟไลน์อยู่ โปรดทราบว่าข้อนี้ใช้กับ ME P2P tunnel เท่านั้น P2P tunnel ชนิดอื่นผ่าน ME P2P tunnel ได้ ดังที่เห็นว่า Redstone P2P tunnel ทำงานได้ปกติ

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## การเชื่อมโยง

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ปลายทั้งสองของการเชื่อมต่อ P2P Tunnel เชื่อมกันได้ด้วย <ItemLink id="memory_card" /> ความถี่จะแสดงเป็นสีเรียงแบบ 2x2
ที่ด้านหลังของ Tunnel
- Shift + คลิกขวา เพื่อสร้างความถี่เชื่อม P2P ใหม่
- คลิกขวา เพื่อวางการตั้งค่า การ์ดอัปเกรด หรือความถี่เชื่อม

Tunnel ที่คุณ Shift + คลิกขวาจะเป็นขาเข้า และ Tunnel ที่คุณคลิกขวาจะเป็นขาออก มีขาออกได้หลายตัว
แต่สำหรับ ME P2P Tunnel channel ที่ไหลเข้าขาเข้าจะถูกแบ่งไปตามขาออก ดังนั้นคุณทำสำเนา channel ไม่ได้

## สูตรคราฟต์

<RecipeFor id="me_p2p_tunnel" />