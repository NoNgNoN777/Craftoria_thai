---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Chest
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# ME Chest

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

ME Chest ทำงานเหมือนเครือข่ายขนาดเล็กที่มี <ItemLink id="terminal" /> <ItemLink id="drive" /> และ <ItemLink id="energy_acceptor" /> ในตัว
แม้ใช้เป็นเครือข่าย storage ขนาดจิ๋วได้ แต่รองรับ [storage cell](../items-blocks-machines/storage_cells.md) ได้เพียงอันเดียว
จึงมีประโยชน์จำกัดในแบบนั้น

แต่จะมีประโยชน์เมื่อใช้โต้ตอบกับ storage cell ที่ติดตั้งอยู่ข้างในโดยเฉพาะ Terminal ในตัวมองเห็นและเข้าถึงได้เฉพาะ
ไอเทมใน Drive ที่ติดตั้ง ขณะที่ [อุปกรณ์](../ae2-mechanics/devices.md) บนเครือข่ายทั่วไปเข้าถึงไอเทมใน [network storage](../ae2-mechanics/import-export-storage.md) ใดก็ได้
รวมถึง ME Chest

มี GUI 2 แบบและแยกตามด้านสำหรับขนส่งไอเทม การโต้ตอบกับ Terminal ด้านบนจะเปิด Terminal ในตัว ใส่ไอเทมลงใน
storage cell ที่ติดตั้งผ่านด้านนี้ได้ แต่ดึงออกไม่ได้ การโต้ตอบกับด้านอื่นจะเปิด GUI ที่มีช่องสำหรับ storage cell
และการตั้งลำดับความสำคัญ ระบบขนส่งไอเทมใส่และนำ cell ออกได้เฉพาะผ่านด้านที่มีช่อง cell

หมุนได้ด้วย <ItemLink id="certus_quartz_wrench" />

มีบัฟเฟอร์เก็บพลังงาน AE ขนาดเล็ก ดังนั้นหากไม่ได้อยู่บนเครือข่ายที่มี [energy cell](../items-blocks-machines/energy_cells.md)
การใส่หรือดึงไอเทมจำนวนมากพร้อมกันอาจทำให้ไฟตก

ย้อมสี Terminal ได้ด้วย <ItemLink id="color_applicator" />

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

ME Chest มีการตั้งค่าทุกอย่างเหมือน <ItemLink id="terminal" /> หรือ <ItemLink id="crafting_terminal" />
แต่ไม่รองรับ <ItemLink id="view_cell" />

## ไฟ LED สถานะ Cell

cell ในหีบมีไฟ LED แสดงสถานะ

| สี     | สถานะ                                                                            |
| :----- | :------------------------------------------------------------------------------- |
| เขียว  | ว่าง                                                                             |
| ฟ้า    | มีของอยู่บ้าง                                                                    |
| ส้ม    | [Type](../ae2-mechanics/bytes-and-types.md) เต็ม เพิ่ม type ใหม่ไม่ได้            |
| แดง    | [Byte](../ae2-mechanics/bytes-and-types.md) เต็ม ใส่ไอเทมเพิ่มไม่ได้              |
| ดำ     | ไม่มีไฟ หรือ drive ไม่มี [channel](../ae2-mechanics/channels.md)                 |

## ลำดับความสำคัญ

ตั้งลำดับความสำคัญได้โดยคลิกประแจที่มุมขวาบนของ GUI ช่อง cell
ไอเทมที่เข้ามาในเครือข่ายจะเริ่มจาก storage ที่มีลำดับสูงสุดเป็นปลายทางแรก
หาก storage หรือ cell สองตัวมีลำดับเท่ากัน
และตัวหนึ่งมีไอเทมนั้นอยู่แล้ว จะเลือก storage นั้นก่อนตัวอื่น cell ที่ [partition](cell_workbench.md) ไว้
จะถือว่ามีไอเทมนั้นอยู่แล้วเมื่ออยู่ในกลุ่มลำดับเดียวกับ storage อื่น ไอเทมที่ถูกดึงออกจาก storage
จะถูกดึงจาก storage ที่มีลำดับต่ำสุด ระบบลำดับนี้ทำให้เมื่อใส่และดึงไอเทมจาก
network storage ตัวที่ลำดับสูงกว่าจะถูกเติมเต็ม และตัวที่ลำดับต่ำกว่าจะถูกทำให้ว่าง

## สูตรคราฟต์

<RecipeFor id="chest" />
