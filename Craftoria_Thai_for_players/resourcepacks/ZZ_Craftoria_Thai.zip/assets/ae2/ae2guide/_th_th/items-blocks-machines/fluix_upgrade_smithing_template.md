---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Smithing Template
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Fluix Smithing Template

ต่างจาก smithing template ของ vanilla ตรงที่คุณทำอันนี้จากศูนย์ได้

จำเป็นสำหรับ [fluix tool](fluix_tools.md)

## สูตรคราฟต์

<RecipeFor id="fluix_upgrade_smithing_template" />