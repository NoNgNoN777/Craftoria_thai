---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Molecular Assembler
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# Molecular Assembler

<BlockImage id="molecular_assembler" scale="8" />

Molecular assembler รับไอเทมที่ใส่เข้ามา และทำงานตามที่ <ItemLink id="pattern_provider" /> ข้างเคียง หรือ <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> หรือ <ItemLink id="stonecutting_pattern" /> ที่ใส่ไว้กำหนด
แล้วส่งผลลัพธ์ไปยังช่องเก็บของข้างเคียง

Assembler ตัวนี้มี crafting pattern สูตร Oak Log 1 ก้อน = Oak Planks 4 ก้อน เมื่อป้อน Oak Log เข้าฮอปเปอร์ด้านบน assembler จะคราฟต์แล้วคาย Oak Planks ลงฮอปเปอร์ด้านล่าง

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การใช้งานหลักของ Molecular Assembler

แต่การใช้งานหลักคือวางข้าง <ItemLink id="pattern_provider" /> Pattern provider มีพฤติกรรมพิเศษในกรณีนี้ คือส่งข้อมูลของ pattern ที่เกี่ยวข้องไปพร้อมวัตถุดิบให้ assembler ที่อยู่ติดกัน เนื่องจาก assembler ดีดผลลัพธ์ที่คราฟต์เสร็จเข้าช่องเก็บของข้างเคียง (จึงเข้าช่องรับผลลัพธ์ของ pattern provider ด้วย) การมี assembler ติดกับ pattern provider จึงเพียงพอสำหรับทำการคราฟต์อัตโนมัติ

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การอัปเกรด

Molecular Assembler รองรับ[การอัปเกรด](upgrade_cards.md)ต่อไปนี้

*   <ItemLink id="speed_card" />

## สูตรคราฟต์

<RecipeFor id="molecular_assembler" />

## หมายเหตุ

Optifine ทำให้ฟังก์ชัน "ส่งไปยังช่องเก็บของข้างเคียง" พัง ระบบคราฟต์ส่วนใหญ่ที่ใช้ assembler จึงใช้งานไม่ได้