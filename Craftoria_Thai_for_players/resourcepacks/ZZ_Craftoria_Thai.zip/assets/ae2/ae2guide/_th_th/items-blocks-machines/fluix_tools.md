---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: เครื่องมือ Fluix
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# เครื่องมือ Fluix

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

เครื่องมือ [Fluix](fluix_crystal.md) คล้ายเครื่องมือเหล็ก แต่ทนทานกว่า 3 เท่า และมี Attack Damage กับความเร็วในการขุดสูงกว่าเล็กน้อย

เครื่องมือ Fluix ทุกชิ้นทำงานเหมือนมี Fortune/Looting อย่างน้อย 1 ซึ่งมีประโยชน์ก่อนจะเข้าถึงโต๊ะ Enchanting

คุณต้องทำ <ItemLink id="fluix_upgrade_smithing_template" />

## สูตรคราฟต์

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
