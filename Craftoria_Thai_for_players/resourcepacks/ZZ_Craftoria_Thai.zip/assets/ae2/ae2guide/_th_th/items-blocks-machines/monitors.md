---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Monitors
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# Monitors

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Monitor ให้ดูและโต้ตอบกับไอเทมหรือของเหลวชนิดเดียวได้ โดยไม่ต้องเปิด GUI

Monitor รับสีของ [สายเคเบิล](cables.md) ที่มันติดอยู่

ถ้า monitor อยู่บนพื้นหรือเพดาน คุณหมุนได้ด้วย <ItemLink id="certus_quartz_wrench" />

เป็น [ส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

# Storage Monitor

แสดงไอเทมหรือของเหลวพร้อมจำนวน วางไว้ข้างฟาร์มของคุณหรืออะไรทำนองนั้น...

*ไม่* ใช้ [channel](../ae2-mechanics/channels.md)

ปุ่มควบคุม:

*   คลิกขวาด้วยไอเทม หรือคลิกขวาสองครั้งด้วยภาชนะของเหลว เพื่อตั้ง monitor เป็นไอเทม/ของเหลวนั้น
*   คลิกขวาด้วยมือเปล่าเพื่อล้าง monitor
*   Shift แล้วคลิกขวาด้วยมือเปล่าเพื่อล็อก monitor

## สูตรคราฟต์

<RecipeFor id="storage_monitor" />

# Conversion Monitor

Conversion Monitor คล้ายกับ storage monitor แต่ให้คุณใส่หรือดึงไอเทมที่ตั้งไว้ได้

ถ้าไอเทมที่ตั้งไว้ [autocraft](../ae2-mechanics/autocrafting.md) ได้ และไม่มีเหลือในที่เก็บ การพยายามหยิบ
ไอเทมจะเปิด UI ให้ระบุจำนวนที่จะคราฟต์แทน

*ใช้* [channel](../ae2-mechanics/channels.md) 1 ช่อง

ปุ่มควบคุมเพิ่มเติม:

*   คลิกซ้ายเพื่อดึงไอเทมที่ตั้งไว้ออกหนึ่งสแต็ก หรือสั่งคราฟต์ไอเทมนั้นถ้าไม่มีในที่เก็บ
*   คลิกขวาด้วยไอเทมใดก็ได้เพื่อใส่ไอเทมนั้น
*   คลิกขวาด้วยมือเปล่าเพื่อใส่ไอเทมที่ตั้งไว้ทั้งหมดจากช่องเก็บของของคุณ

## สูตรคราฟต์

<RecipeFor id="conversion_monitor" />
