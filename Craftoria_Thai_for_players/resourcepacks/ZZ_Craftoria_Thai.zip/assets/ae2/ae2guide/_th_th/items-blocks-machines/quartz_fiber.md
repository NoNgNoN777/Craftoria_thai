---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Fiber
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# Quartz Fiber

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Quartz Fiber ใช้แบ่งปันพลังงานระหว่าง[เครือข่าย](../ae2-mechanics/me-network-connections.md) โดยยังคงแยกเครือข่ายออกจากกัน ทำให้คุณจ่ายไฟให้
[subnetwork](../ae2-mechanics/subnetworks.md)
ได้โดยไม่ต้องวาง Energy Acceptor และสายไฟไปทุกที่ ใช้กันไม่ให้สายเคเบิลเชื่อมกันได้ด้วย
แต่การใช้สายเคเบิลคนละสี หรือใช้ <ItemLink id="cable_anchor" /> ถูกกว่าและได้ผลดีกว่า

เป็น [cable subpart](../ae2-mechanics/cable-subparts.md)

## สูตรคราฟต์

<RecipeFor id="quartz_fiber" />
