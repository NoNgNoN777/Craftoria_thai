---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Crystal
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# Certus Quartz Crystal

<ItemImage id="certus_quartz_crystal" scale="4" />

*"Certus Quartz Crystal มีคุณสมบัติเฉพาะตัวคือรับพลังงานปริมาณมากเข้าสู่โครงสร้างผลึกของมันได้"*

หนึ่งในส่วนผสมหลักของบล็อก [อุปกรณ์](../ae2-mechanics/devices.md) และไอเทมของ AE2 ได้มาจากการปลูกจาก [budding certus](../ae2-mechanics/certus-growth.md)

## สูตรทางเลือกบางอย่าง

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
