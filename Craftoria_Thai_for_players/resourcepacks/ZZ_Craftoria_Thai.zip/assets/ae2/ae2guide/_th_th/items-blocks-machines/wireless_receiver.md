---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Receiver
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# Wireless Receiver

<ItemImage id="wireless_receiver" scale="4" />

<ItemLink id="fluix_pearl" /> ในจานสะท้อน เป็นชิ้นส่วนของเทคโนโลยี ME ไร้สายระยะสั้น

## สูตรคราฟต์

<RecipeFor id="wireless_receiver" />
