---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Energy Cell
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Energy Cell

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Energy Cell เพิ่มความจุ[พลังงาน](../ae2-mechanics/energy.md)ให้เครือข่าย บัฟเฟอร์พลังงานระดับหนึ่งช่วยลดการกระชากของการใช้พลังงาน
เมื่อมีการใส่หรือดึงไอเทมจำนวนมาก และความจุพลังงานที่มากขึ้น
ทำให้เครือข่ายทำงานต่อได้ขณะไม่มีการผลิตพลังงาน (เช่น ตอนกลางคืนเมื่อใช้แผงโซลาร์) หรือรับมือกับการใช้พลังงานมหาศาลในชั่วขณะของ
[spatial storage](../ae2-mechanics/spatial-io.md)

## แถบแสดงปริมาณ

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

แถบด้านข้างของ cell แสดงปริมาณพลังงานที่มี

*   0 แถบ เมื่อชาร์จต่ำกว่า 25%
*   1 แถบ เมื่อชาร์จระหว่าง 25% ถึง 50%
*   2 แถบ เมื่อชาร์จระหว่าง 50% ถึง 75%
*   3 แถบ เมื่อชาร์จระหว่าง 75% ถึง 99%
*   4 แถบ เมื่อชาร์จสูงกว่า 99%

## ชนิดของ Cell

*   <ItemLink id="energy_cell" /> เก็บได้ 200k AE และอันเดียวก็เพียงพอสำหรับการใช้งานส่วนใหญ่ รับมือกับพลังงานกระชาก
    จากการใช้เครือข่ายปกติได้สบาย
*   <ItemLink id="dense_energy_cell" /> เก็บได้ 1.6M AE เหมาะเมื่อคุณต้องการให้เครือข่ายทำงานจากพลังงานที่สะสมไว้ หรือรับมือกับ
    การใช้พลังงานมหาศาลในชั่วขณะของระบบ [spatial storage](../ae2-mechanics/spatial-io.md) ขนาดใหญ่
*   <ItemLink id="creative_energy_cell" /> เป็นไอเทมครีเอทีฟสำหรับทดสอบ ให้พลังงานไม่จำกัด UNLIMITED POWAHHHH หรืออะไรทำนองนั้น

## สูตรคราฟต์

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
