---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz Block
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# Certus Quartz Block

<BlockImage id="quartz_block" scale="8" />

บล็อกเก็บของของ <ItemLink id="certus_quartz_crystal" /> ใช้ทำ [budding certus block](budding_certus.md) หรือ [บล็อกตกแต่ง Certus](decorative_certus.md) ได้

## สูตรคราฟต์

<RecipeFor id="quartz_block" />
