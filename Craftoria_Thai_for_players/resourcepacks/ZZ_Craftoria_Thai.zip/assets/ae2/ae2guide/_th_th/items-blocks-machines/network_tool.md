---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Network Tool
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# Network Tool

<ItemImage id="network_tool" scale="4" />

Network Tool เป็น [wrench](wrench.md) ที่ดัดแปลง แสดงข้อมูลวินิจฉัยเครือข่ายได้ด้วย และเก็บ [upgrade card](upgrade_cards.md) ได้ ยังคงความสามารถของ wrench ในการรื้อของอย่างรวดเร็วและดึง[ชิ้นส่วนย่อย](../ae2-mechanics/cable-subparts.md)ออกจากสายเคเบิล แต่หมุนของไม่ได้

มีช่องเก็บ [upgrade card](upgrade_cards.md) 9 ช่อง และ card เหล่านั้นจะใช้ได้ใน UI ของอุปกรณ์ AE2 ทุกตัว หากมีเครื่องมืออยู่ที่ใดก็ตามในช่องเก็บของของคุณ

คลิกขวาที่ส่วนใดของเครือข่ายจะแสดงหน้าต่างข้อมูลวินิจฉัย คล้ายการคลิกขวาที่ <ItemLink id="controller" /> หน้าต่างนี้แสดง

*   จำนวน channel ที่ใช้อยู่ในเครือข่าย
*   ปุ่มสลับการตั้งค่ารวมสำหรับดูพลังงานเป็น AE หรือ E/FE
*   ปริมาณ[พลังงาน](../ae2-mechanics/energy.md)ที่เก็บอยู่ในเครือข่าย และความจุพลังงานสูงสุดของเครือข่าย
*   ปริมาณพลังงานที่เข้าเครือข่ายและที่เครือข่ายใช้
*   รายการ[อุปกรณ์](../ae2-mechanics/devices.md)และชิ้นส่วนทั้งหมดในเครือข่าย

หน้าต่างนี้ยังช่วยตรวจว่า สายเคเบิลหรืออุปกรณ์สองตัว อยู่ในเครือข่ายเดียวกันหรือไม่ เมื่อทดลองกับ [Subnetwork](../ae2-mechanics/subnetworks.md)

## การซ่อน Facade

<a href="facades.md">Facade</a> จะถูกซ่อนเมื่อถือ network tool ไว้ในมือใดมือหนึ่ง

คุณโต้ตอบกับบล็อกที่อยู่หลัง facade ที่ซ่อนอยู่ได้ โดยไม่ต้องถอด facade ออกก่อน

## สูตรคราฟต์

<RecipeFor id="network_tool" />
