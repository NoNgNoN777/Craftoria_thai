---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Inscriber
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# Inscriber

<BlockImage id="inscriber" scale="8" />

Inscriber ใช้สลักวงจรและ [processor](processors.md) ด้วย [press](presses.md) และบดไอเทมหลายอย่างเป็นผง
รับได้ทั้งพลังงานของ AE2 (AE) หรือ Fabric/Forge Energy (E/FE) แยกตามด้านได้ โดยใส่ไอเทมจากแต่ละด้านจะเข้าช่องคนละช่อง
เพื่อให้ทำเช่นนี้ได้ หมุนได้ด้วย <ItemLink id="certus_quartz_wrench" />
และตั้งให้ส่งผลลัพธ์ที่คราฟต์ได้ไปยังช่องเก็บที่อยู่ติดกันก็ได้

ปรับขนาดบัฟเฟอร์ขาเข้าได้ เช่น หากคุณต้องการป้อนจากช่องเก็บเดียวเข้า Inscriber ชุดใหญ่
คุณควรใช้บัฟเฟอร์เล็ก เพื่อให้วัตถุดิบกระจายไปตาม Inscriber ได้ดีกว่า (แทนที่ตัวแรกจะเต็ม 64
ส่วนตัวอื่นว่างเปล่า)

Circuit Press ทั้ง 4 ใช้คราฟต์ [processor](processors.md)

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

ส่วน Name Press ใช้ตั้งชื่อบล็อกได้คล้ายทั่งตีเหล็ก มีประโยชน์ในการติดป้ายใน <ItemLink id="pattern_access_terminal" />

<ItemImage id="name_press" scale="4" />

## การตั้งค่า

* ตั้งให้ Inscriber แยกตามด้าน (อธิบายด้านล่าง) หรือรับของเข้าช่องใดก็ได้จากทุกด้านก็ได้ โดยมีตัวกรองภายใน
    ตัดสินว่าอะไรเข้าช่องไหน ในโหมดไม่แยกด้าน ดึงไอเทมออกจากช่องบนและล่างไม่ได้
* ตั้งให้ Inscriber ส่งไอเทมเข้าช่องเก็บที่อยู่ติดกันได้
* ปรับขนาดบัฟเฟอร์ขาเข้าได้ ตัวเลือกใหญ่เหมาะกับ Inscriber เดี่ยวที่คุณป้อนเอง
ตัวเลือกเล็กช่วยให้ระบบขนานขนาดใหญ่ใช้งานได้จริงมากขึ้น

## GUI และการแยกตามด้าน

ในโหมดแยกตามด้าน Inscriber จะกรองว่าอะไรเข้าช่องไหนตามด้านที่คุณใส่หรือดึงออก

![Inscriber GUI](../assets/diagrams/inscriber_gui.png) ![Inscriber Sides](../assets/diagrams/inscriber_sides.png)

A. **ช่องใส่ด้านบน** เข้าถึงผ่านด้านบนของ Inscriber (ใส่ไอเทมเข้าและดึงออกจากช่องนี้ได้ทั้งคู่)

B. **ช่องใส่ตรงกลาง** ใส่ผ่านด้านซ้าย ขวา หน้า และหลังของ Inscriber (ใส่ไอเทมเข้าช่องนี้ได้อย่างเดียว ดึงออกไม่ได้)

C. **ช่องใส่ด้านล่าง** เข้าถึงผ่านด้านล่างของ Inscriber (ใส่ไอเทมเข้าและดึงออกจากช่องนี้ได้ทั้งคู่)

D. **ช่องผลลัพธ์** ดึงออกผ่านด้านซ้าย ขวา หน้า และหลังของ Inscriber (ดึงไอเทมออกจากช่องนี้ได้อย่างเดียว ใส่เข้าไม่ได้)

## ออโต้แบบง่าย

ตัวอย่างเช่น การแยกตามด้านและการหมุนได้ ทำให้คุณทำออโต้ Inscriber แบบกึ่งอัตโนมัติได้ดังนี้

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

หรือจะต่อท่อเข้าและออกจาก Inscriber ตรง ๆ ในโหมดไม่แยกด้านก็ได้

## อัปเกรด

Inscriber รองรับ[การ์ดอัปเกรด](upgrade_cards.md) ดังนี้

*   <ItemLink id="speed_card" />

## สูตรคราฟต์

<RecipeFor id="inscriber" />
