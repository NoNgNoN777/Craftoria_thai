---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Meteorite Compass
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# Meteorite Compass

<ItemImage id="meteorite_compass" scale="4" />

Meteorite Compass ชี้ไปที่ <ItemLink id="mysterious_cube" /> ที่ใกล้ที่สุด ซึ่งก็คือชี้ไปที่
[meteorite](../ae2-mechanics/meteorites.md) ที่ใกล้ที่สุด เป็นหนึ่งในไอเทม AE2 ชิ้นแรก ๆ ที่คุณควรทำ

## สูตรคราฟต์

<RecipeFor id="meteorite_compass" />
