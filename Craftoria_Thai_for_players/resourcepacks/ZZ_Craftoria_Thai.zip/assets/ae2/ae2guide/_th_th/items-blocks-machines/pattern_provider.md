---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pattern Provider
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# Pattern Provider

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Pattern provider เป็นช่องทางหลักที่ระบบ [autocrafting](../ae2-mechanics/autocrafting.md) ใช้ติดต่อกับโลกภายนอก มันส่งวัตถุดิบใน [pattern](patterns.md) ไปยังช่องเก็บของที่อยู่ติดกัน และรับไอเทมเข้าสู่เครือข่ายได้ บ่อยครั้งประหยัด channel ได้ด้วยการต่อท่อผลลัพธ์ของเครื่องจักรกลับเข้า pattern provider ที่อยู่ใกล้ ๆ (มักเป็นตัวที่ส่งวัตถุดิบมา) แทนการใช้ <ItemLink id="import_bus" /> ดึงผลลัพธ์ของเครื่องจักรเข้าเครือข่าย

ข้อสังเกต เนื่องจากมันส่งวัตถุดิบตรงจาก [crafting storage](crafting_cpu_multiblock.md#crafting-storage) ใน crafting CPU ในช่องเก็บของของมันจึงไม่เคยมีวัตถุดิบจริง คุณจึงต่อท่อดึงออกจากมันไม่ได้ ต้องให้ provider ส่งไปยังช่องเก็บของอื่น (เช่น Barrel) แล้วต่อท่อดึงจากตรงนั้น

อีกข้อ provider ต้องส่งวัตถุดิบ ทั้งหมด พร้อมกันในครั้งเดียว ส่งครึ่งชุดไม่ได้ ซึ่งนำไปใช้ประโยชน์ได้

Pattern provider มีปฏิสัมพันธ์พิเศษกับ interface บน [subnet](../ae2-mechanics/subnetworks.md) หาก interface ไม่ได้ปรับแต่ง (ช่องคำขอว่าง) provider จะข้าม interface ไปเลย และส่งตรงเข้า [storage](../ae2-mechanics/import-export-storage.md) ของ subnet นั้น โดยไม่เติมชุดสูตรลงใน interface และที่สำคัญกว่าคือ จะไม่ส่งชุดถัดไป จนกว่าเครื่องจักรจะมีที่ว่าง ใช้ร่วมกับ blocking mode ได้ถูกต้อง provider จะตรวจช่องในเครื่องจักรว่ามีวัตถุดิบหรือไม่ แทนการตรวจช่องใน interface

ตัวอย่างเช่น ระบบนี้ส่งทั้งของที่จะหลอมและเชื้อเพลิงตรงเข้าช่องที่ตรงกันในเตาหลอม คุณใช้วิธีนี้ให้ pattern provider ส่งเข้าหลายด้านของเครื่องจักร หรือหลายเครื่องก็ได้

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: แบบกำหนดทิศทาง ทำได้ด้วย certus quartz wrench พร้อม pattern การประมวลผลที่เกี่ยวข้อง

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Storage Bus #1: กรองเฉพาะ Coal
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Storage Bus #2: กรองเป็น blacklist ของ Coal ด้วย inverter card
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ภาพนี้แสดงการส่งวัตถุดิบเข้าหลายเครื่องจักรโดยทั่วไป

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (ต้องเป็นแบบแบน ไม่ใช่บล็อกเต็ม)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        ตำแหน่งที่คุณต้องการให้ pattern provider ส่งวัตถุดิบเข้าไป
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

รองรับ pattern provider หลายตัวที่มี pattern เหมือนกัน และทำงานขนานกัน

Pattern provider จะพยายามส่งชุดวัตถุดิบสลับวนไปทุกด้านของมัน จึงใช้เครื่องจักรที่ต่ออยู่ทั้งหมดขนานกัน

## รูปแบบ

Pattern provider มี 3 รูปแบบ ได้แก่ แบบปกติ แบบกำหนดทิศทาง และแบบแบน/[subpart](../ae2-mechanics/cable-subparts.md) ซึ่งมีผลต่อด้านที่มันส่งวัตถุดิบไป รับไอเทมจาก และเป็นจุดเชื่อมต่อเครือข่าย

* Pattern provider แบบปกติส่งวัตถุดิบไปทุกด้าน รับอินพุตจากทุกด้าน และทำหน้าที่เหมือนสายเคเบิลที่ให้
    [การเชื่อมต่อเครือข่าย](../ae2-mechanics/me-network-connections.md) ทุกด้าน เหมือนเครื่องจักร AE2 ส่วนใหญ่

* Pattern provider แบบกำหนดทิศทางทำได้ด้วยการใช้ <ItemLink id="certus_quartz_wrench" /> กับแบบปกติเพื่อเปลี่ยนทิศ
    ส่งวัตถุดิบเฉพาะด้านที่เลือก รับอินพุตจากทุกด้าน และไม่ให้
  [การเชื่อมต่อเครือข่าย](../ae2-mechanics/me-network-connections.md) ที่ด้านที่เลือก ทำให้ส่งเข้าเครื่องจักร AE2 ได้โดยไม่ต่อเครือข่ายเข้าด้วยกัน หากต้องการทำ subnetwork

* Pattern provider แบบแบนเป็น [cable subpart](../ae2-mechanics/cable-subparts.md) จึงวางหลายตัวบนสายเดียวกันได้ ทำให้จัดวางได้กะทัดรัด
    ทำงานคล้ายด้านที่เลือกของแบบกำหนดทิศทาง คือจ่าย pattern รับอินพุต และ**ไม่**
    ให้[การเชื่อมต่อเครือข่าย](../ae2-mechanics/me-network-connections.md) ที่ด้านหน้า

สลับ pattern provider ระหว่างแบบปกติกับแบบแบนได้ในช่องคราฟต์

## การตั้งค่า

Pattern provider มีหลายโหมด

*   **Blocking Mode** ทำให้ provider ไม่ส่งชุดวัตถุดิบชุดใหม่ หากในเครื่องจักรยังมี
    วัตถุดิบอยู่
*   **Lock Crafting** ล็อก provider ภายใต้เงื่อนไข redstone ต่าง ๆ หรือจนกว่าผลลัพธ์ของ
    การคราฟต์ครั้งก่อนจะถูกส่งกลับเข้า pattern provider ตัวนั้น
*   แสดงหรือซ่อน provider บน <ItemLink id="pattern_access_terminal" /> ได้

## ลำดับความสำคัญ

ตั้งลำดับความสำคัญได้ด้วยการคลิกไอคอนประแจที่มุมขวาบนของ GUI หากมี [pattern](patterns.md) สำหรับไอเทมเดียวกันหลายอัน pattern ใน provider ที่มีลำดับสูงกว่าจะถูกใช้ก่อน pattern ใน provider ที่มีลำดับต่ำกว่า เว้นแต่เครือข่ายไม่มีวัตถุดิบสำหรับ pattern ลำดับสูงกว่า

## ความเข้าใจผิดที่พบบ่อย

ไม่รู้ทำไมผู้เล่นถึงทำแบบนี้กันบ่อย ไม่เข้าใจเหมือนกัน แต่ใส่ไว้ตรงนี้หวังว่าจะช่วยได้ (บางทีผู้เล่นอาจเข้าใจผิดว่า <ItemLink id="export_bus" /> เป็นทางเดียวที่ของจะออกจากเครือข่าย โดยไม่รู้ว่า pattern provider ก็ส่งของออกได้เช่นกัน)

แบบนี้จะไม่ได้ผลตามที่คุณต้องการ ตามที่กล่าวไว้ใน [สายเคเบิล](cables.md) สายเคเบิลไม่ใช่ท่อส่งไอเทม ไม่มีช่องเก็บของในตัว และ provider จะไม่ส่งของเข้าไปในสาย

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        ไม่ใช่ Blast Furnace
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

เนื่องจาก provider ไม่มีที่ให้ส่งของเข้าไป จึงทำงานไม่ได้ สิ่งที่มันทำตรงนี้มีเพียงทำหน้าที่เหมือนสายเคเบิล เชื่อม <ItemLink id="export_bus" /> เข้ากับเครือข่าย

Provider ไม่ได้บอก <ItemLink id="export_bus" /> ว่าต้องส่งออกอะไร export bus จะส่งออกทุกอย่างที่คุณใส่ไว้ในช่องกรองเท่านั้น

สิ่งที่เราทำไว้ตรงนี้โดยสรุปคือแบบนี้

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        ไม่ใช่ Blast Furnace
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

สิ่งที่คุณน่าจะต้องการจริง ๆ คือแบบนี้ ที่ pattern provider ส่งเนื้อหาใน pattern ของมันเข้าเครื่องจักรที่อยู่ติดกัน

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        ไม่ใช่ Blast Furnace
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## การใช้กับ Molecular Assembler

<ItemLink id="molecular_assembler" /> ก็เหมือนเครื่องจักรทั่วไป มีช่องเก็บของที่ใส่ของเข้าได้ แล้วทำงานกับของในช่องนั้น
และเหมือนเครื่องจักรหลายแบบ มันส่งผลลัพธ์ไปยังช่องเก็บของที่อยู่ติดกัน
จึงควรใช้กับ provider เหมือนเครื่องจักรอื่น โดยมีข้อเพิ่มเติมหนึ่งข้อ

Assembler ดึง pattern ที่ต้องการจาก <ItemLink id="crafting_pattern" />, <ItemLink id="smithing_table_pattern" /> หรือ <ItemLink id="stonecutting_pattern" />
ที่ใส่ไว้ใน assembler โดยตรงได้
วิธีนี้มีประโยชน์ในสายการผลิต แต่การต้องมี assembler เฉพาะสำหรับแต่ละสูตรคราฟต์ก็น่ารำคาญ

ด้วยเหตุนี้ pattern provider จึงมีความสามารถพิเศษกับ assembler คือส่งข้อมูล pattern ไปพร้อมกับวัตถุดิบได้ คุณจึงวาง assembler ไว้ข้าง pattern provider แล้ว provider จะใช้ assembler นั้นกับ pattern คราฟต์ smithing และ stonecutting ทั้งหมดของมัน

ง่ายขนาดนี้เลย แค่ใส่ pattern ลงใน provider

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*สังเกตว่ามี provider 8 ตัวพอดี ซึ่งเป็นจำนวน channel สูงสุดที่ส่งผ่าน assembler, provider หรือสายแบบไม่ใช่ dense ได้ในเส้นเดียว*

## สูตรคราฟต์

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
