---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Processor
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# Processor

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

Processor เป็นวัตถุดิบหลักอย่างหนึ่งของ [อุปกรณ์](../ae2-mechanics/devices.md) และเครื่องจักร AE2 และยังเป็นความท้าทายด้านระบบอัตโนมัติด่านใหญ่ด่านแรก ๆ ของคุณ มี processor 3 ชนิด ทำจากทอง <ItemLink id="certus_quartz_crystal" /> และเพชรตามลำดับ ผลิตด้วย [press](presses.md) ใน <ItemLink id="inscriber" /> ผ่านหลายขั้นตอน (ส่วนใหญ่ทำด้วย inscriber หลายตัวต่อกับท่อที่มีตัวกรอง)

## ขั้นตอนการผลิต

<Column gap="5">
  1.  รวบรวมหรือทำวัตถุดิบที่ต้องใช้ ได้แก่ silicon, redstone, ทอง, <ItemLink id="certus_quartz_crystal" /> และเพชร

  <RecipeFor id="silicon" />

  <br />

  2.  กด printed circuit component ที่ต้องใช้ก่อน

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

  3.  ประกอบขั้นสุดท้าย

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>
