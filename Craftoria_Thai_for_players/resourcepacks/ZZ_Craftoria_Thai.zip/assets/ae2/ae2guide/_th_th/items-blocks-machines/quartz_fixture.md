---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Quartz Fixtures
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# Quartz Fixtures

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

Charged quartz fixture เป็นของตกแต่งชิ้นเล็กที่เปล่งแสง

ส่วน light detecting fixture จะปล่อยสัญญาณเรดสโตนตามระดับแสงของบล็อกที่มันอยู่

## สูตรคราฟต์

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
