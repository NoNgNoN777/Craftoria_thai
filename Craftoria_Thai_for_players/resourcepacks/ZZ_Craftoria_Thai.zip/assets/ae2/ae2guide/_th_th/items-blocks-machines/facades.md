---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Facades
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Facades

Facade ใช้ทำให้ฐานของคุณดูเรียบร้อยขึ้น ปิดบังสายเคเบิลได้ทั้งสองขนาด และทำจากบล็อกได้
หลายชนิด

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ปิดได้ทุกด้านของสายเคเบิล แต่จะให้ [subpart](../ae2-mechanics/cable-subparts.md) และจุดเชื่อมต่อของสายเคเบิล
โผล่ออกมา

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ใช้อย่างชาญฉลาดเพื่อเพิ่มความสวยงามให้ฐานของคุณ หรือทำบล็อกที่มีเท็กซ์เจอร์ต่างกันในแต่ละด้าน

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## ซ่อน Facade

Facade จะถูกซ่อนขณะถือ <a href="network_tool.md">Network Tool</a> ไว้ในมือข้างใดข้างหนึ่ง

คุณโต้ตอบกับบล็อกที่อยู่หลัง Facade ที่ซ่อนอยู่ได้โดยไม่ต้องรื้อ Facade ออกก่อน

## สูตรคราฟต์

วางบล็อกที่ต้องการเท็กซ์เจอร์ไว้ตรงกลางของ <ItemLink id="cable_anchor" /> 4 ชิ้น

![Facade Recipe](../assets/diagrams/facade_recipe.png)
