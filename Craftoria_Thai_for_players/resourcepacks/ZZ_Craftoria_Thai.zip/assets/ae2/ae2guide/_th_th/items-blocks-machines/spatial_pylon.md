---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Pylon
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# Spatial Pylon

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

Spatial Pylon ใช้ใน [spatial IO](../ae2-mechanics/spatial-io.md) เพื่อสร้างสนามมิติและกำหนดปริมาตรที่จะได้รับผลกระทบ

Pylon แต่ละแนวต่อเนื่องใช้ 1 [channel](../ae2-mechanics/channels.md)

แนว Pylon ต้องยาวอย่างน้อย 2 บล็อกจึงจะทำงาน

## สูตรคราฟต์

<RecipeFor id="spatial_pylon" />