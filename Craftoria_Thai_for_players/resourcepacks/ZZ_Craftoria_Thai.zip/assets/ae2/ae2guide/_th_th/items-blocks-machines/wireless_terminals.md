---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Wireless Terminals
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
---

# Wireless Terminal

<ItemImage id="wireless_terminal" scale="4" />


Wireless Terminal คือ[เทอร์มินัล](terminals.md)แบบมีสายที่พกพาได้ หน้าจอ UI เหมือนรุ่นมีสายทุกอย่าง ต่างกันที่แทนช่องสำหรับ <ItemLink id="view_cell" /> จะมีช่องสำหรับ[การ์ดอัปเกรด](upgrade_cards.md)

หากต้องการจับคู่กับเครือข่าย ให้ใส่เทอร์มินัลในช่องบนขวาของ <ItemLink id="wireless_access_point" /> ที่ต่อกับเครือข่ายนั้น
(ช่องที่มีรูป Wireless Terminal และลูกศรอยู่ด้านล่าง)

ต้องอยู่ในระยะของ <ItemLink id="wireless_access_point" /> จึงจะใช้งานได้

ชาร์จพลังงานได้ใน <ItemLink id="charger" />

# Wireless Terminal

<ItemImage id="wireless_terminal" scale="4" />

เทอร์มินัลพื้นฐานของคุณ แต่พกพาได้แล้ว! ดูและเข้าถึงของใน[ที่เก็บของเครือข่าย](../ae2-mechanics/import-export-storage.md)
และสั่งของจากระบบ[คราฟต์อัตโนมัติ](../ae2-mechanics/autocrafting.md)ได้จากทุกที่ในระยะของ
<ItemLink id="wireless_access_point" />

## UI

ดู [Terminals](terminals.md)

## อัปเกรด

Wireless Terminal รองรับ[อัปเกรด](upgrade_cards.md)ต่อไปนี้:

*   <ItemLink id="energy_card" /> เพิ่มความจุแบตเตอรี่

## สูตรคราฟต์

<RecipeFor id="wireless_terminal" />

# Wireless Crafting Terminal

<ItemImage id="wireless_crafting_terminal" scale="4" />

[AE2WTLib](ae2wtlib:ae2wtlib/ae2wtlib-index.md) เปลี่ยนการทำงานของ <ItemLink id="ae2:wireless_crafting_terminal" />
วิธีใช้ย้ายไปอยู่ที่[หน้าอื่น](ae2wtlib:ae2wtlib/wireless_crafting_terminal.md)แล้ว
