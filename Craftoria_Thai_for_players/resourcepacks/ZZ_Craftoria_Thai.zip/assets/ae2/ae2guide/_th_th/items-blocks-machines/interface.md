---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Interface
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# Interface

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

Interface ทำงานเหมือนหีบและถังของเหลวขนาดเล็ก ที่เติมตัวเองจากและระบายออกไปยัง [network storage](../ae2-mechanics/import-export-storage.md)
ตามสิ่งที่คุณตั้งให้เก็บสต็อกไว้ในช่อง โดยทำให้เสร็จภายใน gametick เดียว จึงเติมหรือระบายได้สูงสุด 9 สแตกต่อ gametick
เหมาะเป็นวิธีนำเข้าหรือส่งออกที่เร็ว หากคุณมีท่อไอเทมที่เร็วพอ

อีกข้อดีคือ ถังของเหลวส่วนใหญ่เก็บของเหลวได้ 1 ชนิด แต่ Interface เก็บได้สูงสุด 9 ชนิด รวมถึงไอเทมด้วย
โดยพื้นฐานมันคือหีบหรือถังหลายของเหลวที่มีฟังก์ชันเสริม และคุณปิดฟังก์ชันเสริมนั้นได้ ด้วยการไม่ต่อเข้ากับเครือข่ายใด ๆ
จึงมีประโยชน์ในบางกรณี ที่คุณต้องการเก็บของหลายอย่างในปริมาณน้อย

## การทำงานภายในของ Interface

ดังที่กล่าวไว้ Interface คือหีบหรือถังที่ติด <ItemLink id="import_bus" /> และ
<ItemLink id="export_bus" /> สุดแรงจำนวนหนึ่ง พร้อม <ItemLink id="level_emitter" /> อีกหลายตัว

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        Level Emitter หลายตัวเพื่อควบคุมปริมาณสต็อกที่ต้องการ
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        Level Emitter หลายตัวเพื่อควบคุมปริมาณสต็อกที่ต้องการ
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        Import Bus สุดแรงหลายตัว ย้ายได้ 1 สแตกต่อ gametick
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        Export Bus สุดแรงหลายตัว ย้ายได้ 1 สแตกต่อ gametick
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        ช่องเก็บภายในแยกกัน 9 ช่อง
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## Special Interactions

Interface ยังมีความสามารถพิเศษเมื่อใช้กับ [อุปกรณ์](../ae2-mechanics/devices.md) AE2 อื่น ๆ

<ItemLink id="storage_bus" /> ที่วางบน Interface ซึ่งยังไม่ได้ตั้งค่า จะเปิดเผย [network storage](../ae2-mechanics/import-export-storage.md) ทั้งหมดของเครือข่ายนั้นให้เครือข่ายของ Storage Bus
เหมือนเครือข่ายของ Interface เป็นหีบใบใหญ่ใบเดียวที่ Storage Bus วางอยู่
การตั้งไอเทมให้เก็บสต็อกในช่องกรองของ Interface จะปิดพฤติกรรมนี้

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Pattern Provider มีปฏิสัมพันธ์พิเศษกับ Interface บน [subnet](../ae2-mechanics/subnetworks.md) ถ้า Interface ยังไม่ได้ตั้งค่า
Provider จะข้าม Interface ไปเลยและส่งตรงเข้า [storage](../ae2-mechanics/import-export-storage.md) ของ subnet นั้น
โดยไม่เติมชุดวัตถุดิบของสูตรลง Interface และที่สำคัญกว่านั้นคือ จะไม่ส่งชุดถัดไปจนกว่า storage จะมีที่ว่าง

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (ต้องเป็นแบบแบน ไม่ใช่แบบเต็มบล็อก)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        จุดที่คุณต้องการส่ง pattern ไป (เครื่องหลายเครื่อง หรือหลายด้านของ 1 เครื่อง)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## รูปแบบ

Interface มี 2 รูปแบบ คือแบบปกติ และแบบแบน/[subpart](../ae2-mechanics/cable-subparts.md) ซึ่งต่างกันที่ด้านที่เข้าถึงช่องเก็บได้
และด้านที่ให้การเชื่อมต่อเครือข่าย

*   Interface แบบปกติให้ส่งเข้า ดึงออก และเข้าถึงช่องเก็บได้จากทุกด้าน และเหมือนเครื่อง AE2 ส่วนใหญ่ คือทำหน้าที่
    เหมือนสายเคเบิลที่ให้การเชื่อมต่อเครือข่ายทุกด้าน

*   Interface แบบแบนเป็น [cable subpart](../ae2-mechanics/cable-subparts.md) จึงวางหลายตัวบนสายเดียวกันได้ ทำให้จัดวางได้กะทัดรัด
    ให้ส่งเข้า ดึงออก และเข้าถึงช่องเก็บได้จากด้านหน้า แต่ไม่ให้การเชื่อมต่อเครือข่ายที่ด้านหน้า

สลับ Interface ระหว่างแบบปกติและแบบแบนได้ในโต๊ะคราฟต์

## การตั้งค่า

ช่องด้านบนของ Interface กำหนดสิ่งที่ Interface จะเก็บสต็อกไว้ภายใน เมื่อวางไอเทมลงในช่อง
หรือลากมาจาก JEI/REI จะมีประแจปรากฏขึ้นให้ตั้งปริมาณ

คลิกขวาด้วยภาชนะของเหลว (เช่น ถังหรือ fluid tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรองแทนที่จะเป็นไอเทมถังหรือ tank

เมื่อคุณตั้งช่องเป็นโหมดเก็บสต็อก ช่องนั้นจะป้องกันไม่ให้เครื่องภายนอกใส่สิ่งอื่นเข้ามาด้วย

## อัปเกรด

Interface รองรับ [การ์ดอัปเกรด](upgrade_cards.md) ดังนี้

*   <ItemLink id="fuzzy_card" /> ให้ Bus กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="crafting_card" /> ให้ Interface ส่งคำขอคราฟต์ไปยังระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
    เพื่อให้ได้ไอเทมที่ต้องการ โดยจะดึงไอเทมจาก storage ก่อนถ้าทำได้ แล้วจึงขอ
    ให้คราฟต์ไอเทมใหม่

## ลำดับความสำคัญ

ตั้งลำดับความสำคัญได้โดยคลิกประแจที่มุมขวาบนของ GUI Interface ที่มีลำดับสูงกว่าจะได้รับไอเทมก่อน Interface ที่ลำดับต่ำกว่า

## สูตรคราฟต์

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
