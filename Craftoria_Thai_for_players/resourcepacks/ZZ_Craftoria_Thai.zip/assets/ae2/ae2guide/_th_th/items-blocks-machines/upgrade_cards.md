---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: การ์ดอัปเกรด
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# การ์ดอัปเกรด

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

การ์ดอัปเกรดเปลี่ยนพฤติกรรมของ[อุปกรณ์](../ae2-mechanics/devices.md)และเครื่องจักร AE2 เพิ่มความเร็ว เพิ่มความจุตัวกรอง เปิดใช้การควบคุมด้วยเรดสโตน ฯลฯ

## ส่วนประกอบของการ์ด

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

การ์ดคราฟต์จากฐานการ์ดแบบพื้นฐานหรือแบบขั้นสูง

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## Redstone Card

<ItemImage id="redstone_card" scale="2" />

Redstone Card เพิ่มการควบคุมด้วยเรดสโตน โดยเพิ่มปุ่มสลับใน GUI ของอุปกรณ์เพื่อเปลี่ยนระหว่างเงื่อนไขเรดสโตนต่าง ๆ

<RecipeFor id="redstone_card" />

## Capacity Card

<ItemImage id="capacity_card" scale="2" />

Capacity Card เพิ่มจำนวนช่องกรองใน Import Bus, Export Bus, Storage Bus และ Formation Plane

<RecipeFor id="capacity_card" />

## Overflow Destruction Card

<ItemImage id="void_card" scale="2" />

ใส่ Overflow Destruction Card ให้ [storage cell](storage_cells.md) ใน <ItemLink id="cell_workbench" /> ได้
และจะลบไอเทมที่เข้ามาทิ้งเมื่อ cell เต็ม (อย่าลืม[กำหนด partition](cell_workbench.md) ให้ cell ของคุณ) หากใช้ร่วมกับ Equal Distribution Card
ไอเทมจะถูกทิ้งเมื่อส่วนของไอเทมชนิดนั้นใน cell เต็ม แม้ส่วนของไอเทมอื่นจะยังว่างอยู่

<RecipeFor id="void_card" />

## Fuzzy Card

<ItemImage id="fuzzy_card" scale="2" />

Fuzzy Card ให้อุปกรณ์และเครื่องมือที่มีตัวกรองกรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม ทำให้คุณส่งออกขวานเหล็กทั้งหมดได้ไม่ว่าจะเสียหายแค่ไหนหรือมีเอนชานต์อะไร หรือส่งออกเฉพาะดาบเพชรที่เสียหาย ไม่เอาที่ซ่อมเต็มแล้ว

ตัวอย่างด้านล่างแสดงการทำงานของโหมดเปรียบเทียบความเสียหายแบบ Fuzzy ด้านซ้ายคือค่าที่ตั้งของ Bus
ด้านบนคือไอเทมที่ถูกเปรียบเทียบ

| 25%                    | Pickaxe เสียหาย 10% | Pickaxe เสียหาย 30% | Pickaxe เสียหาย 80% | Pickaxe ซ่อมเต็ม |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Pickaxe ใกล้พัง  | ✅                   | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| Pickaxe ซ่อมเต็ม | \*\*\*\*            | ✅                   | ✅                   | ✅                   |

| 50%                    | Pickaxe เสียหาย 10% | Pickaxe เสียหาย 30% | Pickaxe เสียหาย 80% | Pickaxe ซ่อมเต็ม |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Pickaxe ใกล้พัง  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Pickaxe ซ่อมเต็ม | \*\*\*\*            | \*\*\*\*            | ✅                   | ✅                   |

| 75%                    | Pickaxe เสียหาย 10% | Pickaxe เสียหาย 30% | Pickaxe เสียหาย 80% | Pickaxe ซ่อมเต็ม |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Pickaxe ใกล้พัง  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Pickaxe ซ่อมเต็ม | \*\*\*\*            |                     | ✅                   | ✅                   |

| 99%                    | Pickaxe เสียหาย 10% | Pickaxe เสียหาย 30% | Pickaxe เสียหาย 80% | Pickaxe ซ่อมเต็ม |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Pickaxe ใกล้พัง  | ✅                   | ✅                   | ✅                   | \*\*\*\*            |
| Pickaxe ซ่อมเต็ม | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| ไม่สนใจ                | Pickaxe เสียหาย 10% | Pickaxe เสียหาย 30% | Pickaxe เสียหาย 80% | Pickaxe ซ่อมเต็ม |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| Pickaxe ใกล้พัง  | ✅                   | ✅                   | ✅                   | **✅**               |
| Pickaxe ซ่อมเต็ม | **✅**               | **✅**               | **✅**               | ✅                   |

<RecipeFor id="fuzzy_card" />

## Acceleration Card

<ItemImage id="speed_card" scale="2" />

Acceleration Card ทำให้ทุกอย่างเร็วขึ้น โดยให้ Import Bus และ Export Bus ย้ายไอเทมได้มากขึ้นต่อการทำงานหนึ่งครั้ง และให้ Inscriber กับ Assembler ทำงานเร็วขึ้น

<RecipeFor id="speed_card" />

## Inverter Card

<ItemImage id="inverter_card" scale="2" />

Inverter Card สลับตัวกรองในอุปกรณ์และเครื่องมือจาก whitelist เป็น blacklist

<RecipeFor id="inverter_card" />

## Crafting Card

<ItemImage id="crafting_card" scale="2" />

Crafting Card ให้อุปกรณ์ส่งคำขอคราฟต์ไปยังระบบ [autocrafting](../ae2-mechanics/autocrafting.md) ของคุณ
เพื่อให้ได้ไอเทมที่ต้องการ

<RecipeFor id="crafting_card" />

## Equal Distribution Card

<ItemImage id="equal_distribution_card" scale="2" />

ใส่ Equal Distribution Card ให้ [storage cell](storage_cells.md) ใน <ItemLink id="cell_workbench" /> ได้ และ
การ์ดจะแบ่ง cell เป็นส่วนขนาดเท่า ๆ กัน ตามไอเทมที่ [partition](cell_workbench.md) ไว้ ช่วยป้องกันไม่ให้ไอเทมชนิดเดียว
เติม cell จนเต็ม

<RecipeFor id="equal_distribution_card" />

## Energy Card

<ItemImage id="energy_card" scale="2" />

Energy Card เพิ่มความจุพลังงานให้เครื่องมือบางอย่าง เช่น Portable Terminal และทำให้ <ItemLink id="vibration_chamber" />
มีประสิทธิภาพขึ้น

<RecipeFor id="energy_card" />
