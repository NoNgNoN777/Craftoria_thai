---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Condenser
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# Matter Condenser

<BlockImage id="condenser" scale="8" />

Matter condenser ใช้เป็นถังขยะ หรือใช้สร้าง <ItemLink id="matter_ball" /> และ
[singularity](singularities.md) ก็ได้ รับไอเทม ของเหลว ฯลฯ ได้ทุกอย่างที่ storage cell เก็บได้

## การตั้งค่า/สูตรคราฟต์

*   ในโหมดถังขยะ matter condenser จะทิ้งทุกอย่างที่เข้าไป
*   ในโหมด matter ball condenser จะสร้าง <ItemLink id="matter_ball" /> จากทุกอย่างที่คุณใส่เข้าไป
    โหมดนี้ต้องใส่ storage component ในช่องบนของ condenser Matter ball ใช้ไอเทมหรือถัง 256 หน่วย
    ต่อลูก ดังนั้น <ItemLink id="cell_component_1k" /> (ความจุ 8192 บิต) ก็เกินพอ
*   ในโหมด matter singularity condenser จะสร้าง [singularity](singularities.md) จากทุกอย่างที่คุณใส่เข้าไป
    โหมดนี้ต้องใส่ storage component ในช่องบนของ condenser Singularity ใช้ไอเทมหรือถัง 256,000 หน่วย
    ต่อลูก ดังนั้น <ItemLink id="cell_component_64k" /> (ความจุ 524,288 บิต) ก็เกินพอ

โปรดทราบว่าในสองโหมดหลังที่ผลิตทรัพยากรออกมา Matter Condenser *อาจ* ค้างได้ และ
จะไม่รับของเข้าเพิ่มถ้าบัฟเฟอร์พลังงานและบัฟเฟอร์ไอเทมผลลัพธ์เต็มทั้งคู่

## สูตรคราฟต์

<RecipeFor id="condenser" />
