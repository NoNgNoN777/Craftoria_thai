---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cell Workbench
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# Cell Workbench

<BlockImage id="cell_workbench" scale="8" />

Cell Workbench ให้คุณตั้งค่า [storage cell](storage_cells.md) และ <ItemLink id="view_cell" />

คุณเพิ่ม [upgrade card](upgrade_cards.md) และตั้งค่า "partition" เพื่อกรองสิ่งที่ cell จะเก็บได้

ลากไอเทมและของเหลวจาก JEI/REI ใส่ช่องได้ แม้คุณจะไม่มีไอเทมนั้นอยู่จริง

คลิกขวาด้วยภาชนะของเหลว (เช่น Bucket หรือ Fluid Tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรอง แทนการตั้งเป็นตัวถังเอง

## การตั้งค่า

Cell workbench มีปุ่มอยู่ไม่กี่ปุ่มที่มุมซ้ายบน

*   ตั้ง partition ของ cell ตามสิ่งที่มีอยู่ข้างในได้
*   ล้าง partition ของ cell ได้
*   ตั้งให้ workbench คงค่า partition ไว้เมื่อถอด cell ออก เพื่อคัดลอกการตั้งค่าระหว่าง cell ได้

## สูตรคราฟต์

<RecipeFor id="cell_workbench" />
