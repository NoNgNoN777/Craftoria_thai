---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pattern
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# Pattern

<ItemImage id="crafting_pattern" scale="4" />

สร้าง pattern ใน <ItemLink id="pattern_encoding_terminal" /> จาก blank pattern แล้วใส่ใน <ItemLink id="pattern_provider" /> หรือ <ItemLink id="molecular_assembler" />

pattern มีหลายชนิดสำหรับงานต่างกัน

*   <ItemLink id="crafting_pattern" /> เข้ารหัสสูตรที่ทำในโต๊ะคราฟต์ ใส่ตรง ๆ ใน <ItemLink id="molecular_assembler" /> เพื่อให้คราฟต์ผลลัพธ์ทุกครั้งที่ได้รับวัตถุดิบ
    แต่ใช้หลัก ๆ ใน <ItemLink id="pattern_provider" /> ที่อยู่ข้าง molecular assembler
    Pattern provider มีพฤติกรรมพิเศษในกรณีนี้ คือส่ง pattern ที่เกี่ยวข้องไปพร้อมวัตถุดิบให้ assembler ที่อยู่ติดกัน
    เนื่องจาก assembler ดีดผลลัพธ์ที่คราฟต์เสร็จเข้าช่องเก็บของข้างเคียงเอง การมี assembler ติดกับ pattern provider จึงเพียงพอสำหรับคราฟต์อัตโนมัติ

***

*   <ItemLink id="smithing_table_pattern" /> คล้าย crafting pattern มาก แต่เข้ารหัสสูตรของ Smithing Table ทำงานอัตโนมัติด้วย pattern
    provider และ molecular assembler เช่นกัน และทำงานแบบเดียวกันทุกประการ จริง ๆ แล้ว crafting, smithing และ stonecutting pattern
    ใช้ในระบบเดียวกันได้

***

*   <ItemLink id="stonecutting_pattern" /> คล้าย crafting pattern มาก แต่เข้ารหัสสูตรของ Stonecutter ทำงานอัตโนมัติด้วย pattern
    provider และ molecular assembler เช่นกัน และทำงานแบบเดียวกันทุกประการ จริง ๆ แล้ว crafting, smithing และ stonecutting pattern
    ใช้ในระบบเดียวกันได้

***

*   <ItemLink id="processing_pattern" /> คือแหล่งความยืดหยุ่นส่วนใหญ่ของ autocrafting เป็นชนิดที่ครอบคลุมที่สุด บอกเพียงว่า
    "หาก pattern provider ส่งวัตถุดิบเหล่านี้ไปยังช่องเก็บของข้างเคียง ระบบ ME จะได้รับไอเทมเหล่านี้ในอนาคตอันใกล้หรือไกล"
    ใช้ autocraft กับเครื่องจักรม็อดเกือบทุกชนิด หรือเตาหลอมและอื่น ๆ ได้ เพราะใช้งานได้กว้างมาก
    และไม่สนว่าระหว่างส่งวัตถุดิบกับรับผลลัพธ์เกิดอะไรขึ้น คุณจึงทำอะไรแปลก ๆ ได้ เช่น ป้อนวัตถุดิบเข้าสายการผลิตของโรงงานซับซ้อนทั้งสาย
    ที่คัดแยกของ รับวัตถุดิบอื่นจากฟาร์มที่ผลิตไม่รู้จบ
    พิมพ์บทหนังเรื่อง Bee Movie ทั้งเรื่อง ระบบ ME ไม่สนใจ ขอเพียงได้ผลลัพธ์ที่ pattern กำหนด จริง ๆ แล้ว
    มันไม่สนด้วยซ้ำว่าวัตถุดิบเกี่ยวข้องกับผลลัพธ์หรือไม่ คุณตั้งได้ว่า "Cherry Planks 1 ชิ้น = Nether Star 1 ชิ้น" แล้วให้
    ฟาร์ม Wither ของคุณฆ่า Wither เมื่อได้รับ Cherry Planks ก็ใช้งานได้

รองรับ <ItemLink id="pattern_provider" /> หลายตัวที่มี pattern เหมือนกัน และทำงานขนานกัน นอกจากนี้คุณตั้ง pattern ได้ เช่น Cobblestone 8 ก้อน = Stone 8 ก้อน แทน Cobblestone 1 ก้อน = Stone 1 ก้อน แล้ว pattern provider จะใส่ Cobblestone 8 ก้อนเข้าระบบหลอมของคุณในแต่ละครั้ง แทนการใส่ทีละก้อน

## สูตรคราฟต์

<RecipeFor id="blank_pattern" />
