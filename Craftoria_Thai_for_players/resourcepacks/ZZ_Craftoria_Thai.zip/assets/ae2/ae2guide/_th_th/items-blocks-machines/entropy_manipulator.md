---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Entropy Manipulator
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Entropy Manipulator

<ItemImage id="entropy_manipulator" scale="4" />

Entropy Manipulator ให้คุณเพิ่มความร้อนและความเย็นให้สิ่งต่าง ๆ โดยคลิกขวาและ Shift + คลิกขวาตามลำดับ ทำได้ไม่มากนัก
เช่น ระเหยหรือแช่แข็งน้ำ ทำลาวาให้เป็น Obsidian หลอมท่อนไม้เป็น Charcoal และหลอม Cobblestone เป็น Stone ในโลกได้

หากไม่มีสิ่งเฉพาะที่ทำกับบล็อกนั้นได้ จะทำงานเหมือน Flint and Steel

ชาร์จพลังงานได้ใน <ItemLink id="charger" />

## สูตรคราฟต์

<RecipeFor id="entropy_manipulator" />
