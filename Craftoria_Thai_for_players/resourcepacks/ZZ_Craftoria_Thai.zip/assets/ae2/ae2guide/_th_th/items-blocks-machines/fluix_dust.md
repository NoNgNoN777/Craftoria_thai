---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Dust
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Fluix Dust

<ItemImage id="fluix_dust" scale="4" />

<ItemLink id="fluix_crystal" /> ที่ถูกบดด้วย <ItemLink id="inscriber" /> ใช้ในการผลิตเครื่องจักรและชิ้นส่วน AE2
หลายอย่าง

## สูตรคราฟต์

<RecipeFor id="fluix_dust" />
