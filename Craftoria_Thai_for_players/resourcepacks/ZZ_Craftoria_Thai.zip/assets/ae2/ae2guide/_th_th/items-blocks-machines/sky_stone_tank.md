---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone Tank
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# Sky Stone Tank

<BlockImage id="sky_stone_tank" scale="8" />

ถังของเหลวที่เก็บได้ 16 บักเก็ต ไม่เก็บของเหลวข้างในไว้เมื่อหยิบขึ้นมา ไม่มีอะไรจะบอกเพิ่มอีก

## สูตรคราฟต์

<RecipeFor id="sky_stone_tank" />
