---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Storage Cells
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# Storage Cell

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

Storage Cell เป็นวิธีเก็บของหลักวิธีหนึ่งใน Applied Energistics ใส่ได้ใน <ItemLink id="drive" />
หรือ <ItemLink id="chest" />

ดู [Bytes and Types](../ae2-mechanics/bytes-and-types.md) เพื่ออ่านคำอธิบายความจุของ cell ในหน่วย byte และ type

ถอดชิ้นส่วนเก็บของออกจากตัวเรือนได้ หาก cell ว่างเปล่า โดยถือ cell ไว้ในมือแล้ว Shift + คลิกขวา

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    อัปเกรด storage cell เป็นระดับสูงขึ้นได้โดยนำไปรวมกับชิ้นส่วนเก็บของระดับสูงกว่าในโต๊ะคราฟต์ ของข้างในจะยังอยู่ และจะได้ชิ้นส่วนระดับเดิมคืนมา
</Row>

## ความจุเมื่อจำนวน Type ต่างกัน

[ต้นทุนล่วงหน้าของ type](../ae2-mechanics/bytes-and-types.md) ทำให้ cell ที่เก็บ 1 type เก็บได้มากกว่า cell ที่ใช้ครบทั้ง 63 type ถึง 2 เท่า

| Cell                                     | ความจุรวมของ Cell เมื่อใช้ 1 Type | ความจุรวมของ Cell เมื่อใช้ 63 Type |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |


## Partition

กรอง cell ให้รับเฉพาะไอเทมบางอย่างได้ เหมือนกับที่กรอง <ItemLink id="storage_bus" /> ได้ ทำได้ใน
<ItemLink id="cell_workbench" />

ลากไอเทมจาก JEI/REI ลงช่องได้ แม้คุณจะไม่มีไอเทมนั้นอยู่จริง

## อัปเกรด

Storage cell รองรับ[การ์ดอัปเกรด](upgrade_cards.md) ดังนี้ โดยใส่ผ่าน <ItemLink id="cell_workbench" />

*   <ItemLink id="fuzzy_card" /> (ใช้กับ fluid cell ไม่ได้) ให้ partition cell ตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="inverter_card" /> สลับตัวกรองจาก whitelist เป็น blacklist
*   <ItemLink id="equal_distribution_card" /> จัดสรรพื้นที่ byte ของ cell เท่ากันให้ทุก type เพื่อไม่ให้ type เดียวเติมเต็มทั้ง cell
*   <ItemLink id="void_card" /> ทิ้งไอเทมที่ใส่เข้ามาเมื่อ cell เต็ม (หรือเมื่อพื้นที่ที่จัดสรรให้ type นั้นเต็ม
    ในกรณีที่ใช้ Equal Distribution Card) มีประโยชน์ในการกันฟาร์มไม่ให้ค้าง ระวังให้ partition ด้วย
*   Portable cell ใส่ <ItemLink id="energy_card" /> ได้ เพื่อเพิ่มความจุแบตเตอรี่

## การย้อมสี

Portable item cell และ fluid cell ย้อมสีได้เหมือนเกราะหนัง โดยคราฟต์รวมกับสีย้อม

# Housing

สร้าง cell ได้จากชิ้นส่วนเก็บของกับ housing หรือใช้สูตร housing ล้อมรอบชิ้นส่วนเก็บของ

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

คราฟต์ housing เปล่า ๆ ได้ดังนี้

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# Storage Component

Storage Component คือแกนหลักของ cell AE2 ทุกชนิด และกำหนดความจุของ cell แต่ละระดับเพิ่มความจุ
ขึ้น 4 เท่า และใช้ระดับก่อนหน้า 3 ชิ้น

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# Item Storage Cell

Item storage cell เก็บไอเทมได้สูงสุด 63 type ที่ต่างกัน และมีให้ครบทุกความจุมาตรฐาน

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## Portable Item Storage

ทำงานเป็น <ItemLink id="chest" /> ขนาดจิ๋วในกระเป๋าของคุณ หรือเหมือนเป้สะพายหลัง ชาร์จได้ใน <ItemLink id="charger" />

ต่างจาก storage cell มาตรฐาน ตัวนี้ *ลด* จำนวน type ที่เก็บได้เมื่อความจุ byte เพิ่มขึ้น และมีความจุ byte รวม
เพียงครึ่งเดียว

นอกจากการ์ดอัปเกรดที่ cell ทุกชนิดรับได้ ตัวนี้ยังรับ <ItemLink id="energy_card" /> เพื่ออัปเกรดแบตเตอรี่ภายในด้วย

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# Fluid Storage Cell

Fluid storage cell เก็บของเหลวได้สูงสุด 5 type ที่ต่างกัน และมีให้ครบทุกความจุมาตรฐาน

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## Portable Fluid Storage

ทำงานเป็น <ItemLink id="chest" /> ขนาดจิ๋วในกระเป๋าของคุณ หรือเหมือนเป้สะพายหลัง ชาร์จได้ใน <ItemLink id="charger" />

ต่างจาก storage cell มาตรฐาน ตัวนี้ *ลด* จำนวน type ที่เก็บได้เมื่อความจุ byte เพิ่มขึ้น และมีความจุ byte รวม
เพียงครึ่งเดียว

นอกจากการ์ดอัปเกรดที่ cell ทุกชนิดรับได้ ตัวนี้ยังรับ <ItemLink id="energy_card" /> เพื่ออัปเกรดแบตเตอรี่ภายในด้วย

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# Creative Storage Cell

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

Creative cell **ไม่ได้ให้พื้นที่เก็บไม่จำกัด** แต่ทำหน้าที่เป็นแหล่งกำเนิดและที่ทิ้งไม่จำกัดของไอเทมหรือของเหลวใด ๆ
ที่คุณ [partition](cell_workbench.md) ไว้
