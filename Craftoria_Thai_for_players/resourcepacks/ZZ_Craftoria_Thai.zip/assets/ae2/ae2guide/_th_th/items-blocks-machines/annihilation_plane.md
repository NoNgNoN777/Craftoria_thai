---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Annihilation Plane
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# Annihilation Plane

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

Annihilation Plane ทุบบล็อกและเก็บไอเทม ทำงานคล้าย <ItemLink id="import_bus" /> โดยส่งของเข้า
[network storage](../ae2-mechanics/import-export-storage.md) ไอเทมจะถูกเก็บได้ก็ต่อเมื่อชนกับ
ด้านหน้าของ Plane มันไม่เก็บไอเทมเป็นพื้นที่

Annihilation Plane เสริมเอนชานต์ด้วยเอนชานต์ของ pickaxe ได้ทุกชนิด ดังนั้นใช่ คุณใส่ Fortune ระดับสูงลิ่วให้ไม่กี่ตัวแล้ว
[ทำออโต้การแปรรูปแร่](../example-setups/ore-fortuner.md) ได้ หากม็อดแพ็กของคุณอนุญาต นอกจากนี้ Silk Touch ทำงานตามที่คุณคาด
Efficiency ลดค่าพลังงานในการทุบบล็อก และ Unbreaking ให้โอกาสที่จะไม่ใช้พลังงานเลย

เป็น [cable subpart](../ae2-mechanics/cable-subparts.md)

**อย่าลืมเปิดใช้ FAKE PLAYER ในพื้นที่ CHUNK CLAIM ของคุณ**

## การกรอง

Annihilation Plane จะทุบบล็อกหรือเก็บไอเทมก็ต่อเมื่อเก็บของที่ดรอปออกมาลงในเครือข่ายของมันได้
นั่นหมายความว่าหากจะกรอง *คุณต้องจำกัดสิ่งที่เก็บได้ในเครือข่ายของมัน* ซึ่งส่วนใหญ่ทำโดยวางไว้
บน [subnetwork](../ae2-mechanics/subnetworks.md) โดย <ItemLink id="storage_bus" /> หรือ [cell](../items-blocks-machines/storage_cells.md)
ที่ [partition](cell_workbench.md) ไว้ก็ช่วยให้ทำได้

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        กรองให้เหลือเฉพาะสิ่งที่ดรอปจากสิ่งที่คุณต้องการทุบ
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        Partition ไว้เฉพาะสิ่งที่ดรอปจากสิ่งที่คุณต้องการทุบ
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ย้ำอีกครั้งว่ามันกรอง *ตามไอเทมที่ดรอป* ตัวอย่างเช่น หากคุณต้องการกรองการทุบ <ItemLink id="minecraft:amethyst_cluster" />
คุณต้องใช้ Plane ที่เสริมเอนชานต์ Silk Touch ไม่เช่นนั้นระยะการเติบโตก่อนหน้าทุกระยะจะดรอปของเป็นศูนย์ และ Plane จะทุบมันทิ้งไม่ว่าอย่างไร
เพราะเครือข่ายสามารถเก็บ "ความว่างเปล่า" ได้เสมอ

## สูตรคราฟต์

<RecipeFor id="annihilation_plane" />
