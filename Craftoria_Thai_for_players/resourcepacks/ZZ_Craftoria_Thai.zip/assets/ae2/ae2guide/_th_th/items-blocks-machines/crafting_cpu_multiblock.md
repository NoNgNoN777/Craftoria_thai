---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Crafting CPU Multiblock (Storage, Coprocessor, Monitor, Unit)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# Crafting CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

Crafting CPU จัดการคำขอหรืองานคราฟต์ โดยเก็บวัตถุดิบระหว่างทางขณะทำงานคราฟต์หลายขั้นตอน และมีผลต่อขนาดของงานที่ทำได้ รวมถึงความเร็วในการทำให้เสร็จ ดูรายละเอียดที่ [autocrafting](../ae2-mechanics/autocrafting.md)

Crafting CPU แต่ละตัวรับได้ 1 คำขอหรืองาน ดังนั้นหากต้องการขอทั้ง calculation processor และ smooth stone 256 ก้อนพร้อมกัน คุณต้องมี CPU multiblock 2 ตัว

ตั้งให้รับคำขอจากผู้เล่น ระบบอัตโนมัติ (export bus และ interface) หรือทั้งสองอย่างได้

คลิกขวาที่ CPU เพื่อเปิดหน้าสถานะการคราฟต์ ซึ่งแสดงความคืบหน้าของงานที่ CPU กำลังทำ

## การตั้งค่า

*   ตั้งให้ CPU รับคำขอเฉพาะจากผู้เล่น เฉพาะจากระบบอัตโนมัติ (เช่น <ItemLink id="export_bus" /> ที่ใส่
    <ItemLink id="crafting_card" />) หรือทั้งสองอย่างก็ได้

## การสร้าง

Crafting CPU เป็น multiblock ต้องเป็นทรงสี่เหลี่ยมตันไม่มีช่องว่าง และประกอบจากชิ้นส่วนหลายชนิด

CPU แต่ละตัวต้องมี crafting storage อย่างน้อย 1 บล็อก (CPU ขั้นต่ำที่ใช้งานได้ก็คือ crafting storage 1k เพียงบล็อกเดียว)

# Crafting Unit

<BlockImage id="crafting_unit" scale="4" />

(ไม่บังคับ) Crafting unit ใช้เติมช่องว่างใน CPU ให้เป็นทรงสี่เหลี่ยมตัน หากคุณมีชิ้นส่วนอื่นไม่พอ และยังเป็นวัตถุดิบพื้นฐานของชิ้นส่วนอื่นด้วย

<RecipeFor id="crafting_unit" />

# Crafting Storage

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

(จำเป็น) Crafting storage มีทุกขนาดมาตรฐานของ cell (1k, 4k, 16k, 64k, 256k) เก็บวัตถุดิบและวัตถุดิบระหว่างทางที่ใช้ในการคราฟต์ ดังนั้นหากงานคราฟต์มีวัตถุดิบมาก CPU ต้องมี storage ที่ใหญ่ขึ้นหรือมากขึ้น

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Crafting Co-Processing Unit

<BlockImage id="crafting_accelerator" scale="4" />

(ไม่บังคับ) Crafting co-processor ทำให้ระบบส่งชุดวัตถุดิบออกจาก <ItemLink id="pattern_provider" /> ถี่ขึ้น
ด้วยการทำให้ CPU tick เร็วขึ้น
ช่วยให้ตามเครื่องจักรที่ประมวลผลเร็วได้ทัน ตัวอย่างเช่น pattern provider ที่มี
<ItemLink id="molecular_assembler" /> ล้อมรอบ ส่งวัตถุดิบได้เร็วกว่าที่ assembler ตัวเดียวประมวลผลไหว จึงกระจาย
ชุดวัตถุดิบไปยัง assembler รอบ ๆ

สูตรซับซ้อนบางสูตรมีหลายขั้นตอนที่ทำพร้อมกันได้ เช่น ทำไม้กระดานกับหนังสือไปพร้อมกันเพื่อทำชั้นหนังสือ ในหน้าสถานะการคราฟต์ (เปิดได้ด้วยการคลิกขวาที่ CPU  หรือไอคอนค้อนใน [terminal](terminals.md)) ขั้นตอนเหล่านี้ จะขึ้นเป็น "scheduled" ทั้งหมด co-processor ที่เพิ่มแต่ละตัวช่วยให้ทำขั้นตอนเหล่านี้พร้อมกันได้อีกหนึ่งขั้นตอน (และขึ้นเป็น "crafting") แต่ข้อนี้ไม่ค่อยสำคัญ เพราะโดยปกติคุณมี co-processor เพื่อความเร็วในการป้อนวัตถุดิบมากกว่าจำนวนขั้นตอนของสูตรที่ทำพร้อมกันได้จริง

<RecipeFor id="crafting_accelerator" />

# Crafting Monitor

<BlockImage id="crafting_monitor" scale="4" />

(ไม่บังคับ) Crafting monitor แสดงงานที่ CPU กำลังทำอยู่ในขณะนั้น ย้อมสีหน้าจอได้ด้วย <ItemLink id="color_applicator" />

<RecipeFor id="crafting_monitor" />
