---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial Cell
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# Spatial Storage Cell

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

Spatial Storage Cell ใช้ [เก็บปริมาตรของพื้นที่จริง](../ae2-mechanics/spatial-io.md) และใช้งานใน <ItemLink id="spatial_io_port" />

ต่างจาก [Storage Cell](../items-blocks-machines/storage_cells.md) ตรงที่ spatial cell จัดรูปแบบใหม่ไม่ได้

ย้ำอีกครั้ง **คุณรีเซ็ต จัดรูปแบบใหม่ หรือเปลี่ยนขนาด SPATIAL CELL หลังใช้งานแล้วไม่ได้** หากต้องการขนาดอื่น ให้สร้าง cell ใหม่


## สูตรคราฟต์

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# Housing

ทำ cell ได้จาก spatial component กับ housing หรือใช้สูตร housing ล้อมรอบ spatial component

<Row>
  <Recipe id="network/cells/spatial_storage_cell_2_cubed" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

Housing เดี่ยว ๆ คราฟต์ได้ดังนี้

  <RecipeFor id="item_cell_housing" />

# Spatial Component

Spatial Component เป็นแกนหลักของ spatial storage cell แต่ละระดับเพิ่มขนาดของปริมาตรที่เก็บได้ 8 เท่า

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>