---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: สายเคเบิล
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# สายเคเบิล

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

เครือข่าย ME เกิดจากเครื่องจักรที่รองรับ ME ซึ่งวางติดกันได้ แต่วิธีหลักในการขยายเครือข่าย ME ไปยังพื้นที่กว้าง คือใช้สายเคเบิล

สายเคเบิลต่างสีช่วยกันไม่ให้สายที่วางติดกันเชื่อมต่อกัน ทำให้กระจาย [channel](../ae2-mechanics/channels.md) ได้มีประสิทธิภาพขึ้น สีของสายยังกำหนดสีของ terminal ที่ต่ออยู่ด้วย คุณจึงไม่จำเป็นต้องใช้ terminal สีม่วงทั้งหมด สาย Fluix เชื่อมต่อกับสายสีอื่นได้ทุกสี

ข้อควรจำ **CHANNEL ไม่เกี่ยวกับสีของสายเคเบิลเลย**

## หมายเหตุสำคัญ

**หากคุณเพิ่งเริ่มเล่น AE2 และยังไม่คุ้นกับ channel ให้ใช้ smart cable และ dense smart cable ทุกที่ที่ทำได้ สายเหล่านี้แสดงเส้นทางของ channel ในเครือข่าย ทำให้เข้าใจการทำงานได้ง่ายขึ้น**

## หมายเหตุอีกข้อ

**สายเหล่านี้ไม่ใช่ท่อส่งไอเทม ของเหลว หรือพลังงาน** สายไม่มีช่องเก็บของในตัว pattern provider และเครื่องจักรไม่ได้ "ดัน" ของเข้ามาในสาย หน้าที่ของสายมีเพียงเชื่อม [อุปกรณ์](../ae2-mechanics/devices.md) AE2 เข้าด้วยกันเป็นเครือข่าย

## Glass Cable

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" /> เป็นสายที่คราฟต์ง่ายที่สุด ส่งพลังงานและรองรับ
[channel](../ae2-mechanics/channels.md) ได้สูงสุด 8 ช่อง มีให้เลือก 17 สี โดยสีเริ่มต้นคือ Fluix
และย้อมเป็นสีใดก็ได้ด้วยสีย้อมทั้ง 16 สี

หากต้องการคราฟต์สายสี ให้วางสีย้อมชนิดใดก็ได้ไว้ตรงกลาง แล้วล้อมด้วยสายเคเบิลชนิดเดียวกัน 8 เส้น (สีของสายไม่สำคัญ แต่ต้องเป็นชนิดเดียวกัน เช่น glass หรือ smart) คุณยังทาสีสายในโลกได้ด้วยแปรงทาสีที่เข้ากันกับ Forge

คราฟต์สายสีใดก็ได้ร่วมกับถังน้ำเพื่อล้างสีย้อมออก

คุณหุ้มสายด้วยขนแกะเพื่อทำ <ItemLink id="fluix_covered_cable" /> และคราฟต์ <ItemLink id="fluix_smart_cable" /> เพื่อดูว่า [channel](../ae2-mechanics/channels.md) ของคุณกำลังเกิดอะไรขึ้น

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Covered Cable

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Covered cable ไม่ได้ให้ประโยชน์ในการเล่นเหนือกว่า <ItemLink id="fluix_glass_cable" /> แต่ใช้เป็นตัวเลือกด้านรูปลักษณ์ได้ หากคุณชอบหน้าตาแบบหุ้ม

ย้อมสีได้แบบเดียวกับ <ItemLink id="fluix_glass_cable" /> คราฟต์ <ItemLink id="fluix_covered_cable" /> 4 เส้นร่วมกับ redstone และ glowstone เพื่อทำ <ItemLink id="fluix_covered_dense_cable" />

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## Dense Cable

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

สายความจุสูง รองรับได้ 32 channel ต่างจากสายปกติที่รองรับได้เพียง 8 แต่ไม่รองรับ bus คุณต้องลดขนาดจากสาย dense เป็นสายที่เล็กกว่า (เช่น <ItemLink id="fluix_glass_cable" /> หรือ <ItemLink id="fluix_smart_cable" />) ก่อนจึงจะใช้ bus หรือ panel ได้

สาย dense เปลี่ยนพฤติกรรม "เส้นทางสั้นที่สุด" ของ channel เล็กน้อย โดย channel จะเลือกเส้นทางสั้นที่สุดไปยังสาย dense ก่อน แล้วจึงเลือกเส้นทางสั้นที่สุดผ่านสาย dense นั้นไปยัง controller

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## Smart Cable

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

สายชนิดนี้หน้าตาคล้าย <ItemLink id="fluix_covered_cable" /> แต่มีหน้าที่วินิจฉัยด้วยการแสดงการใช้งาน channel บนสาย channel จะปรากฏเป็นเส้นสีเรืองแสงวิ่งไปตามแถบสีดำของสาย ช่วยให้คุณเห็นว่า channel ในเครือข่ายถูกใช้อย่างไร สำหรับ smart cable ทั่วไป 4 channel แรกแสดงเป็นเส้นสีเดียวกับสาย อีก 4 channel ถัดไปแสดงเป็นเส้นสีขาว ส่วน dense smart cable แต่ละแถบแทน 4 channel

ในเครือข่ายที่มี <ItemLink id="controller" /> เส้นบนสายจะแสดงเส้นทางที่ channel ใช้จริง

Smart cable ในเครือข่ายแบบ ad-hoc จะแสดงจำนวน channel ที่ใช้อยู่ทั้งเครือข่าย แทนจำนวน channel ที่ไหลผ่านสายเส้นนั้น

ย้อมสีได้แบบเดียวกับ <ItemLink id="fluix_glass_cable" />

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
