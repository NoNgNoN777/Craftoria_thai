---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Presses
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Presses

มี press 5 แบบที่ใช้ใน <ItemLink id="inscriber" />

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Processor Press

Silicon, Logic, Calculation และ Engineering press ใช้ผลิต [processor](processors.md)
Press 4 แบบนี้ได้มาจากการทุบ <ItemLink id="mysterious_cube" /> ใน [meteorite](../ae2-mechanics/meteorites.md)
และทำสำเนาใน <ItemLink id="inscriber" /> ได้ด้วย

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Name Press

Name Press ใช้ใน inscriber เพื่อตั้งชื่อไอเทมได้ คล้ายกับทั่งตีเหล็ก

ถ้าจะคราฟต์ ให้คลิกขวาด้วย <ItemLink id="certus_quartz_cutting_knife" /> หรือ <ItemLink id="nether_quartz_cutting_knife" />
แล้วใส่แท่งโลหะ จากนั้นพิมพ์ชื่อ
ที่ต้องการเขียนลงบนแผ่น แล้วหยิบแผ่นที่เสร็จออกมา ใน inscriber ใช้แผ่นได้ครั้งละหนึ่งหรือสองแผ่น
ถ้าใช้สองแผ่น จะพิมพ์ชื่อโดยรวมทั้งสองชื่อเข้าด้วยกัน ช่องบนก่อนแล้วจึงช่องล่าง
