---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Mysterious Cube
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# Mysterious Cube

<BlockImage id="mysterious_cube" scale="8" />

จำได้ไหมว่าเคยต้องหา meteor หลายลูกเพื่อหา press ให้ครบ ไม่ต้องแล้ว! ตอนนี้ meteorite มาพร้อม Mysterious Cube

ไม่รู้ว่าจะเกิดอะไรขึ้นเมื่อคุณทุบมัน (โดยไม่ใช้ Silk Touch)...

คุณยังทำของเลียนแบบได้ด้วย คือ Not So Mysterious Cube

## สูตรคราฟต์

<RecipeFor id="not_so_mysterious_cube" />
