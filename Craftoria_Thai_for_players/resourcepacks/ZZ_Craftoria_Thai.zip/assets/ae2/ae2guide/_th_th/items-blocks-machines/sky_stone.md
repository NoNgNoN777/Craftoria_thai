---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Sky Stone
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# Sky Stone

<BlockImage id="sky_stone_block" scale="8" />

วัสดุที่ใช้สร้าง [meteorite](../ae2-mechanics/meteorites.md) ใช้ในสูตรของ <ItemLink id="sky_stone_tank" />, <ItemLink id="not_so_mysterious_cube" />,
<ItemLink id="cell_component_256k" /> และที่สำคัญที่สุดคือ <ItemLink id="controller" />

## สูตรคราฟต์

วาง annihilation plane หันขึ้นด้านบนที่ความสูงสุดของโลก เพื่อรับ sky stone dust

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
