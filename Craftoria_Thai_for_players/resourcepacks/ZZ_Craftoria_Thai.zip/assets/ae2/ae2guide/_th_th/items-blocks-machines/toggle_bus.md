---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Toggle Bus
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# Toggle Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Bus ที่ทำงานคล้าย <ItemLink id="fluix_glass_cable" /> หรือสายอื่น ๆ แต่สลับสถานะการเชื่อมต่อได้ด้วย redstone ทำให้คุณตัดส่วนหนึ่งของ [ME Network](../ae2-mechanics/me-network-connections.md) ออกได้

เมื่อได้รับสัญญาณ redstone ชิ้นส่วนนี้จะเปิดการเชื่อมต่อ ส่วน <ItemLink id="inverted_toggle_bus" /> ทำงานตรงข้าม คือปิดการเชื่อมต่อแทน

ข้อสังเกต การสลับสถานะอาจทำให้ เครือข่ายรีบูต และคำนวณอุปกรณ์ที่เชื่อมต่อใหม่

เป็น [ชิ้นส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

## สูตรคราฟต์

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />
