---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Block
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Fluix Block

<BlockImage id="fluix_block" scale="8" />

บล็อกเก็บของของ <ItemLink id="fluix_crystal" /> ใช้ในสูตรของเครื่องจักรบางอย่างด้วย

## สูตรคราฟต์

<RecipeFor id="fluix_block" />
