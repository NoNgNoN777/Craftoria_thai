---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Growth Accelerator
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# Growth Accelerator

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

Growth Accelerator เร่ง[การเติบโต](../ae2-mechanics/certus-growth.md)ของ certus หรือ amethyst อย่างมหาศาล เมื่อวางติดกับ budding block

น่าแปลกที่มันเร่งการเติบโตของพืชหลายชนิดได้ *ด้วย*

มันทำโดยสร้าง "random tick" ให้บล็อกข้างเคียง เพิ่มจาก random tick ที่เกิดตามธรรมชาติ ในทางทฤษฎี accelerator 1 ตัวทำให้ของเติบโตเร็วกว่าปกติประมาณ 90 เท่า และผลรวมกันแบบบวก

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

จ่ายพลังงานได้จากด้านบนหรือด้านล่าง ผ่าน[สายเคเบิล](cables.md)ของ AE2 หรือสายพลังงานของม็อดอื่น รับได้ทั้งพลังงานของ AE2 (AE) และ Forge Energy (FE)

หากต้องการจ่ายพลังงานด้วยมือ ให้วาง <ItemLink id="crank" /> ที่ด้านบนหรือด้านล่างแล้วคลิกขวา

แยกด้านบนและด้านล่างได้จากลายเส้น flux สีชมพูบนด้านเหล่านั้น

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## สูตรคราฟต์

<RecipeFor id="growth_accelerator" />
