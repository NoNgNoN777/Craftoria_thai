---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Crystal
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# Fluix Crystal

<ItemImage id="fluix_crystal" scale="4" />

*"Fluix Crystal มีความสามารถเฉพาะตัว ในการดูดซับและแปลงพลังงานจากรูปแบบหนึ่งเป็นอีกรูปแบบหนึ่ง และเป็นรากฐานของ
เทคโนโลยี Matter Energy ทั้งหมด"*

หนึ่งในส่วนผสมหลักของบล็อก [อุปกรณ์](../ae2-mechanics/devices.md) และไอเทมของ AE2 สร้างได้โดยโยน Nether Quartz เรดสโตน และ
<ItemLink id="charged_certus_quartz_crystal" /> ลงในน้ำ

ทำ[ออโต้](../example-setups/throw-in-water-automation.md)ได้โดยใช้ <ItemLink id="formation_plane" /> และ <ItemLink id="annihilation_plane" />

## สูตรคราฟต์

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
