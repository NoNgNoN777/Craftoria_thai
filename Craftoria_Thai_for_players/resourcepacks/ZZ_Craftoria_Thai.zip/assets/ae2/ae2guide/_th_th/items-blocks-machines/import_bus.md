---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME Import Bus
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# Import Bus

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

Import bus ดึงไอเทมและของเหลว (และอย่างอื่นถ้ามีแอดออน) จากคลังที่มันติดอยู่ แล้วส่งเข้า
[network storage](../ae2-mechanics/import-export-storage.md)

เพื่อลดแล็ก ถ้า import bus ไม่ได้นำเข้าอะไรมาสักพัก มันจะเข้าสู่
"โหมดพัก" ที่ทำงานช้า แล้วตื่นและเร่งเป็นความเร็วเต็มที่ (4 ครั้งต่อวินาที) เมื่อนำเข้าบางอย่างสำเร็จ

เป็น [ส่วนย่อยของสายเคเบิล](../ae2-mechanics/cable-subparts.md)

## การกรอง

โดยค่าตั้งต้น bus จะนำเข้าทุกอย่างที่เข้าถึงได้ ไอเทมที่ใส่ในช่องกรองจะทำหน้าที่เป็น whitelist
อนุญาตให้นำเข้าเฉพาะไอเทมเหล่านั้น

ลากไอเทมและของเหลวจาก JEI/REI ใส่ช่องได้ แม้คุณจะไม่มีไอเทมนั้นจริง ๆ

คลิกขวาด้วยภาชนะของเหลว (เช่น ถังหรือ fluid tank) เพื่อตั้งของเหลวนั้นเป็นตัวกรอง แทนที่จะเป็นไอเทมถังหรือ tank

## อัปเกรด

Import bus รองรับ [อัปเกรด](upgrade_cards.md) ต่อไปนี้

*   <ItemLink id="capacity_card" /> เพิ่มจำนวนช่องกรอง
*   <ItemLink id="speed_card" /> เพิ่มจำนวนที่ย้ายต่อรอบ
*   <ItemLink id="fuzzy_card" /> ให้ bus กรองตามระดับความเสียหาย และ/หรือข้าม NBT ของไอเทม
*   <ItemLink id="inverter_card" /> เปลี่ยนตัวกรองจาก whitelist เป็น blacklist
*   <ItemLink id="redstone_card" /> เพิ่มการควบคุมด้วยเรดสโตน ทำงานเมื่อมีสัญญาณสูง สัญญาณต่ำ หรือครั้งเดียวต่อพัลส์

## ความเร็ว

| Acceleration Card | ไอเทมที่ย้ายต่อรอบ         |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## สูตรคราฟต์

<RecipeFor id="import_bus" />
