---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cable Anchor
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# Cable Anchor

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

หนามเล็ก ๆ สำหรับตกแต่งที่ติดบนสายเคเบิล ใช้กันไม่ให้สายเคเบิลเชื่อมต่อกัน สร้างบันไดด้วยสายเคเบิล หรือทำให้สายเคเบิลดูเหมือน
เชื่อมกับกำแพงรอบ ๆ นอกจากนี้ยังใช้คราฟต์ <ItemLink id="facade" />

Cable anchor กันไม่ให้เกิดการเชื่อมต่อทางด้านที่มันติดอยู่

ปีนขึ้นได้เหมือนบันได

## สูตรคราฟต์

<RecipeFor id="cable_anchor" />
