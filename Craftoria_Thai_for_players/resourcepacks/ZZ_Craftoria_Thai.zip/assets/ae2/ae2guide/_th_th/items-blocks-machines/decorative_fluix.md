---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Decorative Fluix
  icon: fluix_stairs
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_stairs
- ae2:fluix_wall
- ae2:fluix_slab
---

# Decorative Fluix

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/decorative_fluix.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_block" /> คราฟต์และตัดด้วย Stonecutter เป็นบล็อกก่อสร้างตกแต่งได้หลายแบบ

## สูตรคราฟต์

<Row>
  <RecipeFor id="fluix_stairs" />

  <RecipeFor id="fluix_wall" />

  <RecipeFor id="fluix_slab" />
</Row>
