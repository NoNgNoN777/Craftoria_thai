---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Vibration Chamber
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# Vibration Chamber

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

วิธีหลักที่ตั้งใจให้จ่าย[พลังงาน](../ae2-mechanics/energy.md)แก่เครือข่ายคือ
<ItemLink id="energy_acceptor" /> แต่ vibration chamber ก็ผลิต AE ในปริมาณน้อยถึงปานกลางได้โดยตรง

โดยค่าเริ่มต้น (ไม่มี[การอัปเกรด](upgrade_cards.md)และใช้ config เริ่มต้น) ผลิตได้ 40 AE/t

เมื่อที่เก็บ[พลังงาน](../ae2-mechanics/energy.md)ของเครือข่ายเต็ม vibration chamber จะลดกำลังลงเพื่อประหยัดเชื้อเพลิง แต่ปิดสนิทไม่ได้

## การตั้งค่า

*   Vibration chamber ให้เข้าถึงการตั้งค่ารวมสำหรับดูพลังงานเป็น AE หรือ E/FE

## การอัปเกรด

Vibration chamber รองรับ[การอัปเกรด](upgrade_cards.md)ต่อไปนี้

*   <ItemLink id="energy_card" /> เพิ่มประสิทธิภาพของ chamber +50% สูงสุด +150% หรือ 250% ของประสิทธิภาพพื้นฐาน
*   <ItemLink id="speed_card" /> เพิ่มอัตราการเผาของ chamber +50% สูงสุด +150% หรือ 250% ของกำลังผลิตพื้นฐาน

## Config

แก้ไขคุณสมบัติของ vibration chamber ได้ใน common.json ในโฟลเดอร์ ae2 ภายในโฟลเดอร์ config ของไดเรกทอรี .minecraft\
ของคุณ

*   baseEnergyPerFuelTick กำหนดประสิทธิภาพพื้นฐานของ vibration chamber ที่ยังไม่อัปเกรด
*   minEnergyPerGameTick กำหนดการผลิตพลังงานต่ำสุดที่เป็นไปได้ (chamber จะใช้เชื้อเพลิงช้า ๆ เสมอ แม้เครือข่าย
    ไม่ต้องการพลังงานเลย)
*   maxEnergyPerGameTick กำหนดกำลังผลิตสูงสุด (และความเร็ว) ของ vibration chamber ที่ยังไม่อัปเกรด

## สูตรคราฟต์

<RecipeFor id="vibration_chamber" />
