---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Controller
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# Controller

<BlockImage id="controller" p:state="online" scale="8" />

Controller คือศูนย์กลางการจัดเส้นทางของ [ME Network](../ae2-mechanics/me-network-connections.md) หากไม่มี เครือข่ายจะเป็นแบบ "ad-hoc" และมี[อุปกรณ์](../ae2-mechanics/devices.md)ที่ใช้ channel ได้รวมกันสูงสุด 8 ตัว

ใน [ME Network](../ae2-mechanics/me-network-connections.md) เดียวกัน มี controller 2 ตัวไม่ได้

Controller ให้ [Channel](../ae2-mechanics/channels.md) 32 ช่องต่อด้าน

Controller ต้องใช้ 6 AE/t ต่อบล็อก controller จึงจะทำงาน บล็อก controller แต่ละบล็อกเก็บ AE ได้ 8000 เครือข่ายที่ใหญ่ขึ้นจึงอาจต้องมีที่เก็บพลังงานเพิ่ม ดูรายละเอียดที่ [พลังงาน](../ae2-mechanics/energy.md)

สร้าง Multiblock Controller ได้ค่อนข้างอิสระ

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

แต่มีกฎบางข้อที่ต้องทำตาม

1.  บล็อก controller ทั้งหมดใน [ME Network](../ae2-mechanics/me-network-connections.md) ต้องเชื่อมต่อกัน ไม่เช่นนั้นบล็อกจะเปลี่ยนเป็นสีแดง
2.  ขนาดของ controller ต้องอยู่ในกรอบ 7x7x7 ไม่เช่นนั้นจะเปลี่ยนเป็นสีแดง
3.  Controller มีบล็อกติดกันได้ 2 บล็อกในแกนไม่เกิน 1 แกน หากบล็อกใดฝ่าฝืนกฎนี้ จะหยุดทำงานและเปลี่ยนเป็นสีแดง

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ตราบใดที่ทำตามกฎครบและมีพลังงาน controller จะเรืองแสงและวนเปลี่ยนสี

คลิกขวาที่ controller เพื่อเปิด GUI เดียวกับ <ItemLink id="network_tool" />

## สูตรคราฟต์

<RecipeFor id="controller" />
