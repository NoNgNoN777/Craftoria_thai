---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Budding Certus Quartz
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Budding Certus Quartz

(ดู [Certus Growth](../ae2-mechanics/certus-growth.md) ด้วย)

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ตา certus quartz จะงอกจากบล็อก budding certus คล้ายกับ amethyst พบได้ใน [meteorite](../ae2-mechanics/meteorites.md)
Block budding certus มี 4 ระดับ ได้แก่ Flawless, Flawed, Chipped และ Damaged ดูแยกได้ง่ายที่สุด
ด้วยม็อดอย่าง HWYLA, Jade, The One Probe ฯลฯ (หรือหน้าจอ f3)

สำหรับ budding certus แบบ flawed, chipped และ damaged ทุกครั้งที่ตางอกอีกขั้น บล็อก budding มีโอกาส
เสื่อมลงหนึ่งระดับ และสุดท้ายกลายเป็น <ItemLink id="quartz_block" /> ธรรมดา

Budding certus แบบ flawless ไม่เสื่อมจากการงอกของตา และเป็นแหล่งผลิตไม่จำกัด

ถ้าทุบด้วยพิคแอกซ์ธรรมดา บล็อก budding certus จะเสื่อมลง 1 ระดับ ถ้าทุบด้วยพิคแอกซ์
ที่เอนชานต์ Silk Touch จะไม่เสื่อม ยกเว้นแบบ flawless **นั่นหมายความว่าบล็อก budding certus แบบ flawless ไม่สามารถ
เก็บและย้ายด้วยพิคแอกซ์ได้** ให้ใช้ [Spatial Storage](../ae2-mechanics/spatial-io.md) ตัดและวาง
บล็อก flawless budding ย้ายที่แทน

## สูตรคราฟต์

Budding certus แบบ flawed, chipped และ damaged คราฟต์ได้โดยโยนบล็อก budding ระดับก่อนหน้า (หรือ <ItemLink id="quartz_block" />)
ลงน้ำพร้อม <ItemLink id="charged_certus_quartz_crystal" /> ตั้งแต่หนึ่งชิ้นขึ้นไป

Budding certus แบบ flawless คราฟต์ไม่ได้ พบได้ในโลกเท่านั้น

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
