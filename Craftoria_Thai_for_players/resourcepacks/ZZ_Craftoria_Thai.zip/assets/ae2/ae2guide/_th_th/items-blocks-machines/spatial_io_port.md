---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Spatial IO Port
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# Spatial IO Port

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

Spatial IO Port ใช้ใน [spatial IO](../ae2-mechanics/spatial-io.md) เพื่อใส่ [spatial cell](spatial_cells.md) และควบคุมการทำงานของ spatial IO

หากต้องการให้เป็นอัตโนมัติ ใส่และดึง cell ได้ด้วยระบบขนย้ายไอเทมใดก็ได้ เช่น ฮอปเปอร์หรือ bus ของ AE2

## สูตรคราฟต์

<RecipeFor id="spatial_io_port" />