---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Certus Quartz Crystal
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# Charged Certus Quartz Crystal

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

<ItemLink id="certus_quartz_crystal" /> ที่ผ่าน <ItemLink id="charger" /> มาแล้ว ใช้ในการผลิต
<ItemLink id="fluix_crystal" /> และ [budding certus block](../items-blocks-machines/budding_certus.md)

## สูตรคราฟต์

<RecipeFor id="charged_certus_quartz_crystal" />
