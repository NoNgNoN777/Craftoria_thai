---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME IO Port
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# ME I/O Port

<BlockImage id="io_port" p:powered="true" scale="8" />

IO Port ให้คุณเติม [storage cell](../items-blocks-machines/storage_cells.md) จาก หรือระบายออกไปยัง
[network storage](../ae2-mechanics/import-export-storage.md) ได้อย่างรวดเร็ว

หมุนได้ด้วย <ItemLink id="certus_quartz_wrench" />

## การตั้งค่า

*   ตั้งให้ IO Port ย้าย cell ไปยังช่องผลลัพธ์เมื่อ cell ว่าง เต็ม หรือเมื่อทำงานเสร็จ
*   หากใส่ <ItemLink id="redstone_card" /> จะมีตัวเลือกเงื่อนไขเรดสโตนต่าง ๆ
*   ตรงกลาง GUI มีลูกศรสำหรับตั้งทิศทางการย้ายไอเทม จาก cell ไปยัง [network storage](../ae2-mechanics/import-export-storage.md)
    หรือจาก storage ไปยัง cell

## อัปเกรด

IO Port รองรับ[การ์ดอัปเกรด](upgrade_cards.md) ดังนี้

*   <ItemLink id="speed_card" /> เพิ่มปริมาณที่ย้ายต่อการทำงานหนึ่งครั้ง
*   <ItemLink id="redstone_card" /> เพิ่มการควบคุมด้วยเรดสโตน ให้ทำงานเมื่อมีสัญญาณสูง สัญญาณต่ำ หรือหนึ่งครั้งต่อหนึ่งพัลส์

## สูตรคราฟต์

<RecipeFor id="io_port" />
