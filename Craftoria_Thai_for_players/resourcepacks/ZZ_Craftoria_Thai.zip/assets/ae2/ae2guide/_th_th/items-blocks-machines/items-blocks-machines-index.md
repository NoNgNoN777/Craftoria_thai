---
navigation:
  title: ไอเทม บล็อก และเครื่องจักร
  position: 50
---

# ไอเทม บล็อก และเครื่องจักร

รายการสิ่งต่าง ๆ ในม็อดให้หน้าอื่นลิงก์มา พร้อมคำอธิบายหน้าที่ของแต่ละอย่าง

## ส่วนผสมและบล็อกเบ็ดเตล็ด

<CategoryIndex category="misc ingredients blocks" />

## โครงสร้างพื้นฐานของเครือข่าย

<CategoryIndex category="network infrastructure" />

## อุปกรณ์

<CategoryIndex category="devices" />

## เครื่องจักร

<CategoryIndex category="machines" />

## เครื่องมือ

<CategoryIndex category="tools" />