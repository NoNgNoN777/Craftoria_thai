---
navigation:
  parent: example-setups/example-setups-index.md
  title: ระบบเตาหลอมอัตโนมัติ
  icon: minecraft:furnace
---

# ระบบเตาหลอมอัตโนมัติ

โปรดทราบว่าชุดนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ต่อเข้ากับระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
ของคุณ ถ้าต้องการทำเตาหลอมอัตโนมัติแบบแยกเดี่ยว ใช้ hopper กับหีบแทนได้

การทำ <ItemLink id="minecraft:furnace" /> ให้อัตโนมัติซับซ้อนกว่าเครื่องจักรง่าย ๆ อย่าง [charger](../example-setups/charger-automation.md)
เตาหลอมต้องป้อนของจากสองด้านที่ต่างกัน และดึงของออกอีกด้านหนึ่ง ไอเทมที่จะหลอมต้องส่งเข้าทางด้านบน
เชื้อเพลิงต้องส่งเข้าทางด้านข้าง และผลลัพธ์ต้องดึงออกทางด้านล่าง

ทำได้โดยวาง <ItemLink id="pattern_provider" />
ไว้ด้านบน วาง <ItemLink id="export_bus" /> ไว้ด้านข้างเพื่อส่งเชื้อเพลิงเข้าไปตลอด และวาง <ItemLink id="import_bus" /> ไว้
ด้านล่างเพื่อนำผลลัพธ์เข้าเครือข่าย แต่วิธีนี้ใช้ [channel](../ae2-mechanics/channels.md) ถึง 3 ช่อง

นี่คือวิธีทำให้ใช้ channel เพียง 1 ช่อง

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: แบบมีทิศทาง ทำได้โดยใช้ certus quartz wrench ใส่ processing pattern ที่เกี่ยวข้อง

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Storage Bus #1: กรองเฉพาะ coal
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Storage Bus #2: กรองแบบบล็อก coal โดยใช้ inverter card
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="pattern_provider" /> (1) ใช้ค่าตั้งต้นตามปกติ พร้อมใส่ <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
    ทำให้มีทิศทางโดยใช้ <ItemLink id="certus_quartz_wrench" /> กับมัน

  ![Iron Pattern](../assets/diagrams/furnace_pattern.png)

* <ItemLink id="interface" /> (2) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="storage_bus" /> ตัวแรก (3) กรองเฉพาะ coal หรือเชื้อเพลิงอื่นที่คุณต้องการใช้
* <ItemLink id="storage_bus" /> ตัวที่สอง (4) กรองแบบบล็อกเชื้อเพลิงที่ใช้อยู่ โดยใช้ <ItemLink id="inverter_card" />

## หลักการทำงาน

1. <ItemLink id="pattern_provider" /> ส่งวัตถุดิบเข้า <ItemLink id="interface" />
   (จริง ๆ แล้วเพื่อเพิ่มประสิทธิภาพ มันส่งผ่าน Storage Bus ตรง ๆ เหมือนเป็นส่วนต่อของหน้าตัว provider ไอเทมไม่ได้เข้า Interface จริง)
2. Interface ตั้งไว้ไม่เก็บอะไรเลย จึงพยายามส่งวัตถุดิบเข้า [network storage](../ae2-mechanics/import-export-storage.md)
3. ที่เก็บเดียวบน subnet สีเขียวคือ <ItemLink id="storage_bus" /> ทั้งสองตัว ตัวที่กรอง coal วาง coal ลงช่องเชื้อเพลิงของเตาผ่านด้านข้าง
    ตัวที่กรองแบบไม่ใช่ coal วางไอเทมที่จะหลอมลงช่องบนผ่านด้านบน
4. เตาหลอมทำงานของมันไป
5. Hopper ดึงผลลัพธ์ออกทางด้านล่างของเตา แล้ววางลงช่องรับของคืนของ provider ส่งกลับเข้าเครือข่ายหลัก
