---
navigation:
  parent: example-setups/example-setups-index.md
  title: สต็อกอัตโนมัติด้วย Level Emitter
  icon: level_emitter
---

# สต็อกอัตโนมัติด้วย Level Emitter

บางคนอาจถามว่า "ฉันจะเก็บไอเทมชนิดหนึ่งไว้ในปริมาณที่กำหนด และคราฟต์เพิ่มเมื่อจำเป็นได้อย่างไร"

วิธีหนึ่งคือใช้ <ItemLink id="export_bus" />, <ItemLink id="level_emitter" /> และ <ItemLink id="crafting_card" /> เพื่อขอไอเทมใหม่จาก [autocrafting](../ae2-mechanics/autocrafting.md) ของเครือข่ายคุณโดยอัตโนมัติ ระบบนี้ใช้รักษาปริมาณมากของไอเทมชนิดเดียว

แน่นอนว่าคุณทำให้เครือข่ายคราฟต์ต่อเนื่องได้ โดยไม่ใช้ level emitter และ redstone card

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (1) Export Bus: กรองเป็นไอเทมที่ต้องการ มี Redstone Card และ Crafting Card ตั้งโหมดเรดสโตนเป็น
        "Active with signal" และตั้งพฤติกรรมการคราฟต์เป็น "Do not use stocked items"
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        (2) Level Emitter: ตั้งไอเทมและจำนวนที่ต้องการ และตั้งเป็น "Emit when levels are below limit"
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (3) Interface: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="export_bus" /> (1) กรองเป็นไอเทมที่ต้องการ มี <ItemLink id="redstone_card" /> และ <ItemLink id="crafting_card" />
  ตั้ง "Redstone Mode" เป็น "Active with signal" และตั้ง "Crafting Behavior" เป็น "Do not use stocked items" (ไม่ใช้ไอเทมที่สต็อกไว้)
* <ItemLink id="level_emitter" /> (2) ตั้งไอเทมและจำนวนที่ต้องการ และตั้งเป็น "Emit when levels are below limit"
* <ItemLink id="interface" /> (3) ตั้งค่าเริ่มต้น

## หลักการทำงาน

1. ถ้าจำนวนไอเทมที่ต้องการใน [network storage](../ae2-mechanics/import-export-storage.md) ต่ำกว่าปริมาณที่กำหนดใน
   <ItemLink id="level_emitter" /> มันจะส่งสัญญาณเรดสโตน
2. เมื่อได้รับสัญญาณเรดสโตน (และเพราะมี <ItemLink id="crafting_card" /> กับตั้งไม่ให้ใช้ไอเทมที่สต็อกไว้)
   <ItemLink id="export_bus" /> จะขอให้ [autocrafting](../ae2-mechanics/autocrafting.md) ของเครือข่ายคราฟต์
   ไอเทมที่ต้องการเพิ่ม แล้วส่งออกไอเทมนั้น
3. เมื่อมีไอเทมถูกดันเข้ามา (และไม่ได้ตั้งให้มีอะไรในช่องเก็บของภายใน) <ItemLink id="interface" /> จะดันไอเทมนั้นเข้า network storage