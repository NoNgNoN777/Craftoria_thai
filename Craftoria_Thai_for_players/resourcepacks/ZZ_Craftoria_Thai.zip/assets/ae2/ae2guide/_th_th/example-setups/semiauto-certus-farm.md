---
navigation:
  parent: example-setups/example-setups-index.md
  title: ฟาร์ม Certus กึ่งอัตโนมัติ
  icon: certus_quartz_crystal
  position: 115
---

# ฟาร์ม Certus กึ่งอัตโนมัติ

น่าเสียดายที่ [ฟาร์ม certus แบบง่าย](simple-certus-farm.md) ต้องใช้ <ItemLink id="flawless_budding_quartz" /> ถึงจะทำงานอัตโนมัติเต็มรูปแบบ ซึ่งต้องใช้ [Spatial IO](../ae2-mechanics/spatial-io.md) หรือสร้างฟาร์มที่ [meteorite](../ae2-mechanics/meteorites.md)

อย่างไรก็ตาม AE2 วางและทุบบล็อกได้ จึงอาจทำให้ฟาร์มของคุณ *เปลี่ยน budding certus ให้เอง* ได้ (คุณต้องคอยใส่
<ItemLink id="flawed_budding_quartz" /> ลงในถังรับเข้า และหยิบ <ItemLink id="quartz_block" /> จากถัง
budding certus ที่ใช้หมดแล้ว
ออกมา)

ถ้าต้องการให้ทำงานอัตโนมัติเต็มรูปแบบ ดู [ฟาร์ม Certus ขั้นสูง](advanced-certus-farm.md)

ฟาร์มนี้ซับซ้อนกว่า [ฟาร์ม certus แบบง่าย](simple-certus-farm.md) เล็กน้อย เพราะจริง ๆ แล้วเป็นระบบแยก 3 ชุดที่อัดรวมกัน

ดู [การเติบโตของ Certus](../ae2-mechanics/certus-growth.md) สำหรับความเร็วโดยประมาณ

**นี่คือโครงสร้างซับซ้อนที่มีของซ่อนอยู่หลังของอื่น ให้หมุนกล้องดูจากทุกมุม**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Annihilation Plane ตัวที่ 1: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Fortune ได้
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
        (2) Storage Bus ตัวที่ 1: กรองเป็น Certus Quartz Crystal
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Subnet ตัวทุบกลุ่มผลึก
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Annihilation Plane ตัวที่ 2: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Silk Touch
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
        (4) Storage Bus ตัวที่ 2: กรองเป็น Certus Quartz Block
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Subnet ตัวทุบ Certus Block
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Formation Plane: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
        (6) Import Bus: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Subnet ตัววาง Budding Block
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
        (7) Storage Bus ตัวที่ 3: กรองเป็น Certus Quartz Crystal ตั้ง priority สูงกว่า storage หลักของคุณ
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

    <DiamondAnnotation pos="1.5 0.5 1.5" color="#00ff00">
        ใส่ Flawed Budding Certus Quartz ด้วยมือ
        <BlockImage id="flawed_budding_quartz" scale="2" />
    </DiamondAnnotation>

    <DiamondAnnotation pos="1.5 1.5 1.5" color="#00ff00">
        หยิบ Certus Quartz Block ออกด้วยมือ
        <BlockImage id="quartz_block" scale="2" />
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## การตั้งค่า

### ตัวทุบกลุ่มผลึก:

* <ItemLink id="annihilation_plane" /> ตัวแรก (1) ไม่มี GUI และตั้งค่าไม่ได้ แต่เอนชานต์ Fortune ได้
* <ItemLink id="storage_bus" /> ตัวแรก (2) กรองเป็น <ItemLink id="certus_quartz_crystal" />

### ตัวทุบ Certus Block:

* <ItemLink id="annihilation_plane" /> ตัวที่สอง (3) ไม่มี GUI และตั้งค่าไม่ได้ แต่ต้องเอนชานต์ Silk Touch
* <ItemLink id="storage_bus" /> ตัวที่สอง (4) กรองเป็น <ItemLink id="quartz_block" />

### ตัววาง Budding Block:

* <ItemLink id="formation_plane" /> (5) ตั้งค่าเริ่มต้น
* <ItemLink id="import_bus" /> (6) ตั้งค่าเริ่มต้น

### บนเครือข่ายหลัก:

* <ItemLink id="storage_bus" /> ตัวที่สาม (7) กรองเป็น <ItemLink id="certus_quartz_crystal" /> และตั้ง
  [priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูงกว่า storage หลักของคุณ

## หลักการทำงาน

### ตัวทุบกลุ่มผลึก:

Subnet ตัวทุบกลุ่มผลึกทำงานคล้ายกับ subnet ใน [ฟาร์ม certus แบบง่าย](simple-certus-farm.md) มาก

1. <ItemLink id="annihilation_plane" /> พยายามทุบสิ่งที่อยู่ตรงหน้า แต่ทุบได้เฉพาะ <ItemLink id="quartz_cluster" />
   เพราะ storage เดียวบน subnet คือ <ItemLink id="storage_bus" /> ที่กรองเป็น <ItemLink id="certus_quartz_crystal" />
2. <ItemLink id="storage_bus" /> เก็บผลึก certus quartz ลงในถัง

### ตัวทุบ Certus Block

Subnet ตัวทุบ certus block ทำหน้าที่ทุบ budding block ที่หมดแล้วเมื่อมันกลายเป็น <ItemLink id="quartz_block" /> ธรรมดา ทำงานคล้ายตัวทุบกลุ่มผลึก

1. <ItemLink id="annihilation_plane" /> พยายามทุบสิ่งที่อยู่ตรงหน้า แต่ทุบได้เฉพาะ <ItemLink id="quartz_block" />
   เพราะ storage เดียวบน subnet คือ <ItemLink id="storage_bus" /> ที่กรองเป็น <ItemLink id="quartz_block" />
   plane ต้องมี Silk Touch เพื่อไม่ให้ budding block เสื่อมเมื่อถูกทุบ และ plane จะได้ไม่ทุบมันก่อนเวลา
2. <ItemLink id="storage_bus" /> เก็บ certus quartz block ไว้ในถัง
   budding certus ที่ใช้หมดแล้ว คุณต้องโยนมันลงน้ำพร้อม <ItemLink id="charged_certus_quartz_crystal" /> เองเพื่อฟื้นฟู

### ตัววาง Budding Block

Subnet ตัววาง budding block ทำหน้าที่วาง <ItemLink id="flawed_budding_quartz" /> ใหม่ เมื่อ subnet ตัวทุบทุบอันเก่าที่หมดแล้ว

1. <ItemLink id="import_bus" /> นำ budding block เข้าจากถังรับเข้า
2. Storage เดียวบน subnet คือ <ItemLink id="formation_plane" /> ซึ่งวาง budding block

### บนเครือข่ายหลัก

* <ItemLink id="storage_bus" /> ให้เครือข่ายหลัก (และ [Charger Automation](charger-automation.md) ด้วย) เข้าถึงผลึก certus quartz ทั้งหมดในถัง ตั้งไว้ที่
  [priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูง เพื่อให้ผลึก certus quartz
  ถูกใส่กลับในถังก่อน แทนที่จะเข้า storage หลักของคุณ