---
navigation:
  parent: example-setups/example-setups-index.md
  title: ตัวเติมถัง (Bucket Filler)
  icon: minecraft:water_bucket
---

# ตัวเติมถัง (Bucket Filler)

ดู [Bucket Emptier](bucket-emptier.md) ด้วย

โปรดทราบว่าระบบนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ผสานกับระบบ [autocrafting](../ae2-mechanics/autocrafting.md) ของคุณ

บางครั้งชีวิตก็ไม่สะดวก และคุณต้องการของเหลวเป็นถังแทนที่จะเป็นของเหลวเอง บางทีเครื่องอาจทำให้ได้ (เช่น Fluid Transposer จาก Thermal Expansion) แต่คุณอาจไม่ได้มีม็อดที่ทำให้สะดวกเสมอไป โชคดีที่ Minecraft ดั้งเดิมมีวิธีที่สะดวกน้อยลงนิดหน่อย คือ <ItemLink id="minecraft:dispenser" />

**โปรดทราบว่าคุณมักไม่ต้องทำแบบนี้ เพราะ Fluid Substitutions ใน [Pattern Encoding Terminal](../items-blocks-machines/terminals.md#pattern-encoding-terminal) ให้คุณใช้ของเหลวเองในสูตรคราฟต์แทนถังได้**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Pattern Provider: ตั้งล็อกการคราฟต์เป็น "With redstone signal" พร้อม processing pattern ที่เกี่ยวข้อง

        <Row>
        ![Fill Pattern](../assets/diagrams/water_fill_pattern_small.png)
        ![Fill Pattern](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (2) Interface: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        (3) Storage Bus ตัวที่ 1: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Formation Plane: กรองแบบ blacklist ถัง โดยใช้ inverter card
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        (5) Import Bus: กรองแบบ blacklist ถัง โดยใช้ inverter card
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (6) Storage Bus ตัวที่ 2: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## การตั้งค่า

* <ItemLink id="pattern_provider" /> (1) ตั้งล็อกการคราฟต์เป็น "With redstone signal" พร้อม <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
  
    ![Charger Pattern](../assets/diagrams/water_fill_pattern.png)
    ![Charger Pattern](../assets/diagrams/lava_fill_pattern.png)

* <ItemLink id="interface" /> (2) ตั้งค่าเริ่มต้น
* <ItemLink id="storage_bus" /> ตัวแรก (3) ตั้งค่าเริ่มต้น
* <ItemLink id="formation_plane" /> (4) กรองแบบ blacklist ถัง โดยใช้ inverter card
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* <ItemLink id="import_bus" /> (5) กรองแบบ blacklist ถัง โดยใช้ inverter card
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* <ItemLink id="storage_bus" /> ตัวที่สอง (6) ตั้งค่าเริ่มต้น

## หลักการทำงาน

1. <ItemLink id="pattern_provider" /> ดันวัตถุดิบเข้า <ItemLink id="interface" />
   (จริง ๆ แล้ว เพื่อเพิ่มประสิทธิภาพ มันดันผ่าน storage bus และ formation plane ตรง ๆ เหมือนเป็นส่วนต่อขยายของด้านของ provider ไอเทมไม่ได้เข้า interface จริง ๆ)
2. ด้วยกลไกที่อธิบายใน [pipe subnet](pipe-subnet.md#providing-to-multiple-places) และ <ItemLink id="formation_plane" />
   ถังจะไปอยู่ใน <ItemLink id="minecraft:dispenser" /> และ formation plane วางของเหลว
3. <ItemLink id="minecraft:comparator" /> ตรวจพบถังใน dispenser จึงจ่ายพลังให้ dispenser พร้อมกับล็อก
   <ItemLink id="pattern_provider" /> ไปพร้อมกัน
4. Dispenser ตักของเหลวด้วยถัง ตอนนี้ในตัวมันมีถังที่เติมแล้ว
5. <ItemLink id="import_bus" /> ดึงถังที่เติมแล้วออกจาก dispenser และเก็บผ่าน
   <ItemLink id="storage_bus" /> เข้า pattern provider ส่งกลับเครือข่ายหลัก
6. Comparator เห็นว่า dispenser ว่าง จึงปลดล็อก provider
