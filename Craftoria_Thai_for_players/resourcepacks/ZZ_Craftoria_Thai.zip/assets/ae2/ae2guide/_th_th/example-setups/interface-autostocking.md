---
navigation:
  parent: example-setups/example-setups-index.md
  title: สต็อกอัตโนมัติด้วย Interface
  icon: interface
---

# สต็อกอัตโนมัติด้วย Interface

บางคนอาจถามว่า "ฉันจะเก็บไอเทมหลายชนิดไว้ในปริมาณที่กำหนด และคราฟต์เพิ่มเมื่อจำเป็นได้อย่างไร"

วิธีหนึ่งคือใช้ <ItemLink id="interface" /> และ <ItemLink id="crafting_card" /> เพื่อขอไอเทมใหม่จาก [autocrafting](../ae2-mechanics/autocrafting.md) ของเครือข่ายคุณโดยอัตโนมัติ ระบบนี้เหมาะกับการรักษาปริมาณน้อยของไอเทมหลากหลายชนิดมากกว่า

ระบบตัวอย่างนี้ตัดให้สั้นเพื่อไม่ให้กว้างเกินไป โดยทั่วไปที่เหมาะที่สุดน่าจะใช้ <ItemLink id="interface" /> 4 ตัวและ <ItemLink id="storage_bus" /> 4 ตัว เพื่อใช้ [channel](../ae2-mechanics/channels.md) ทั้ง 8 ของ [สายเคเบิล](../items-blocks-machines/cables.md) ปกติ

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        (1) Interface: ตั้งให้เก็บไอเทมที่ต้องการไว้ในตัวเอง มี Crafting Card
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        (2) Storage Bus: ตั้ง "Input/Output Mode" เป็น "Extract Only"
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="interface" /> (1) ตั้งให้เก็บไอเทมที่ต้องการไว้ในตัวเอง โดยคลิกไอเทมที่ต้องการใส่ในช่องด้านบน
   หรือลากจาก JEI ใส่ช่องด้านบน แล้วคลิกไอคอนประแจเหนือช่องเพื่อกำหนดจำนวน มี <ItemLink id="crafting_card" />
* <ItemLink id="storage_bus" /> (2) ตั้ง "Input/Output Mode" เป็น "Extract Only"

## หลักการทำงาน

1. ถ้า <ItemLink id="interface" /> ดึงไอเทมที่ตั้งไว้จาก [network storage](../ae2-mechanics/import-export-storage.md) ได้ไม่พอ
   (และมี <ItemLink id="crafting_card" />) มันจะขอให้ [autocrafting](../ae2-mechanics/autocrafting.md) ของเครือข่ายคราฟต์ไอเทมนั้นเพิ่ม
2. <ItemLink id="storage_bus" /> ให้เครือข่ายเข้าถึงเนื้อหาของ interface ได้