---
navigation:
  parent: example-setups/example-setups-index.md
  title: ตัวอย่าง "เครือข่ายหลัก"
  icon: controller
---

# ตัวอย่าง "เครือข่ายหลัก"

ชุดอื่นจำนวนมากอ้างถึง "เครือข่ายหลัก" คุณอาจสงสัยด้วยว่า [อุปกรณ์](../ae2-mechanics/devices.md) เหล่านี้
ประกอบรวมเป็นระบบที่ใช้งานได้อย่างไร นี่คือตัวอย่าง

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        กลุ่ม pattern provider และ assembler ขนาดใหญ่ให้พื้นที่มากสำหรับ pattern ของการคราฟต์ การตัดหิน และ smithing
        การวางแบบลายกระดานหมากรุกทำให้ provider ใช้ assembler หลายตัวพร้อมกันได้ ขณะที่ยังกะทัดรัด
        การจัดเป็นกลุ่มละ 8 ทำให้ channel ไม่มีทางเดินสายผิด
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        จริง ๆ แล้วคุณไม่ต้องใช้ controller ใหญ่ขนาดนั้น ดีไซน์วงแหวนและลูกบาศก์ขนาดใหญ่ที่เห็นตามฐานของผู้เล่นอื่น
        ส่วนใหญ่ทำมาเพื่อความเท่เท่านั้น
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        เครือข่ายที่ดีทุกเครือข่ายมี energy cell เพื่อรับพลังงานเข้าต่อ gametick ได้มากขึ้น และ 
        ทำให้พลังงานที่ขึ้นลงนิ่งขึ้น
    </BoxAnnotation>
    
    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        คุณน่าจะอยากใช้แหล่งพลังงานจากม็อดอื่น เช่น เครื่องปฏิกรณ์ แผงโซลาร์ หรือเครื่องกำเนิดไฟฟ้า
        หรืออะไรก็ได้ Vibration Chamber พอใช้ได้ แต่ AE2 ออกแบบมาให้ใช้ในม็อดแพ็ก และใช้ 
        เครื่องผลิตพลังงานหลักของฐานคุณ
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="15 1 9" max="16 3 14" thickness="0.05">
        ใช้ Facade ซ่อนของไว้หลังกำแพงได้
    </BoxAnnotation>
    <BoxAnnotation color="#33dd33" min="15 3 12" max="16 10 14" thickness="0.05">
        ใช้ Facade ซ่อนของไว้หลังกำแพงได้
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 7" max="14 10 9" thickness="0.05">
        คุณไม่ต้องใช้ drive bay และ cell มากขนาดนั้นสำหรับที่เก็บทั่วไป Drive 2-4 ตัวที่ใส่ cell ขนาด 4k หรือ 16k
        มักพอเกือบทุกครั้ง
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 10" max="14 11 11" thickness="0.05">
        สำหรับเก็บของจำนวนมาก ให้ใช้ cell ใหญ่ที่กรองไอเทมเฉพาะอย่าง ใส่ใน drive แยกต่างหากที่ตั้ง
        ลำดับความสำคัญสูงกว่า
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10 9 13" max="11.7 13 14" thickness="0.05">
        ระบบเติมสต็อกอัตโนมัติด้วย Interface
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="6 10 12" max="9 12 15" thickness="0.05">
        ส่วนขยายตามตรรกะของชุด charger automation ไปเป็น charger หลายตัว
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 10 12" max="5 11 15" thickness="0.05">
        อีกวิธีทำ processor ให้อัตโนมัติ เพราะใน 1.20 inscriber ดันผลลัพธ์ออกเองได้แล้ว
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="3 10 10" max="4 12 11" thickness="0.05">
        อีกวิธีทำ processor ให้อัตโนมัติ เพราะใน 1.20 inscriber ดันผลลัพธ์ออกเองได้แล้ว
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.2 9.2 8.2" max="7.8 10 8.8" thickness="0.05">
        Wireless Access Point อยู่ตรงกลางเพราะรัศมีสัญญาณเป็นทรงกลม
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        โดยทั่วไปคุณจะมี crafting CPU ใหญ่ 1-2 ตัวสำหรับงานใหญ่ และตัวเล็กอีกไม่กี่ตัวไว้จัดการงาน
        รองลงมาขณะที่ CPU ใหญ่กำลังทำงานอยู่
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="5 3 6" max="6 4 7" thickness="0.05">
        บางครั้ง subnet อาจต้องมี controller ของตัวเองถ้ามีอุปกรณ์เกิน 8 ชิ้น (เช่น กระจายไปมากกว่า
        8 จุด)
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        ฟาร์ม Certus
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        ระบบ Throwing-In-Water อัตโนมัติ
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>
