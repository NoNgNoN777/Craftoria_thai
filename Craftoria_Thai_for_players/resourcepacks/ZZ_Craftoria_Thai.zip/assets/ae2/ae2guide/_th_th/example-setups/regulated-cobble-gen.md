---
navigation:
  parent: example-setups/example-setups-index.md
  title: เครื่องผลิต Cobblestone ที่ควบคุมอัตโนมัติ
  icon: minecraft:cobblestone
---

# เครื่องผลิต Cobblestone ที่ควบคุมอัตโนมัติ

การทำเครื่องผลิต cobblestone ให้อัตโนมัติทำได้ง่าย แค่หัน <ItemLink id="annihilation_plane" /> เข้าหาเครื่องผลิต cobblestone แบบใช้มือ
ของ vanilla ทั่วไป แต่ถ้าทำแบบนี้ เครือข่ายของคุณจะอัดแน่นด้วย cobblestone จนติดขัดในที่สุด
จึงต้องมีการควบคุม

เนื่องจากกลไกของ annihilation plane (ทำงานเหมือน <ItemLink id="import_bus" />) เราจึงวาง <ItemLink id="level_emitter" />
หันเข้าหา <ItemLink id="export_bus" /> ที่ใส่ <ItemLink id="redstone_card" /> ไม่ได้ตรง ๆ (เพราะต่อจาก import ไป export
โดยไม่มีที่เก็บคั่นกลางไม่ได้) เราต้องอ้อมนิดหน่อย

<ItemLink id="toggle_bus" /> ให้คุณเชื่อมและตัดส่วนต่าง ๆ ของเครือข่ายด้วยสัญญาณเรดสโตน แต่ทุกครั้งที่ทำแบบนี้
เครือข่ายจะรีบูต มีวิธีแก้ง่าย ๆ คือวาง toggle bus ไว้บน [subnetwork](../ae2-mechanics/subnetworks.md)
เพื่อให้รีบูตเฉพาะ subnet

เราทำให้ [subnetwork](../ae2-mechanics/subnetworks.md) ที่ประกอบด้วย <ItemLink id="annihilation_plane" /> และ <ItemLink id="storage_bus" /> ทำงานในตัวเองได้
แล้วส่งเข้า <ItemLink id="interface" /> บนเครือข่ายหลัก Toggle bus จะเชื่อมและตัด subnet ออกจาก
<ItemLink id="quartz_fiber" /> ทำให้ plane ขาดพลังงาน

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        (1) Annihilation Plane: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Efficiency และ Unbreaking ได้ เพื่อลดการใช้พลังงาน
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        (2) Storage Bus: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        (3) Toggle Bus: สำคัญมากที่ toggle bus ต้องอยู่บน
        subnetwork ไม่ใช่เครือข่ายหลัก
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        (4) Level Emitter: กำหนดค่าเป็น cobblestone และจำนวนที่ต้องการ ตั้งเป็น "Emit when levels are below limit"
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        (5) Interface: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
        บันไดที่มีน้ำขังช่วยไม่ให้น้ำไหล และไม่ให้ลาวากลายเป็น obsidian
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="annihilation_plane" /> (1) ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Efficiency และ Unbreaking ได้ เพื่อลดการใช้พลังงาน
* <ItemLink id="storage_bus" /> (2) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="toggle_bus" /> (3) ต้องอยู่ฝั่ง subnetwork ของ quartz fiber ไม่ใช่ฝั่งเครือข่ายหลัก ไม่เช่นนั้นเครือข่าย
  หลักจะรีบูตทุกครั้งที่สลับ
* <ItemLink id="level_emitter" /> (4) กำหนดค่าเป็นไอเทมและจำนวนที่ต้องการ ตั้งเป็น "Emit when levels are below limit"
* <ItemLink id="interface" /> (5) ใช้ค่าตั้งต้นตามปกติ

## หลักการทำงาน

1. เครื่องผลิต cobblestone สร้าง cobblestone ออกมา
2. <ItemLink id="annihilation_plane" /> ทุบ cobblestone
3. <ItemLink id="storage_bus" /> เก็บ cobblestone ลงใน <ItemLink id="interface" /> ส่งเข้าเครือข่ายหลัก
4. เมื่อจำนวน cobblestone ในเครือข่ายหลักเกินที่ตั้งไว้ <ItemLink id="level_emitter" /> จะหยุด
   ส่งสัญญาณ ทำให้ <ItemLink id="toggle_bus" /> ปิด
5. ทำให้ subnetwork ขาดพลังงาน annihilation plane จึงหยุดทำงาน
