---
navigation:
  parent: example-setups/example-setups-index.md
  title: ประเภทที่เก็บและการจัดเครือข่ายให้เป็นระเบียบ
  icon: drive
---

# ที่เก็บหลายแบบและการจัดเครือข่ายให้เป็นระเบียบ

เมื่อใช้ตัวกรอง [partition](../items-blocks-machines/cell_workbench.md) และ [ลำดับความสำคัญของที่เก็บ](../ae2-mechanics/import-export-storage.md#storage-priority)
คุณจะตั้งที่เก็บได้หลายระดับสำหรับของแต่ละประเภท

ที่เก็บมักแบ่งเป็น
* ที่เก็บทั่วไป สำหรับของจิปาถะที่คุณมีตั้งแต่ไม่กี่ชิ้นถึงไม่กี่พันชิ้น ใช้ [cell](../items-blocks-machines/storage_cells.md) ขนาดเล็ก
เช่น 4k หรือ 16k
* ที่เก็บจำนวนมาก สำหรับของที่คุณมีมากกว่าไม่กี่พันชิ้น เช่น cobble หรือ iron ใช้ cell ใหญ่ เช่น 256k
หรือ cell จากแอดออน MEGA
* ที่เก็บในพื้นที่ของฟาร์ม ตามที่อธิบายไว้ใน [Specialized Local Storage](specialized-local-storage.md) และ
[ฟาร์ม](simple-certus-farm.md) [certus](semiauto-certus-farm.md) [หลายแบบ](advanced-certus-farm.md)

ลำดับความสำคัญตั้งไว้เพื่อให้เมื่อไอเทมถูกส่งเข้าเครือข่ายหลัก ระบบจะพยายามเก็บลงที่เก็บเฉพาะทาง
แบบจำนวนมากหรือในพื้นที่ก่อน ถ้าทำไม่ได้ (เพราะตัวกรองและ partition) จึงเก็บลงที่เก็บทั่วไป
ซึ่งหมายความว่าไอเทมจะ ไม่ย้ายจากที่เก็บหนึ่งไปอีกที่หนึ่งเอง แต่จะ "ย้ายถิ่น" เมื่อเข้าและออกจากเครือข่าย
ถ้าต้องการย้ายไอเทมจริง ๆ ให้ใช้ <ItemLink id="io_port" />

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/network_storage_types.snbt" />

    <BoxAnnotation color="#33dd33" min="11 0 1" max="12 1.3 2" thickness="0.05">
        ที่เก็บจำนวนมาก ในที่นี้คือ storage bus ที่กรองไอเทม ติดกับที่เก็บความจุสูงอย่าง drawer storage bus นี้กรองเฉพาะ
        coal มีลำดับความสำคัญสูง ดังนั้นเมื่อ coal เข้าเครือข่ายจะไปที่ storage bus นี้ และเมื่อ coal ถูก
        ดึงจากเครือข่าย จะดึงจากทุกที่ *ยกเว้นที่นี่* coal จึง "ย้ายถิ่น" มาที่ drawer นี้

        หมายเหตุสำคัญ: คลังที่ปรับแต่งมาอย่างดีและมีขนาดใหญ่อย่าง drawer ใช้แบบนี้ได้ แต่คลังขนาดใหญ่ที่ *ไม่ได้* ปรับแต่งและมีหลายช่อง เช่น
        colossal chest ทำให้ประสิทธิภาพแย่มากเมื่อใช้กับ storage bus
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="11 0 3" max="12 1 4" thickness="0.05">
        ที่เก็บจำนวนมาก ในที่นี้คือ cell 256k ที่กำหนด partition ไว้ ใน drive ที่มีลำดับความสำคัญสูง cell นี้กำหนด partition เป็น
        cobblestone และ iron มี Equal Distribution Card จึงไม่เต็มไปด้วย cobblestone จนไม่เหลือ
        ที่ว่างให้ iron drive มีลำดับความสำคัญสูง ดังนั้นเมื่อ cobble หรือ iron เข้าเครือข่ายจะไปที่ storage bus นี้
        และเมื่อ cobble หรือ iron ถูกดึงจากเครือข่าย จะดึงจากทุกที่ *ยกเว้นที่นี่* cobble และ iron จึง "ย้ายถิ่น" มาที่ cell นี้
    </BoxAnnotation>

    <BoxAnnotation color="#33dddd" min="11 0 5" max="12 1 6" thickness="0.05">
        ที่เก็บทั่วไป ในที่นี้คือ drive ที่เต็มไปด้วย cell 16k cell เหล่านี้ไม่ได้กำหนด partition drive มีลำดับความสำคัญกลาง
        (ในที่นี้คือ 0) ดังนั้นเมื่อมีของเข้าเครือข่าย ของจะไปที่ที่เก็บเฉพาะทางแบบจำนวนมากหรือในพื้นที่ก่อน
        และเมื่อมีของถูกดึงจากเครือข่าย จะดึงจากที่นี่ก่อน ไอเทมที่มีที่เก็บเฉพาะทางจึงค่อย ๆ
        "ย้ายถิ่น" ออกจากที่เก็บทั่วไปเองตามธรรมชาติ
    </BoxAnnotation>

    <BoxAnnotation color="#88ff88" min="11 0 8" max="12 1 9" thickness="0.05">
        IO Port นี้มีบทบาทสำคัญในการจัดเครือข่ายให้เป็นระเบียบ เนื่องจากลำดับความสำคัญของที่เก็บ *ไม่ได้* ย้ายไอเทม
        ให้เอง จึงควรนำ cell ที่ใช้เป็นที่เก็บทั่วไปมา "สับเปลี่ยน" ผ่าน IO port เป็นระยะ เพื่อย้ายไอเทมที่มี
        ที่เก็บเฉพาะทางของตัวเองไปยังที่เก็บนั้น วิธีนี้ "จัดระเบียบ" ที่เก็บ ทำให้ของไม่ถูก
        เก็บกระจายหลายที่
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 11" max="15 1 12" thickness="0.05">
        ที่เก็บในพื้นที่ของฟาร์มม็อบ drive นี้มี cell ที่กำหนด partition เป็นไอเทมที่ดรอปซึ่งคุณต้องการเก็บ เช่น bone และ arrow
        ตัว drive เองไม่ได้ตั้งลำดับความสำคัญ เพราะสิ่งที่กำหนดลำดับความสำคัญคือ storage bus ที่เข้าถึง subnet
        จากเครือข่ายหลัก cell ใส่ equal distribution card และ overflow destruction card ไว้
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 1 10" max="15 2.3 11" thickness="0.05">
        ที่เก็บในพื้นที่ของฟาร์มม็อบ ชุด storage bus กับ interface นี้ทำให้เครือข่ายหลักเข้าถึงที่เก็บของ subnet นี้ได้
        Storage bus ตั้งลำดับความสำคัญสูง และกรองเฉพาะของที่เก็บใน cell บน subnet

        สำคัญ: เนื่องจากบน subnet มีชุดถังขยะ อย่าลืมกรอง storage bus นี้ ไม่เช่นนั้นมันจะเริ่มทิ้ง
        *ทุกไอเทม ของเหลว ฯลฯ ที่เข้าเครือข่าย*!
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 9" max="15 1.3 10" thickness="0.05">
        ที่เก็บในพื้นที่ของฟาร์มม็อบ storage bus บน matter condenser นี้ตั้งลำดับความสำคัญต่ำกว่า drive หมายความว่า
        ไอเทมที่ม็อบดรอปซึ่งเข้า cell ใน drive ไม่ได้ จะล้นมาที่นี่แล้วถูกกำจัดทิ้ง ซึ่งสำคัญมาก
        เพื่อไม่ให้ subnet อุดตันเต็มไปด้วยของไร้ค่าอย่างธนูที่เกือบพัง
    </BoxAnnotation>

    <BoxAnnotation color="#dd33dd" min="8 1 11.7" max="9 2.3 13" thickness="0.05">
        ที่เก็บในพื้นที่ของฟาร์มแตงโม ชุดนี้ใช้วิธีคล้ายกับตัวอย่างฟาร์ม certus หลายแบบ Storage bus
        บน subnet ใส่ผลผลิตที่ปลูกลงถัง อีก storage bus บนเครือข่ายหลัก (กรองเฉพาะ melon
        slice และมีลำดับความสำคัญสูง) ให้เครือข่ายหลักเข้าถึงผลผลิตได้
    </BoxAnnotation>

  <IsometricCamera yaw="270" pitch="30" />
</GameScene>
