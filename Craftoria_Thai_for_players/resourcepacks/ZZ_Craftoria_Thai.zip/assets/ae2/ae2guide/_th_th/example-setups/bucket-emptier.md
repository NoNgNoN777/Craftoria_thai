---
navigation:
  parent: example-setups/example-setups-index.md
  title: ตัวเทของเหลวออกจากถัง
  icon: minecraft:bucket
---

# ตัวเทของเหลวออกจากถัง

ดู [Bucket Filler](bucket-filler.md) ด้วย

โปรดทราบว่าชุดนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ต่อเข้ากับระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
ของคุณ

บางครั้งคุณต้องการตัวของเหลวเอง แต่ผลิตได้เฉพาะของเหลวที่อยู่ในถัง บางครั้งเครื่องจักรอาจทำให้ได้
(เช่น Fluid Transposer จาก Thermal Expansion) แต่คุณอาจไม่มีม็อดที่ทำเรื่องนี้ได้สะดวกเสมอไป โชคดีที่
Minecraft ปกติมีวิธีที่สะดวกน้อยกว่าเล็กน้อย คือ <ItemLink id="minecraft:dispenser" />

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_emptier.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Pattern Provider: ตั้งให้ล็อกการคราฟต์ "With redstone signal" และเปิดโหมด blocking ใส่ processing pattern ที่เกี่ยวข้อง

        <Row>
        ![Fill Pattern](../assets/diagrams/water_empty_pattern_small.png)
        ![Fill Pattern](../assets/diagrams/lava_empty_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (2) Interface: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 2 1.1" max="3.9 2.2 1.9">
        (3) Storage Bus #1: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Annihilation Plane: ไม่มี GUI ให้ตั้งค่า
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 1.2 0.8" max="3.8 1.8 1">
        (5) Import Bus: กรองเฉพาะถัง (bucket)
        <ItemImage id="minecraft:bucket" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (6) Storage Bus #2: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## การตั้งค่า

* <ItemLink id="pattern_provider" /> (1) ตั้งให้ล็อกการคราฟต์ "With redstone signal" และเปิดโหมด blocking
  พร้อมใส่ <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
  
    ![Charger Pattern](../assets/diagrams/water_empty_pattern.png)
    ![Charger Pattern](../assets/diagrams/lava_empty_pattern.png)

* <ItemLink id="interface" /> (2) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="storage_bus" /> ตัวแรก (3) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="annihilation_plane" /> (4) ไม่มี GUI จึงตั้งค่าไม่ได้
* <ItemLink id="import_bus" /> (5) กรองเฉพาะถัง (bucket)
  <ItemImage id="minecraft:bucket" scale="2" />
* <ItemLink id="storage_bus" /> ตัวที่สอง (6) ใช้ค่าตั้งต้นตามปกติ

## หลักการทำงาน

1. <ItemLink id="pattern_provider" /> ส่งวัตถุดิบเข้า <ItemLink id="interface" />
   (จริง ๆ แล้วเพื่อเพิ่มประสิทธิภาพ มันส่งผ่าน Storage Bus ตรง ๆ เหมือนเป็นส่วนต่อของหน้าตัว provider ไอเทมไม่ได้เข้า Interface จริง)
2. ผ่านกลไกที่อธิบายไว้ใน [pipe subnet](pipe-subnet.md#providing-to-multiple-places)
   ถังจะไปอยู่ใน <ItemLink id="minecraft:dispenser" />
3. <ItemLink id="minecraft:comparator" /> ตรวจพบถังใน dispenser จึงจ่ายพลังงานให้ dispenser พร้อมกับล็อก
   <ItemLink id="pattern_provider" />
4. Dispenser เทของเหลวออกจากถัง ตอนนี้ในตัวมันมีถังเปล่าอยู่
5. <ItemLink id="import_bus" /> ดึงถังเปล่าออกจาก dispenser แล้วเก็บผ่าน
   <ItemLink id="storage_bus" /> เข้า pattern provider ส่งกลับเข้าเครือข่ายหลัก
6. Comparator เห็นว่า dispenser ว่างแล้ว จึงปลดล็อก provider