---
navigation:
  parent: example-setups/example-setups-index.md
  title: ฟาร์ม Amethyst
  icon: minecraft:amethyst_shard
---

# การทำฟาร์ม Amethyst

แม้ <ItemLink id="growth_accelerator" /> ใช้กับ amethyst ได้ แต่วิธีกรอง [certus bud](../items-blocks-machines/budding_certus.md) ตามปกติ
ด้วย <ItemLink id="annihilation_plane" /> ใช้กับ amethyst bud ไม่ได้ ต่างจาก certus bud ที่ยังไม่โตเต็มที่ซึ่งดรอป
<ItemLink id="certus_quartz_dust" /> amethyst bud ที่ยังไม่โตเต็มที่ไม่ดรอปอะไรเลย annihilation plane จึงทุบมันทุกครั้ง
เพราะเครือข่ายเก็บ "ความว่างเปล่า" ได้เสมอ

วิธีแก้คือเอนชานต์ annihilation plane ด้วย Silk Touch ทำให้ amethyst bud ที่ยังไม่โตเต็มที่ *ดรอป* บางอย่าง (บล็อก bud ในระยะต่าง ๆ) จึงกรองได้

จากนั้นต้องวาง <ItemLink id="minecraft:amethyst_cluster" /> กลับด้วย <ItemLink id="formation_plane" /> แล้วให้ <ItemLink id="annihilation_plane" /> ที่ไม่มี Silk Touch ทุบอีกครั้ง เพื่อรับ <ItemLink id="minecraft:amethyst_shard" />

โปรดทราบว่าเนื่องจาก cluster มีทิศทาง ต้องมีผิวหน้าของบล็อกตันอยู่ตรงข้าม formation plane พอดี

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) Annihilation Plane ตัวที่ 1: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Silk Touch
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) Formation Plane: กรองเป็น Amethyst Cluster
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) Annihilation Plane ตัวที่ 2: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Fortune ได้
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) Storage Bus ตัวที่ 1: กรองเป็น Amethyst Shard
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) Storage Bus ตัวที่ 2: กรองเป็น Amethyst Shard ตั้ง priority สูงกว่า storage หลักของคุณ
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="annihilation_plane" /> ตัวแรก (1) ไม่มี GUI และตั้งค่าไม่ได้ แต่ต้องเอนชานต์ Silk Touch
* <ItemLink id="formation_plane" /> (2) กรองเป็น <ItemLink id="minecraft:amethyst_cluster" />
* <ItemLink id="annihilation_plane" /> ตัวที่สอง (3) ไม่มี GUI และตั้งค่าไม่ได้ แต่เอนชานต์ Fortune ได้
* <ItemLink id="storage_bus" /> ตัวแรก (4) กรองเป็น <ItemLink id="minecraft:amethyst_shard" />
* <ItemLink id="storage_bus" /> ตัวที่สอง (5) กรองเป็น <ItemLink id="minecraft:amethyst_shard" /> และตั้ง
  [priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูงกว่า storage หลักของคุณ

## หลักการทำงาน

1. <ItemLink id="annihilation_plane" /> ตัวแรกพยายามทุบสิ่งที่อยู่ตรงหน้า แต่ทุบได้เฉพาะ <ItemLink id="minecraft:amethyst_cluster" />
    เพราะ storage เดียวบน subnet คือ <ItemLink id="formation_plane" /> ที่กรองเป็น amethyst cluster ซึ่งใช้ได้เพราะ
plane เอนชานต์ Silk Touch ไว้ ไม่เช่นนั้นมันจะทุบ bud ที่ยังไม่โตเต็มที่ได้ เพราะ bud เหล่านั้นไม่ดรอปอะไร
2. <ItemLink id="formation_plane" /> วาง cluster ลงบนบล็อกที่อยู่ตรงข้าม
3. <ItemLink id="annihilation_plane" /> ตัวที่สองทุบ cluster ได้ <ItemLink id="minecraft:amethyst_shard" />
4. <ItemLink id="storage_bus" /> ตัวแรกเก็บ shard ลงในถัง จริง ๆ แล้วไม่จำเป็นต้องกรอง เพราะสิ่งเดียว
ที่ annihilation plane ตัวที่สองควรเจอคือ cluster ที่โตเต็มที่แล้ว
5. <ItemLink id="storage_bus" /> ตัวที่สองให้เครือข่ายหลักเข้าถึง amethyst shard ทั้งหมดในถัง ตั้งไว้ที่
[priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูง เพื่อให้ amethyst shard
ถูกใส่กลับในถังก่อน แทนที่จะเข้า storage หลักของคุณ
