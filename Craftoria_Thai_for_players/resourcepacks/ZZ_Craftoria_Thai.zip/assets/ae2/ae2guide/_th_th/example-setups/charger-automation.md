---
navigation:
  parent: example-setups/example-setups-index.md
  title: ระบบ Charger อัตโนมัติ
  icon: charger
---

# ระบบ Charger อัตโนมัติ

โปรดทราบว่าชุดนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ต่อเข้ากับระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
ของคุณ ถ้าต้องการทำ <ItemLink id="charger" /> ให้อัตโนมัติแบบแยกเดี่ยว ใช้ hopper กับหีบแทนได้

การทำ <ItemLink id="charger" /> ให้อัตโนมัติค่อนข้างง่าย <ItemLink id="pattern_provider" /> ส่งวัตถุดิบเข้า charger แล้ว [pipe subnet](pipe-subnet.md)
หรือท่อไอเทมอื่นส่งผลลัพธ์กลับเข้า provider

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Pattern Provider: ใช้ค่าตั้งต้นตามปกติ พร้อมใส่ processing pattern ที่เกี่ยวข้อง และจ่ายพลังงานให้ charger ด้วย

        ![Charger Pattern](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        (2) Import Bus: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (3) Storage Bus: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="pattern_provider" /> (1) ใช้ค่าตั้งต้นตามปกติ พร้อมใส่ <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
  และจ่าย [พลังงาน](../ae2-mechanics/energy.md) ให้ <ItemLink id="charger" /> ด้วย เพราะทำหน้าที่เหมือน [สายเคเบิล](../items-blocks-machines/cables.md)
  
    ![Charger Pattern](../assets/diagrams/charger_pattern.png)

* <ItemLink id="import_bus" /> (2) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="storage_bus" /> (3) ใช้ค่าตั้งต้นตามปกติ

## หลักการทำงาน

1. <ItemLink id="pattern_provider" /> ส่งวัตถุดิบเข้า <ItemLink id="charger" />
2. Charger ชาร์จตามหน้าที่ของมัน
3. <ItemLink id="import_bus" /> บน subnet สีเขียวดึงผลลัพธ์ออกจาก charger แล้วพยายามเก็บลง
   [network storage](../ae2-mechanics/import-export-storage.md)
4. ที่เก็บเดียวบน subnet สีเขียวคือ <ItemLink id="storage_bus" /> ซึ่งเก็บไอเทมผลลัพธ์ลงใน pattern provider ส่งกลับเข้าเครือข่ายหลัก
