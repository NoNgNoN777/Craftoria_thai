---
navigation:
  parent: example-setups/example-setups-index.md
  title: ฟาร์ม Certus ขั้นสูง
  icon: certus_quartz_crystal
  position: 120
---

# ฟาร์ม Certus ขั้นสูง

ชุดนี้คือ [Semi-Auto Certus Farm](semiauto-certus-farm.md) นั่นเอง เพียงแต่ผนวกเข้ากับระบบ ME
ของคุณอย่างสมบูรณ์

แทนที่จะสะสม budding block ไว้กองใหญ่แล้วคอยรีเฟรชด้วยมือเป็นครั้งคราว
ชุดนี้ใช้ [Charger Automation](charger-automation.md) และ [Throwing-In-Water Automation](throw-in-water-automation.md)
เพื่อทำเรื่องนี้อัตโนมัติ

ดูความเร็วโดยประมาณได้ที่ [Certus Growth](../ae2-mechanics/certus-growth.md)

**นี่คือชุดที่ซับซ้อน มีของซ่อนอยู่หลังของอื่น ให้หมุนกล้องดูจากทุกมุม**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Annihilation Plane #1: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Fortune ได้
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) Storage Bus #1: กรองเฉพาะ Certus Quartz Crystal
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Subnet ตัวทุบคลัสเตอร์
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Annihilation Plane #2: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Silk Touch ไว้
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) Storage Bus #2: กรองเฉพาะ Certus Quartz Block
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Subnet ตัวทุบบล็อก Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Formation Plane: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) Import Bus: กรองเฉพาะ Flawed Budding Certus Quartz
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Subnet ตัววาง Budding Block
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) Storage Bus #3: กรองเฉพาะ Certus Quartz Crystal ตั้งลำดับความสำคัญให้สูงกว่าที่เก็บหลักของคุณ
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) Interface: ตั้งให้เก็บ Flawed Budding Certus Quartz ไว้ในตัวเอง 1 ชิ้น และใส่ Crafting Card ไว้
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        ไปยังเครือข่ายหลัก, Charger Automation และ Throwing-In-Water Automation
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## การตั้งค่า

### ตัวทุบคลัสเตอร์:

* <ItemLink id="annihilation_plane" /> ตัวแรก (1) ไม่มี GUI จึงตั้งค่าไม่ได้ แต่เอนชานต์ Fortune ได้
* <ItemLink id="storage_bus" /> ตัวแรก (2) กรองเฉพาะ <ItemLink id="certus_quartz_crystal" />

### ตัวทุบบล็อก Certus:

* <ItemLink id="annihilation_plane" /> ตัวที่สอง (3) ไม่มี GUI จึงตั้งค่าไม่ได้ แต่ต้องเอนชานต์ Silk Touch
* <ItemLink id="storage_bus" /> ตัวที่สอง (4) กรองเฉพาะ <ItemLink id="quartz_block" />

### ตัววาง Budding Block:

* <ItemLink id="formation_plane" /> (5) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="import_bus" /> (6) กรองเฉพาะ <ItemLink id="flawed_budding_quartz" />

### บนเครือข่ายหลัก:

* <ItemLink id="storage_bus" /> ตัวที่สาม (7) กรองเฉพาะ <ItemLink id="certus_quartz_crystal" /> และตั้ง
  [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority) ให้สูงกว่าที่เก็บหลักของคุณ
* <ItemLink id="interface" /> (8) ตั้งให้เก็บ Flawed Budding Certus Quartz ไว้ในตัวเอง 1 ชิ้น และใส่ <ItemLink id="crafting_card" /> ไว้

## หลักการทำงาน

### ตัวทุบคลัสเตอร์:

Subnet ตัวทุบคลัสเตอร์ทำงานคล้ายกับ subnet ใน [ฟาร์ม certus แบบง่าย](simple-certus-farm.md) มาก

1. <ItemLink id="annihilation_plane" /> พยายามทุบสิ่งที่อยู่ด้านหน้า แต่ทุบได้เฉพาะ <ItemLink id="quartz_cluster" />
   เพราะที่เก็บเดียวบน subnet คือ <ItemLink id="storage_bus" /> ที่กรองเฉพาะ <ItemLink id="certus_quartz_crystal" />
2. <ItemLink id="storage_bus" /> เก็บ certus quartz crystal ลงในถัง

### ตัวทุบบล็อก Certus

Subnet ตัวทุบบล็อก Certus มีหน้าที่ทุบ budding block ที่หมดอายุแล้ว เมื่อมันกลายเป็น <ItemLink id="quartz_block" /> ธรรมดา
ทำงานคล้ายกับตัวทุบคลัสเตอร์

1. <ItemLink id="annihilation_plane" /> พยายามทุบสิ่งที่อยู่ด้านหน้า แต่ทุบได้เฉพาะ <ItemLink id="quartz_block" />
   เพราะที่เก็บเดียวบน subnet คือ <ItemLink id="storage_bus" /> ที่กรองเฉพาะ <ItemLink id="quartz_block" /> 
   Plane ต้องมี Silk Touch เพื่อให้ budding block ไม่เสื่อมสภาพเมื่อถูกทุบ และ plane จะได้ไม่ทุบมันก่อนเวลา
2. <ItemLink id="storage_bus" /> เก็บ certus quartz block ลงใน <ItemLink id="interface" /> เพื่อให้
   [Throwing-In-Water Automation](throw-in-water-automation.md) นำไปทำ <ItemLink id="flawed_budding_quartz" /> ใหม่

### ตัววาง Budding Block

Subnet ตัววาง budding block มีหน้าที่วาง <ItemLink id="flawed_budding_quartz" /> ก้อนใหม่ เมื่อ subnet ตัวทุบทุบก้อนเก่าที่หมดอายุไปแล้ว

1. <ItemLink id="import_bus" /> นำ budding block จาก <ItemLink id="interface" /> เข้า [network storage](../ae2-mechanics/import-export-storage.md)
2. ที่เก็บเดียวบน subnet คือ <ItemLink id="formation_plane" /> ซึ่งวาง budding block ลงไป

### บนเครือข่ายหลัก

* <ItemLink id="storage_bus" /> ทำให้เครือข่ายหลัก (รวมถึง [Charger Automation](charger-automation.md)) เข้าถึง certus quartz crystal ทั้งหมดในถังได้ ตั้งไว้ที่
  [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority) สูง เพื่อให้ certus quartz crystal ถูกส่งกลับ
  ไปเก็บในถังก่อน แทนที่จะเข้าที่เก็บหลักของคุณ
* <ItemLink id="interface" /> ให้ subnet ตัววาง budding block เข้าถึง <ItemLink id="flawed_budding_quartz" /> ได้ และ
    เป็นทางให้ subnet ตัวทุบบล็อก Certus ส่งบล็อกที่หมดอายุกลับเข้าเครือข่ายหลัก
    <ItemLink id="crafting_card" /> ทำให้ Interface ขอ budding block ใหม่จาก [autocrafting](../ae2-mechanics/autocrafting.md) ของเครือข่ายหลักได้