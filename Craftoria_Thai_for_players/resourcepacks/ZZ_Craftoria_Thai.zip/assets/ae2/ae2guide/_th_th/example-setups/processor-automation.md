---
navigation:
  parent: example-setups/example-setups-index.md
  title: ระบบอัตโนมัติสำหรับ Processor
  icon: logic_processor
---

# การผลิต Processor อัตโนมัติ

มีหลายวิธีทำ [processor](../items-blocks-machines/processors.md) ให้เป็นอัตโนมัติ และนี่คือหนึ่งในนั้น

ผังทั่วไปนี้ทำได้กับท่อ conduit หรือ duct ขนส่งไอเทมทุกชนิด หรือสิ่งที่ม็อดนั้นเรียก ตราบเท่าที่กรองได้

![The Process FLow Diagram](../assets/diagrams/processor_flow_diagram.png)

ต่อไปนี้คือรายละเอียดวิธีทำด้วย AE2 ล้วน ๆ โดยใช้ [subnet "ท่อ"](pipe-subnet.md)

โปรดทราบว่าระบบนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ผสานกับระบบ [autocrafting](../ae2-mechanics/autocrafting.md) ของคุณ ถ้าต้องการทำ processor แบบแยกเดี่ยว ให้เปลี่ยน pattern provider เป็นถังอีกใบ แล้วใส่วัตถุดิบลงในถังบนโดยตรง

ระบบนี้ใช้ย้อนกลับกับ AE2 เวอร์ชันก่อนหน้าได้ เพราะแม้ <ItemLink id="inscriber" /> จะมีทิศทางด้าน pipe subnet ก็ยังใส่เข้าและดึงออกจากด้านที่ถูกต้อง

## บทเรียนเรื่องการเข้ารหัส Pattern

บ่อยครั้ง [pattern](../items-blocks-machines/patterns.md) ที่คุณต้องเข้ารหัส **จะไม่ตรงกับที่คุณเห็นใน JEI** หรือสิ่งที่ JEI ใส่ให้เมื่อคุณคลิกปุ่ม + ในกรณีนี้ JEI จะให้ 2 pattern แยกกัน อันหนึ่งสำหรับชิ้นส่วนที่พิมพ์แล้ว และอีกอันสำหรับการประกอบขั้นสุดท้าย และ pattern ชิ้นส่วนที่พิมพ์แล้วจะรวม [press](../items-blocks-machines/presses.md) ไว้ด้วย นี่ไม่ใช่สิ่งที่เราต้องการ เพราะระบบนี้ไม่ได้ทำแบบนั้น เราต้องการ 1 pattern ที่รับวัตถุดิบดิบและให้ processor ที่เสร็จแล้ว และเนื่องจาก press อยู่ใน inscriber แล้ว เราจึงไม่ควรใส่มันใน pattern

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) Pattern Provider: ตั้งค่าเริ่มต้น พร้อม processing pattern ที่เกี่ยวข้อง

        <Row>
            ![Logic Pattern](../assets/diagrams/logic_pattern_small.png)
            ![Calculation Pattern](../assets/diagrams/calculation_pattern_small.png)
            ![Engineering Pattern](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        (2) Storage Bus ตัวที่ 1: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        (3) Export Bus ตัวที่ 1: กรองเป็น Silicon มี Acceleration Card 2 ใบ
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        (4) Export Bus ตัวที่ 2: กรองเป็น Gold Ingot มี Acceleration Card 2 ใบ
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        (5) Export Bus ตัวที่ 3: กรองเป็น Certus Quartz Crystal มี Acceleration Card 2 ใบ
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        (6) Export Bus ตัวที่ 4: กรองเป็น Diamond มี Acceleration Card 2 ใบ
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        (7) Export Bus ตัวที่ 5: กรองเป็น Redstone Dust มี Acceleration Card 2 ใบ
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        (8) Inscriber ตัวที่ 1: ตั้งค่าเริ่มต้น มี Silicon Press และ Acceleration Card 4 ใบ
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        (9) Inscriber ตัวที่ 2: ตั้งค่าเริ่มต้น มี Logic Press และ Acceleration Card 4 ใบ
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        (10) Inscriber ตัวที่ 3: ตั้งค่าเริ่มต้น มี Calculation Press และ Acceleration Card 4 ใบ
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        (11) Inscriber ตัวที่ 4: ตั้งค่าเริ่มต้น มี Engineering Press และ Acceleration Card 4 ใบ
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        (12) Inscriber ตัวที่ 5: ตั้งค่าเริ่มต้น มี Acceleration Card 4 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        (13) Import Bus ตัวที่ 1: ตั้งค่าเริ่มต้น มี Acceleration Card 2 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        (14) Import Bus ตัวที่ 2: ตั้งค่าเริ่มต้น มี Acceleration Card 2 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        (15) Import Bus ตัวที่ 3: ตั้งค่าเริ่มต้น มี Acceleration Card 2 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        (16) Import Bus ตัวที่ 4: ตั้งค่าเริ่มต้น มี Acceleration Card 2 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        (17) Storage Bus ตัวที่ 2: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        (18) Storage Bus ตัวที่ 3: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        (19) Import Bus ตัวที่ 5: ตั้งค่าเริ่มต้น มี Acceleration Card 2 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        (20) Storage Bus ตัวที่ 4: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        Quartz Fiber จ่ายพลังงานให้ Inscriber ทั้ง 3 ตัว เพราะ inscriber ทำหน้าที่เหมือนสายเคเบิลจึงส่งผ่านพลังงานได้
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## การตั้งค่า

* <ItemLink id="pattern_provider" /> (1) ตั้งค่าเริ่มต้น พร้อม <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
  โปรดทราบว่า pattern เหล่านี้ไปจากวัตถุดิบดิบถึง processor ที่เสร็จแล้วโดยตรง และ **ไม่** รวม [press](../items-blocks-machines/presses.md)

  ![Logic Pattern](../assets/diagrams/logic_pattern.png)
  ![Calculation Pattern](../assets/diagrams/calculation_pattern.png)
  ![Engineering Pattern](../assets/diagrams/engineering_pattern.png)

* <ItemLink id="storage_bus" /> (2, 17, 18, 20) ตั้งค่าเริ่มต้น
* <ItemLink id="export_bus" /> (3-7) กรองเป็นวัตถุดิบที่เกี่ยวข้อง มี <ItemLink id="speed_card" /> 2 ใบ
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* <ItemLink id="import_bus" /> (13-16, 19) ตั้งค่าเริ่มต้น มี <ItemLink id="speed_card" /> 2 ใบ
* <ItemLink id="inscriber" /> ทุกตัวตั้งค่าเริ่มต้น มี [press](../items-blocks-machines/presses.md) ที่เกี่ยวข้อง
   และ <ItemLink id="speed_card" /> 4 ใบ
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## หลักการทำงาน

1. <ItemLink id="pattern_provider" /> ดันวัตถุดิบเข้าถัง
2. [Pipe subnet](pipe-subnet.md) ตัวแรก (สีส้ม) ดึง silicon, redstone dust และวัตถุดิบของ processor ที่เกี่ยวข้อง
   (Gold Ingot, Certus Quartz Crystal หรือ Diamond) ออกจากถัง แล้วใส่ใน <ItemLink id="inscriber" /> ที่เกี่ยวข้อง
3. <ItemLink id="inscriber" /> สี่ตัวแรกทำ <ItemLink id="printed_silicon" /> และ <ItemLink id="printed_logic_processor" />,
   <ItemLink id="printed_calculation_processor" /> หรือ <ItemLink id="printed_engineering_processor" />
4. [Pipe subnet](pipe-subnet.md) ตัวที่สองและสาม (สีเขียว) นำแผงวงจรที่พิมพ์แล้วออกจาก <ItemLink id="inscriber" /> สี่ตัวแรก
    แล้วใส่ใน <ItemLink id="inscriber" /> ตัวที่ห้าซึ่งประกอบขั้นสุดท้าย
5. <ItemLink id="inscriber" /> ตัวที่ห้าประกอบ [processor](../items-blocks-machines/processors.md)
6. [Pipe subnet](pipe-subnet.md) ตัวที่สี่ (สีม่วง) ใส่ processor ลงใน pattern provider ส่งกลับเครือข่ายหลัก