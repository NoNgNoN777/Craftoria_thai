---
navigation:
  parent: example-setups/example-setups-index.md
  title: ระบบ Throwing-In-Water อัตโนมัติ
  icon: fluix_crystal
---

# ระบบสูตรโยนของลงน้ำอัตโนมัติ

โปรดทราบว่าชุดนี้ใช้ <ItemLink id="pattern_provider" /> จึงออกแบบมาให้ต่อเข้ากับระบบ [autocrafting](../ae2-mechanics/autocrafting.md)
ของคุณ

บางสูตรต้องโยนไอเทมลงน้ำ (แต่ชุดคล้ายกันนี้ใช้โยนไอเทมลงที่อื่นได้ด้วย)
ทำให้อัตโนมัติได้ด้วย <ItemLink id="formation_plane" />, <ItemLink id="annihilation_plane" /> และโครงสร้างสนับสนุนอีกเล็กน้อย
(โดยพื้นฐานคือ [pipe subnet](pipe-subnet.md) ที่ดัดแปลง 2 ชุด)

ชุดนี้ออกแบบมาใช้ร่วมกับ [charger automation](charger-automation.md) เพื่อจัดหา <ItemLink id="charged_certus_quartz_crystal" />

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) Pattern Provider: ใช้ค่าตั้งต้นตามปกติ พร้อมใส่ processing pattern ที่เกี่ยวข้อง

        ![Fluix Pattern](../assets/diagrams/fluix_pattern_small.png) ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) Interface: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) Formation Plane: ตั้งให้ทิ้งวัตถุดิบเป็นไอเทม
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) Annihilation Plane: ไม่มี GUI ให้ตั้งค่า
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) Storage Bus: กรองเฉพาะผลลัพธ์ของ pattern
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        ไปยังเครือข่ายหลักและ Charger Automation
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## การตั้งค่าและ Pattern

* <ItemLink id="pattern_provider" /> (1) ใช้ค่าตั้งต้นตามปกติ พร้อมใส่ <ItemLink id="processing_pattern" /> ที่เกี่ยวข้อง
  * สำหรับ <ItemLink id="fluix_crystal" /> ใช้สูตรตั้งต้นจาก JEI/REI ได้เลย

    ![Fluix Pattern](../assets/diagrams/fluix_pattern.png)

  * สำหรับ <ItemLink id="flawed_budding_quartz" /> ควรทำตรง ๆ จาก <ItemLink id="quartz_block" /> จะดีที่สุด
    เพื่อเลี่ยงปัญหาที่วัตถุดิบของสูตรหนึ่งเป็นผลลัพธ์ของอีกสูตรหนึ่ง จน storage bus กรองไม่ได้

    ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern.png)

* <ItemLink id="interface" /> (2) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="formation_plane" /> (3) ตั้งให้ทิ้งวัตถุดิบเป็นไอเทม
* <ItemLink id="annihilation_plane" /> (4) ไม่มี GUI จึงตั้งค่าไม่ได้
* <ItemLink id="storage_bus" /> (5) กรองเฉพาะผลลัพธ์ของ pattern

## หลักการทำงาน

1.  <ItemLink id="pattern_provider" /> ส่งวัตถุดิบเข้า <ItemLink id="interface" /> ที่อยู่ด้านข้างบน subnet สีเขียว
2.  Interface (ที่ตั้งค่าไม่ให้เก็บอะไรเป็นค่าตั้งต้น) พยายามส่งของในตัวเข้า [network storage](../ae2-mechanics/import-export-storage.md)
3.  ที่เก็บเดียวบน subnet สีเขียวคือ <ItemLink id="formation_plane" /> ซึ่งทิ้งไอเทมที่ได้รับลงในน้ำ
4.  <ItemLink id="annihilation_plane" /> บน subnet สีส้มพยายามเก็บไอเทมที่เพิ่งถูกทิ้ง แต่ทำไม่ได้ เพราะ
    <ItemLink id="storage_bus" /> ที่อยู่บน pattern provider (ที่เก็บเดียวบน subnet สีส้ม) กรองให้รับเฉพาะผลลัพธ์ของการคราฟต์ที่เป็นไปได้
5.  ไอเทมเปลี่ยนรูปในโลกตามสูตร
6.  ตอนนี้ annihilation plane เก็บไอเทมด้านหน้าได้แล้ว เพราะ storage bus อนุญาตให้เก็บ
7.  Storage bus เก็บไอเทมผลลัพธ์ลงใน pattern provider ส่งกลับเข้าเครือข่าย
