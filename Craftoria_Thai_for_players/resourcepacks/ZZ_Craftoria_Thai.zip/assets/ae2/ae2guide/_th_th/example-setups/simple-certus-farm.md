---
navigation:
  parent: example-setups/example-setups-index.md
  title: ฟาร์ม Certus แบบง่าย
  icon: certus_quartz_crystal
  position: 110
---

# ฟาร์ม Certus แบบง่าย

ดังที่กล่าวใน [การเติบโตของ Certus](../ae2-mechanics/certus-growth.md) การเก็บเกี่ยว <ItemLink id="certus_quartz_crystal" /> อัตโนมัติ
ต้องใช้ <ItemLink id="annihilation_plane" /> และ <ItemLink id="storage_bus" /> 
<ItemLink id="growth_accelerator" /> ใช้เร่งการงอกของผลึก certus quartz อย่างมาก แล้ว plane
จะทุบ <ItemLink id="quartz_cluster" /> ที่โตเต็มที่ โดยกรองอาศัยข้อดีที่โชคดีเป็นพิเศษคือผลึก
certus ที่ยังไม่โตเต็มที่ดรอป <ItemLink id="certus_quartz_dust" /> แทนที่จะไม่ดรอปอะไรเลย

ฟาร์มนี้ทำงานอัตโนมัติเต็มรูปแบบเมื่อใช้ <ItemLink id="flawless_budding_quartz" /> แต่ถ้าเป็น budding certus quartz แบบ flawed, chipped และ damaged คุณต้องเปลี่ยน budding block เอง หรือทำอัตโนมัติตามที่อธิบายใน [ฟาร์ม Certus กึ่งอัตโนมัติ](semiauto-certus-farm.md) และ [ฟาร์ม Certus ขั้นสูง](advanced-certus-farm.md)

ดู [การเติบโตของ Certus](../ae2-mechanics/certus-growth.md) สำหรับความเร็วโดยประมาณ

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        (1) Annihilation Plane: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Fortune ได้
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        (2) Storage Bus ตัวที่ 1: กรองเป็น Certus Quartz Crystal
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        (3) Storage Bus ตัวที่ 2: กรองเป็น Certus Quartz Crystal ตั้ง priority สูงกว่า storage หลัก
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="annihilation_plane" /> ตัวแรก (1) ไม่มี GUI และตั้งค่าไม่ได้ แต่เอนชานต์ Fortune ได้
* <ItemLink id="storage_bus" /> ตัวแรก (2) กรองเป็น <ItemLink id="certus_quartz_crystal" />
* <ItemLink id="storage_bus" /> ตัวที่สอง (3) กรองเป็น <ItemLink id="certus_quartz_crystal" /> และตั้ง
  [priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูงกว่า storage หลัก

## หลักการทำงาน

1. <ItemLink id="annihilation_plane" /> พยายามทุบสิ่งที่อยู่ตรงหน้า แต่ทุบได้เฉพาะ <ItemLink id="quartz_cluster" />
   เพราะ storage เดียวบน subnet คือ <ItemLink id="storage_bus" /> ที่กรองเป็น <ItemLink id="certus_quartz_crystal" />
4. <ItemLink id="storage_bus" /> ตัวแรกเก็บผลึก certus quartz ลงในถัง
5. <ItemLink id="storage_bus" /> ตัวที่สองให้เครือข่ายหลักเข้าถึงผลึก certus quartz ทั้งหมดในถัง ตั้งไว้ที่
   [priority](../ae2-mechanics/import-export-storage.md#storage-priority) สูง เพื่อให้ผลึก certus quartz
   ถูกใส่กลับในถังก่อน แทนที่จะเข้า storage หลักของคุณ
