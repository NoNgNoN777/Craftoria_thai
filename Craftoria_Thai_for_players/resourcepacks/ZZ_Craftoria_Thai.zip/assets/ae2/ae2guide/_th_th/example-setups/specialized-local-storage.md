---
navigation:
  parent: example-setups/example-setups-index.md
  title: ที่เก็บในพื้นที่เฉพาะทาง
  icon: drive
---

# ที่เก็บในพื้นที่เฉพาะทาง

เมื่อใช้ [พฤติกรรมพิเศษอย่างหนึ่งของ Interface](../items-blocks-machines/interface.md#special-interactions)
[subnetwork](../ae2-mechanics/subnetworks.md) จะแสดงสิ่งที่อยู่ในที่เก็บของตัวเองให้เครือข่ายหลักเห็นได้ โดยไม่ต้องมองเห็น
ที่เก็บของเครือข่ายหลัก และใช้ [channel](../ae2-mechanics/channels.md) เพียง 1 ช่อง

เหมาะกับที่เก็บในพื้นที่ของฟาร์มบางแห่ง เพื่อไม่ให้ไอเทมล้นเข้าที่เก็บหลักของคุณ

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        (1) วิธีนำไอเทมเข้าอย่างใดอย่างหนึ่ง (ในที่นี้คือ interface)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        (2) Drive: ใส่ cell ไว้ข้างใน cell ควรกรองเฉพาะสิ่งที่ฟาร์มผลิตออกมา
        cell ใส่ Equal Distribution Card และ Overflow Destruction Card ได้
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        (3) Crafting Terminal: เห็นสิ่งที่อยู่ใน Drive บน subnet ได้ แต่ไม่เห็นสิ่งที่อยู่ในที่เก็บของเครือข่ายหลักของคุณ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (4) Interface #2: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        (5) Storage Bus: ตั้งลำดับความสำคัญให้สูงกว่าที่เก็บหลัก กรองเฉพาะสิ่งที่ฟาร์มผลิตออกมาได้
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
        Crafting Terminal: เห็นทั้งสิ่งที่อยู่ในที่เก็บของเครือข่ายหลัก *และ* subnetwork
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="interface" /> ตัวแรก (1) รับไอเทมจากฟาร์มของคุณ แล้วส่งเข้า subnet เฉย ๆ
* <ItemLink id="drive" /> (2) ใส่ [cell](../items-blocks-machines/storage_cells.md) ไว้ข้างใน cell ควร
  [กำหนด partition](../items-blocks-machines/cell_workbench.md) ให้ตรงกับสิ่งที่ฟาร์มผลิตออกมา
  cell ใส่ <ItemLink id="equal_distribution_card" /> และ <ItemLink id="void_card" /> ได้
* <ItemLink id="interface" /> ตัวที่สอง (4) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="storage_bus" /> ตั้ง [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority)
  ให้สูงกว่าที่เก็บหลัก กรองเฉพาะสิ่งที่ฟาร์มผลิตออกมาได้

## หลักการทำงาน

* <ItemLink id="interface" /> บน subnet ทำให้ <ItemLink id="storage_bus" /> บนเครือข่ายหลักเห็นสิ่งที่อยู่ใน <ItemLink id="drive" />
ซึ่งหมายความว่า Storage Bus ดึงไอเทมจาก cell ใน drive และส่งไอเทมเข้า cell ได้โดยตรง
* Storage Bus ตั้งไว้ที่ [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority) สูง เพื่อให้ไอเทมถูกส่งกลับ
  ไปเก็บใน subnet ก่อน แทนที่จะเข้าที่เก็บหลักของคุณ
* ที่สำคัญคือ ถ้า cell ใน subnet เต็ม ไอเทมจะไม่ล้นเข้าเครือข่ายหลัก ถ้าฟาร์มเป็นแบบที่
จะพังเมื่อของค้าง ใช้ <ItemLink id="void_card" /> เพื่อลบไอเทมส่วนเกินทิ้งแทนได้ 
* ถ้าฟาร์มผลิตไอเทมหลายอย่าง <ItemLink id="equal_distribution_card" /> ช่วยไม่ให้ไอเทมอย่างเดียวกินที่ใน cell จนเต็ม
แล้วทำให้ไอเทมอื่นเก็บไม่ได้