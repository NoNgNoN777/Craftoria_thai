---
navigation:
  parent: example-setups/example-setups-index.md
  title: ระบบเพิ่มแร่ด้วย Fortune อัตโนมัติ
  icon: minecraft:raw_iron
---

# ระบบเพิ่มแร่ด้วย Fortune อัตโนมัติ

<ItemLink id="annihilation_plane" /> เอนชานต์ด้วยเอนชานต์ของพิคแอกซ์ได้ทุกชนิด รวมถึง Fortune ดังนั้นการใช้งานที่ชัดเจนคือ
ใส่ Fortune ให้ plane ไม่กี่ตัว แล้วใช้ <ItemLink id="formation_plane" /> และ <ItemLink id="annihilation_plane" /> วางและ
ทุบแร่อย่างรวดเร็ว

โปรดทราบว่า <ItemLink id="import_bus" /> ต้อง "ไล่ความเร็วขึ้น" ชุดนี้จึงเริ่มช้าแล้วถึงความเร็วเต็มที่ภายในไม่กี่วินาที

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        (1) Import Bus: ใส่ Acceleration Card ไว้ไม่กี่ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        (2) Formation Plane: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        (3) Annihilation Plane: ไม่มี GUI ให้ตั้งค่า แต่เอนชานต์ Fortune ไว้
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        (4) Storage Bus: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        ทางเข้า
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        ทางออก
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

*   <ItemLink id="import_bus" /> (1) ใส่ <ItemLink id="speed_card" /> ไว้ไม่กี่ใบ ยิ่งมี formation plane ในชุดมาก
    ก็ต้องใส่มากขึ้น เพราะทำให้ import bus ดึงไอเทมได้ทีละมากขึ้น
*   <ItemLink id="formation_plane" /> (2) ใช้ค่าตั้งต้นตามปกติ
*   <ItemLink id="annihilation_plane" /> (3) ไม่มี GUI จึงตั้งค่าไม่ได้ แต่เอนชานต์ Fortune ไว้
*   <ItemLink id="storage_bus" /> (4) ใช้ค่าตั้งต้นตามปกติ

## หลักการทำงาน

1.  <ItemLink id="import_bus" /> บน subnet สีเขียวนำบล็อกจากถังใบแรกเข้า [network storage](../ae2-mechanics/import-export-storage.md)
2.  ที่เก็บเดียวบน subnet สีเขียวคือ <ItemLink id="formation_plane" /> ซึ่งวางบล็อกลงไป
3.  <ItemLink id="annihilation_plane" /> บน subnet สีส้มทุบบล็อก โดยใช้ Fortune กับบล็อกเหล่านั้น
4.  <ItemLink id="storage_bus" /> บน subnet สีส้มเก็บผลลัพธ์จากการทุบลงในถังใบที่สอง
