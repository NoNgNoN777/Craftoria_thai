---
navigation:
  parent: example-setups/example-setups-index.md
  title: ตัวเทหรือเติม Cell
  icon: io_port
---

# ตัวเทหรือเติม Cell

บางคนอาจถามว่า "ฉันจะเทของใน cell ลงหีบ ลิ้นชัก หรือกระเป๋าเป้อย่างรวดเร็วได้อย่างไร หรือในทางกลับกัน เติม cell จากสิ่งเหล่านั้น"

คำตอบคือใช้ <ItemLink id="io_port" /> ร่วมกับ subnet เพื่อจำกัดว่ามันวางไอเทมลงที่ไหนหรือดึงไอเทมจากที่ไหนได้

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) IO Port: ตั้งเป็น "Transfer data to Network" หรือ "Transfer data to Storage Cell" ได้ด้วยปุ่มลูกศร
        ตรงกลาง GUI มี Acceleration Card 3 ใบ
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) Storage Bus: ตั้งค่าเริ่มต้น
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        วางสิ่งที่คุณต้องการเติมหรือเทออกไว้ตรงนี้
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        Quartz Fiber: ต้องใช้เฉพาะเมื่อแหล่งพลังงานเป็นเครือข่ายอื่น
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        ไปยังแหล่งพลังงานบางอย่าง เช่น เครือข่ายอื่น หรือ Energy Acceptor
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="io_port" /> (1) ตั้งเป็น "Transfer data to Network" หรือ "Transfer data to Storage Cell" ได้ด้วยปุ่มลูกศร
  ตรงกลาง GUI มี acceleration card 3 ใบเพื่อความเร็วสูงสุด
* <ItemLink id="storage_bus" /> (2) ตั้งค่าเริ่มต้น

## หลักการทำงาน

### ในโหมด "Transfer To Network"

1. <ItemLink id="io_port" /> พยายามเทเนื้อหาของ [storage cell](../items-blocks-machines/storage_cells.md) ที่ใส่ไว้
    เข้า [network storage](../ae2-mechanics/import-export-storage.md)
2. Storage เดียวบน subnet คือ <ItemLink id="storage_bus" /> ซึ่งเก็บไอเทมหรือของเหลวหรืออื่น ๆ ลงในสิ่งใดก็ตาม
    ที่คุณวางไว้ตรงหน้ามัน
* <ItemLink id="energy_cell" /> ให้บัฟเฟอร์ [พลังงาน](../ae2-mechanics/energy.md) ที่ใหญ่พอ เพื่อให้เครือข่ายไม่
    หมดจากการใช้พลังงานในการย้ายไอเทมจำนวนมากต่อ gametick

### ในโหมด "Transfer To Storage Cell"

1. <ItemLink id="io_port" /> พยายามเทเนื้อหาของ [storage ของเครือข่าย](../ae2-mechanics/import-export-storage.md)
   ลงใน [storage cell](../items-blocks-machines/storage_cells.md) ที่ใส่ไว้
2. Storage เดียวบน subnet คือ <ItemLink id="storage_bus" /> ซึ่งดึงไอเทมหรือของเหลวหรืออื่น ๆ ออกจากสิ่งใดก็ตาม
   ที่คุณวางไว้ตรงหน้ามัน
* <ItemLink id="energy_cell" /> ให้บัฟเฟอร์ [พลังงาน](../ae2-mechanics/energy.md) ที่ใหญ่พอ เพื่อให้เครือข่ายไม่
  หมดจากการใช้พลังงานในการย้ายไอเทมจำนวนมากต่อ gametick