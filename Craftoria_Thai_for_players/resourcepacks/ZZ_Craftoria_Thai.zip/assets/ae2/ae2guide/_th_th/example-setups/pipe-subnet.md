---
navigation:
  parent: example-setups/example-setups-index.md
  title: Subnet "ท่อ" ไอเทม/ของเหลว
  icon: storage_bus
---

# Subnet "ท่อ" ไอเทม/ของเหลว

วิธีง่าย ๆ ที่จำลองท่อไอเทมและ/หรือของเหลวด้วย [อุปกรณ์](../ae2-mechanics/devices.md) ของ AE2 ใช้ได้กับทุกอย่างที่คุณจะใช้ท่อไอเทมหรือของเหลวทำ รวมถึงการส่งผลลัพธ์ของการคราฟต์กลับไปที่ <ItemLink id="pattern_provider" />

โดยทั่วไปมีสองวิธีที่ทำได้

## Import Bus -> Storage Bus

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Import Bus: กรองได้
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Storage Bus: กรองได้ ตัวนี้ (และ storage bus อื่นที่คุณต้องการให้เป็นปลายทาง)
        ต้องเป็น storage เดียวบนเครือข่าย
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        ต้นทาง
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        ปลายทาง
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="import_bus" /> (1) บนช่องเก็บของต้นทางนำไอเทมหรือของเหลวเข้ามา และพยายามเก็บลงใน [network storage](../ae2-mechanics/import-export-storage.md) เนื่องจาก storage เดียวบนเครือข่ายคือ <ItemLink id="storage_bus" /> (2) (นี่คือเหตุผลที่เป็น subnet ไม่ใช่เครือข่ายหลักของคุณ) ไอเทมหรือของเหลวจึงถูกวางลงในช่องเก็บของปลายทาง และถูกส่งต่อไป พลังงานมาจาก <ItemLink id="quartz_fiber" /> ทั้ง import bus และ storage bus กรองได้ แต่ถ้าไม่กรอง ระบบจะส่งทุกอย่างที่เข้าถึงได้ ระบบนี้ใช้กับ import bus และ storage bus หลายตัวได้ด้วย

## Storage Bus -> Export Bus

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Storage Bus: กรองได้ ตัวนี้ (และ storage bus อื่นที่คุณต้องการให้เป็นต้นทาง)
        ต้องเป็น storage เดียวบนเครือข่าย
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Export Bus: ต้องกรอง
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        ต้นทาง
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        ปลายทาง
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="export_bus" /> บนช่องเก็บของปลายทางพยายามดึงไอเทมที่อยู่ในตัวกรองจาก [network storage](../ae2-mechanics/import-export-storage.md) เนื่องจาก storage เดียวบนเครือข่ายคือ <ItemLink id="storage_bus" /> (นี่คือเหตุผลที่เป็น subnet ไม่ใช่เครือข่ายหลักของคุณ) ไอเทมหรือของเหลวจึงถูกดึงจากช่องเก็บของต้นทาง และถูกส่งต่อไป พลังงานมาจาก <ItemLink id="quartz_fiber" /> เนื่องจาก export bus ต้องกรองจึงจะทำงาน ระบบนี้จึงทำงานเฉพาะเมื่อคุณกรอง export bus ระบบนี้ใช้กับ storage bus และ export bus หลายตัวได้ด้วย

## ระบบที่ใช้ไม่ได้ (Import Bus -> Export Bus)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        Import Bus: เครือข่ายไม่มี storage จึงไม่มีที่ให้นำเข้า
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        (2) Export Bus: เครือข่ายไม่มี storage จึงไม่มีอะไรให้ส่งออก
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
        ต้นทาง
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
        ปลายทาง
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

ระบบที่มีแค่ import bus กับ export bus จะใช้ไม่ได้ import bus จะพยายามดึงจากช่องเก็บของต้นทางและเก็บไอเทมหรือของเหลวลงใน network storage ส่วน export bus จะพยายามดึงจาก network storage และใส่ไอเทมหรือของเหลวลงในช่องเก็บของปลายทาง แต่เนื่องจากเครือข่ายนี้ **ไม่มี storage** import bus จึงนำเข้าไม่ได้ และ export bus ก็ส่งออกไม่ได้ จึงไม่เกิดอะไรขึ้น

## นำเข้าและส่งออกผ่าน 1 ด้าน

สมมติว่าคุณมีเครื่องที่รับอินพุตและให้ดึงเอาต์พุตออกผ่าน 1 ด้าน (เช่น <ItemLink id="charger" />) คุณทั้งดันวัตถุดิบเข้าและดึงผลลัพธ์ออกได้ โดยรวม 2 วิธีของ pipe subnet เข้าด้วยกัน

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        (1) Import Bus: กรองได้
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (2) Storage Bus: กรองได้ ตัวนี้ (และ storage bus อื่นที่คุณต้องการให้ดันเข้าและดึงไอเทม)
        ต้องเป็น storage เดียวบนเครือข่าย
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (3) สิ่งที่คุณต้องการดันเข้าและดึงออก: ในที่นี้คือ Charger
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        (4) Export Bus: ต้องกรอง
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
        ต้นทาง
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
        ปลายทาง
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Interface

ปรากฏว่ามี [อุปกรณ์](../ae2-mechanics/devices.md) นอกจาก import bus และ export bus ที่ดันไอเทมเข้าและดึงไอเทมออกจาก [network storage](../ae2-mechanics/import-export-storage.md) ได้ด้วย! ที่เกี่ยวข้องในที่นี้คือ <ItemLink id="interface" /> ถ้ามีไอเทมถูกใส่เข้ามาที่ interface ไม่ได้ตั้งให้สต็อก interface จะดันมันเข้า network storage ซึ่งใช้ประโยชน์ได้คล้ายท่อ import bus -> storage bus ส่วนการตั้ง interface ให้สต็อกไอเทมบางอย่างจะดึงมันจาก network storage คล้ายท่อ storage bus -> export bus ตั้ง interface ให้สต็อกบางอย่างและไม่สต็อกบางอย่างได้ ทำให้ดันเข้าและดึงผ่าน storage bus จากระยะไกลได้ ถ้าคุณมีเหตุผลบางอย่างที่อยากทำแบบนั้น

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        Interface
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
        Interface
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## หนึ่งต่อหลาย หลายต่อหนึ่ง (และหลายต่อหลาย)

แน่นอนว่าคุณไม่จำเป็นต้องใช้ <ItemLink id="import_bus" /> หรือ <ItemLink id="export_bus" /> หรือ <ItemLink id="storage_bus" /> เพียงตัวเดียว

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Providing To Multiple Places

จากทั้งหมดนี้ เราได้วิธีส่งวัตถุดิบจากด้านหนึ่งของ <ItemLink id="pattern_provider" /> ไปยังหลายตำแหน่ง เช่น กลุ่มเครื่อง หรือหลายด้านของเครื่องเดียว

เราไม่ต้องการท่อ import -> storage หรือ storage -> export เพราะ <ItemLink id="pattern_provider" /> ไม่เคยมีวัตถุดิบอยู่ในตัวจริง ๆ แต่ provider *ดัน* วัตถุดิบไปยังช่องเก็บของที่อยู่ติดกัน เราจึงต้องมีช่องเก็บของที่อยู่ติดกันที่นำเข้าไอเทมได้ด้วย

ฟังดูเหมือน... <ItemLink id="interface" /> ใช่ไหม! ตรวจให้แน่ใจว่า provider อยู่ในโหมด directional หรือ flat subpart และ/หรือ interface อยู่ในโหมด flat subpart เพื่อไม่ให้ทั้งสองต่อเป็นเครือข่ายเดียวกัน

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (ต้องเป็นแบบ flat ไม่ใช่ fullblock)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Storage Bus
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        ที่ที่คุณต้องการให้ pattern ส่งไป (หลายเครื่อง หรือหลายด้านของ 1 เครื่อง)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>