---
navigation:
  parent: example-setups/example-setups-index.md
  title: การคราฟต์แบบวนซ้ำ
  icon: minecraft:netherite_upgrade_smithing_template
---

# ระบบคราฟต์แบบวนซ้ำ

ดังที่กล่าวใน [autocrafting](../ae2-mechanics/autocrafting.md) อัลกอริทึมวางแผน autocrafting จัดการสูตรที่ผลลัพธ์หลักเป็นหนึ่งในวัตถุดิบไม่ได้ เช่น ไม่สามารถทำสำเนา <ItemLink id="minecraft:netherite_upgrade_smithing_template" /> ได้

วิธีหนึ่งคือใช้ความสามารถของ <ItemLink id="level_emitter" /> ในการแสร้งเป็น [pattern](../items-blocks-machines/patterns.md)

จากนั้นใช้มันเปิดระบบเล็ก ๆ ที่คราฟต์ซ้ำตลอดเวลา ในกรณีนี้ เราจะดูระบบสำหรับทำสำเนา <ItemLink id="minecraft:netherite_upgrade_smithing_template" />

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Interface: ตั้งให้เก็บสต็อกวัตถุดิบเพิ่มเติมที่ต้องใช้ ได้แก่ diamond และ netherrack
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        (2) Level Emitter: กำหนดค่าเป็น "netherite smithing template" และตั้งเป็น "Emit Redstone to craft item".
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (3) Import Bus #1: กรองเฉพาะไอเทมที่ Interface เก็บสต็อกไว้ ใส่ Redstone Card ไว้ และตั้งโหมดเรดสโตนเป็น
        "Active with signal".
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        (4) Storage Bus #1: ตั้งลำดับความสำคัญให้สูงกว่า Storage Bus อีกตัว สำคัญมาก
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        (5) Molecular Assembler: ใส่แพทเทิร์นสำหรับทำสำเนา smithing template ไว้ข้างใน

        ![Pattern](../assets/diagrams/smithing_template_pattern_small.png)

        ต้องใส่ smithing template ลงไปด้วยมือ 1 ชิ้นตั้งแต่ตอนสร้างครั้งแรก
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        (6) Import Bus #2: ใช้ค่าตั้งต้นตามปกติ
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        (7) Storage Bus #2: กรองเฉพาะ "netherite smithing template" ตั้งลำดับความสำคัญให้ต่ำกว่า Storage Bus อีกตัว
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        ไปยังเครือข่ายหลัก
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## การตั้งค่า

* <ItemLink id="interface" /> (1) ตั้งให้เก็บสต็อกวัตถุดิบเพิ่มเติมที่ต้องใช้ ได้แก่ diamond และ netherrack
* <ItemLink id="level_emitter" /> (2) กำหนดค่าเป็น "netherite smithing template" และตั้งเป็น "Emit Redstone to craft item"
* <ItemLink id="import_bus" /> ตัวแรก (3) กรองเฉพาะไอเทมที่ Interface เก็บสต็อกไว้ ใส่ Redstone Card ไว้ และตั้งโหมดเรดสโตนเป็น "Active with signal"
* <ItemLink id="storage_bus" /> ตัวแรก (4) ตั้ง [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority) ให้ *สูงกว่า* Storage Bus ตัวที่สอง
* <ItemLink id="molecular_assembler" /> (5) ใส่แพทเทิร์นสำหรับทำสำเนา smithing template ไว้ และใส่ smithing template ลงไปด้วยมือ 1 ชิ้น

  ![Pattern](../assets/diagrams/smithing_template_pattern.png)

* <ItemLink id="import_bus" /> ตัวที่สอง (6) ใช้ค่าตั้งต้นตามปกติ
* <ItemLink id="storage_bus" /> ตัวที่สอง (7) กรองเฉพาะ "netherite smithing template" และมี [ลำดับความสำคัญ](../ae2-mechanics/import-export-storage.md#storage-priority) *ต่ำกว่า* Storage Bus ตัวแรก

## หลักการทำงาน

1. <ItemLink id="level_emitter" /> ทำตัวเสมือน [pattern](../items-blocks-machines/patterns.md) เพราะใส่
   <ItemLink id="crafting_card" /> ไว้และตั้งเป็น "Emit Redstone to craft item" ดังนั้น "netherite smithing template" จึงปรากฏใน
   [terminal](../items-blocks-machines/terminals.md) เป็นของที่ [autocraft](../ae2-mechanics/autocrafting.md) ได้
2. เมื่อได้รับคำขอคราฟต์ไอเทมนั้น ไม่ว่าจากผู้เล่นหรือจากระบบเอง Level Emitter จะเปิด
3. Level Emitter เปิดใช้งาน <ItemLink id="import_bus" /> ตัวแรก ซึ่งดึงวัตถุดิบที่เก็บสต็อกไว้ใน <ItemLink id="interface" /> ออกมา
4. <ItemLink id="storage_bus" /> เพียงตัวเดียวในเครือข่ายที่เก็บวัตถุดิบเหล่านั้นได้คือตัวที่ติดกับ assembler
5. <ItemLink id="molecular_assembler" /> รับวัตถุดิบ (ที่มี smithing pattern อยู่ข้างในแล้ว 1 ชิ้น) แล้วคราฟต์ ได้ smithing pattern 2 ชิ้น
6. <ItemLink id="import_bus" /> ตัวที่สองดึง smithing pattern ออกมา 1 ชิ้น
7. Storage Bus ตัวแรกมีลำดับความสำคัญสูงกว่า smithing pattern ชิ้นนั้นจึงกลับเข้า assembler
8. <ItemLink id="import_bus" /> ตัวที่สองดึง smithing pattern ออกมาอีก 1 ชิ้น
9. Assembler รับ smithing pattern เพิ่มไม่ได้ smithing pattern ชิ้นที่สองจึงไปที่ Storage Bus ที่มีลำดับความสำคัญต่ำกว่า แล้วใส่เข้า Interface
10. <ItemLink id="interface" /> ไม่ได้ตั้งให้เก็บสต็อก smithing pattern จึงส่งเข้าเครือข่าย