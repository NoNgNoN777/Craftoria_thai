---
navigation:
  title: สารบัญ
  position: 0
---

![Logo](assets/logo.png)

# Applied Energistics 2 คืออะไร

# วิธีใช้คู่มือนี้

* เปิดแถบด้านซ้ายเพื่อดูสารบัญ
* หลายหน้ามีฉากโต้ตอบได้ ถ้าฉากมีปุ่ม ![Plus](assets/diagrams/plus.png)
และ ![Minus](assets/diagrams/minus.png) (ซูม) ข้างฉาก คุณหมุนและเลื่อนกล้องได้
คลิกซ้ายแล้วลากเพื่อหมุน คลิกขวาแล้วลากเพื่อเลื่อน

# Applied Energistics 2 คืออะไร

Applied Energistics 2 เพิ่มชิ้นส่วนและกลไกสำหรับระบบโลจิสติกส์และการเก็บของ คุณแทนห้องใหญ่ที่เต็มด้วยหีบได้ด้วย ME Network ขนาดกะทัดรัด แต่นั่นเป็นเพียงจุดเริ่มต้น Applied Energistics ออกแบบมาให้ทำงานร่วมกับม็อดอื่นในม็อดแพ็ก และทำให้ม็อดเหล่านั้นเป็นอัตโนมัติได้ คุณตั้งระบบให้คราฟต์ทุกอย่างที่ต้องใช้ (และผลลัพธ์สุดท้าย) ของสายการคราฟต์ซับซ้อนได้ด้วยการคลิกครั้งเดียว หรือเก็บไอเทมบางชนิดไว้ในปริมาณที่กำหนด คราฟต์เพิ่มเมื่อจำเป็น หรือเพียงย้ายไอเทมไปรอบฐาน

* [เริ่มต้นใช้งาน](getting-started.md)
* [เคล็ดลับ](tips-and-tricks.md)
* [กลไกของ AE2](ae2-mechanics/ae2-mechanics-index.md)
* [ตัวอย่างการตั้งระบบ](example-setups/example-setups-index.md)
* [ไอเทม บล็อก และเครื่องจักร](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>