---
navigation:
  title: "Add-on: AE2 Import Export Card"
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
- ae2importexportcard:block_picker_card
---

# AE2 Import Export Card

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />

  <ItemImage id="ae2importexportcard:import_card" scale="2" />

  <ItemImage id="ae2importexportcard:block_picker_card" scale="2" />
</Row>

การ์ด Import, Export และ Block Picker ช่วยให้คุณนำเข้า/ส่งออกไอเทมจากช่องเก็บของได้

## Import Card

<ItemImage id="ae2importexportcard:import_card" scale="2" />

Import Card ดึงไอเทมในช่องที่กำหนดของช่องเก็บของคุณ แล้วส่งเข้าระบบ ME

![Import Card](diagrams/import_card.png)

คลิกช่องเพื่อทำเครื่องหมายถูก ไอเทมในช่องที่มีเครื่องหมายถูกจะถูกนำเข้าระบบ ME ลากไอเทมจากช่องเก็บของไปด้านบนเพื่อเปลี่ยนตัวกรอง

### อัปเกรด

Import Card รองรับ[อัปเกรด](items-blocks-machines/upgrade_cards.md)ต่อไปนี้:

*   <ItemLink id="fuzzy_card" /> กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="inverter_card" /> สลับตัวกรองจาก whitelist เป็น blacklist

### สูตรคราฟต์

<RecipeFor id="ae2importexportcard:import_card" />

## Export Card

<ItemImage id="ae2importexportcard:export_card" scale="2" />

Export Card ทำงานเหมือนกันทุกประการ แต่ดึงไอเทมจากระบบ ME เข้าช่องเก็บของของคุณ

![Export Card](diagrams/export_card.png)

หากต้องการกำหนดไอเทม ให้ลากไอเทมจากช่องเก็บของไปยังช่องใดช่องหนึ่งด้านบน แล้วคลิกช่องในช่องเก็บของเพื่อเปลี่ยนเป็นจำนวนที่ต้องการ คลิกขวาเพื่อล้างกลับเป็น X

### อัปเกรด

Export Card รองรับ[อัปเกรด](items-blocks-machines/upgrade_cards.md)ต่อไปนี้:

*   <ItemLink id="fuzzy_card" /> กรองตามระดับความเสียหาย และ/หรือไม่สนใจ NBT ของไอเทม
*   <ItemLink id="speed_card" /> เพิ่มความเร็วการโอนจาก 1 ชิ้นไปจนถึงทั้งสแตก
*   <ItemLink id="crafting_card" /> สั่งและคราฟต์ไอเทมที่ยังไม่มีให้โดยอัตโนมัติ

### สูตรคราฟต์

<RecipeFor id="ae2importexportcard:export_card" />

## Block Picker Card

<ItemImage id="ae2importexportcard:block_picker_card" scale="2" />

Block Picker Card ให้คุณดึงบล็อกที่กำลังมองอยู่ออกจากเครือข่ายได้ทันที เพียงเล็งไปที่บล็อกแล้วกดปุ่ม "Pick Block" ถ้าเครือข่ายมีบล็อกนั้นอยู่ ระบบจะดึงเข้าช่องเก็บของของคุณ

![Block Picker Card](diagrams/block_picker_card.png)

### สูตรคราฟต์

<RecipeFor id="ae2importexportcard:block_picker_card" />