---
navigation:
  parent: appflux/appflux-index.md
  title: Insulating Resin
  icon: appflux:insulating_resin
categories:
- flux materials
item_ids:
- appflux:insulating_resin
- appflux:harden_insulating_resin
---

# Insulating Resin

<Row>
<ItemImage id="appflux:insulating_resin" scale="4"></ItemImage>
<ItemImage id="appflux:harden_insulating_resin" scale="4"></ItemImage>
</Row>

Insulating Resin ป้องกันพลังงานที่เก็บไว้รั่วไหล เป็นวัสดุจำเป็นสำหรับทำตัวเรือน FE cell
