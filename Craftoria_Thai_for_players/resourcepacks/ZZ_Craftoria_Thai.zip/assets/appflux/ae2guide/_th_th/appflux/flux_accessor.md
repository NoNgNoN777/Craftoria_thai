---
navigation:
  parent: appflux/appflux-index.md
  title: Flux Accessor
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# Flux Accessor

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

Flux Accessor รับเข้า/ส่งออกพลังงานที่เก็บไว้ในเครือข่าย ME ของคุณได้ ค่าเริ่มต้นไม่จำกัดอัตรารับส่ง ปรับได้ในค่าตั้งของ Appflux

มีโหมดเร็วและโหมดปกติ ในโหมดเร็วจะส่งออกพลังงานทุก tick ซึ่งอาจทำให้เกิดแลคหากใช้หนัก ส่วนโหมดปกติจะส่งออกตามพลังงานที่เก็บอยู่ของปลายทาง จึงไม่ทำให้แลค

* ข้อควรทราบ: "พลังงาน" ในที่นี้คือ FE ที่เก็บใน [FE Storage Cell](./flux_cells.md) ของคุณ
ไม่ใช่พลังงานใน [Energy Cell](ae2:items-blocks-machines/energy_cells.md)

