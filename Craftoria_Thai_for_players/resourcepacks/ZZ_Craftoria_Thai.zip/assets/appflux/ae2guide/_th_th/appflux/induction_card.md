---
navigation:
  parent: appflux/appflux-index.md
  title: Induction Card
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# Induction Card

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

Induction Card เปลี่ยน <ItemLink id="ae2:pattern_provider" /> หรือ <ItemLink id="ae2:interface" /> ให้เป็น
<ItemLink id="appflux:flux_accessor" /> ทำให้รับและส่งพลังงานเข้าออกได้
