---
navigation:
  parent: appflux/appflux-index.md
  title: การใช้งานกับ Terminal
categories:
- flux tricks
---

# การใช้งานกับ Terminal

Terminal จะแสดงพลังงานที่เก็บไว้เป็น *ของเหลวสีเขียว* เหล่านี้

![FE_GUI](../pic/fe_terminal.png)

นี่ไม่ใช่ของเหลวจริง และคุณใช้ถังเติมไม่ได้

คุณใช้ภาชนะบรรจุพลังงาน เช่น แบตเตอรี่หรือเครื่องมือไฟฟ้า เติมพลังงานเข้าหรือดึงออกจากมันได้

![FE_GUI2](../pic/fe_terminal2.png)

