---
navigation:
    title: Applied Flux
    position: 70
---

# เก็บพลังงานไว้ใน Cell!

Appflux ช่วยให้คุณจัดการระบบพลังงานด้วย AE

## Flux Cells
<CategoryIndex category="flux cells"></CategoryIndex>

## วัสดุ
<CategoryIndex category="flux materials"></CategoryIndex>

## Flux Accessor
<CategoryIndex category="flux accessor"></CategoryIndex>

## เทคนิค
<CategoryIndex category="flux tricks"></CategoryIndex>
