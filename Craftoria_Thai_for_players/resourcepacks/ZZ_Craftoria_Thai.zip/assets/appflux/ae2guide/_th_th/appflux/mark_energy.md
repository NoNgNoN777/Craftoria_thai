---
navigation:
  parent: appflux/appflux-index.md
  title: ทำเครื่องหมาย FE
categories:
- flux tricks
---

# วิธีทำเครื่องหมาย FE ในช่อง config

หากต้องการส่งพลังงานออกด้วย <ItemLink id="ae2:export_bus"/> คุณต้องทำเครื่องหมาย FE ในช่อง config ของมัน

คลิกขวาที่ช่องด้วยภาชนะบรรจุพลังงานเพื่อทำเครื่องหมาย FE

![FE_MARK](../pic/fe_mark.png)
