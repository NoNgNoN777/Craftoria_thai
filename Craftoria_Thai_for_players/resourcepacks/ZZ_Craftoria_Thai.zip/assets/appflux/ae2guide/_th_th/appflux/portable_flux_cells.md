---
navigation:
  parent: appflux/appflux-index.md
  title: Portable Flux Cells
  icon: appflux:fe_1k_portable_cell
categories:
- flux cells
item_ids:
- appflux:fe_1k_portable_cell
- appflux:fe_4k_portable_cell
- appflux:fe_16k_portable_cell
- appflux:fe_64k_portable_cell
- appflux:fe_256k_portable_cell
- appflux:fe_1m_portable_cell
- appflux:fe_4m_portable_cell
- appflux:fe_16m_portable_cell
- appflux:fe_64m_portable_cell
- appflux:fe_256m_portable_cell
---

# Portable Flux Cells

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_portable_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_portable_cell" scale="4" />
  </Row>
</Column>

Portable FE cell มีขนาดเพียงหนึ่งในสี่ของ [FE cells](./flux_cells.md) ปกติ

อย่างไรก็ตาม คุณติดตั้ง <ItemLink id="appflux:induction_card"/> ใน Portable FE cell ได้ แล้วมันจะชาร์จไอเทมในช่องเก็บของของคุณให้อัตโนมัติ
