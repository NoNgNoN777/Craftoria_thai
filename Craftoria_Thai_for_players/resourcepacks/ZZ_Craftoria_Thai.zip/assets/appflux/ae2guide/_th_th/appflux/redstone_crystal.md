---
navigation:
  parent: appflux/appflux-index.md
  title: Redstone Crystal
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# Redstone Crystal

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*"Pow ah!!"*

Redstone เป็นตัวกลางเก็บพลังงานที่ดี แต่หลวมเกินกว่าจะใส่ใน cell ได้

เมื่อรวม Fluix Crystal และ Glowstone เข้ากับ Redstone Block จะตกผลึกเป็น Redstone Crystal เก็บพลังงานได้มหาศาล ในขณะที่กินพื้นที่น้อยมาก
