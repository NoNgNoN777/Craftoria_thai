---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Magnet Card
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# Magnet Card

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

<ItemLink id="ae2wtlib:magnet_card" /> คือ[การ์ดอัปเกรด](ae2:items-blocks-machines/upgrade_cards.md)สำหรับ <ItemLink id="ae2:wireless_crafting_terminal" />
ช่วยเพิ่มแม่เหล็กให้ <ItemLink id="ae2:wireless_crafting_terminal" /> เปิดปิดหรือกรองได้ใน GUI
และมีปุ่มลัดสำหรับเปิดหรือปิดด้วย

<ItemLink id="ae2wtlib:magnet_card" /> ทำ 2 อย่าง:

1. เก็บไอเทมในระยะที่กว้างขึ้น (ตั้งค่าได้ ค่าเริ่มต้นคือ 16)
2. ส่งไอเทมที่เก็บได้เข้าระบบ ME แทนช่องเก็บของของคุณ

เปิดปิดแยกกันได้ และกรองแยกกันได้ (ตัวกรองการเก็บและตัวกรองการส่งเข้า)
ตัวกรองทั้งสองตั้งเป็นโหมด blacklist หรือ whitelist ได้

## สูตรคราฟต์

<RecipeFor id="ae2wtlib:magnet_card" />
