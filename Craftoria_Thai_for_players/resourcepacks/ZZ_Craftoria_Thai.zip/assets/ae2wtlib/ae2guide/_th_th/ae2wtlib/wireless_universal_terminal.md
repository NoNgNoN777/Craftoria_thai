---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Wireless Universal Terminal
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_universal_terminal
---

# Wireless Universal Terminal

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> คือการรวม[Wireless Terminal](wireless_terminals.md)หลายตัวไว้ในไอเทมเดียว

[Wireless Terminal ของ AE2WTLib](wireless_terminals.md)ทุกตัวรวมเป็นเทอร์มินัลเดียวได้

<ItemLink id="ae2:wireless_terminal" /> ของ AE2 รวมเข้ากับ <ItemLink id="ae2wtlib:wireless_universal_terminal" /> **ไม่ได้**


## UI

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> เพิ่มปุ่มบน UI ของเทอร์มินัล
คลิกซ้าย (และคลิกขวา) เพื่อสลับไป[Wireless Terminal](wireless_terminals.md)ตัวถัดไป (หรือตัวก่อนหน้า)


## อัปเกรด

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> รับอัปเกรดแบบเดียวกับ[Wireless Terminal](wireless_terminals.md)ที่ติดตั้งอยู่
เทอร์มินัลที่ติดตั้งแต่ละตัวเพิ่มช่องอัปเกรด 2 ช่อง

## ที่เก็บพลังงาน

การเพิ่มเทอร์มินัลจะรวมที่เก็บพลังงานเข้าด้วยกัน
ดังนั้น <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ที่มีเทอร์มินัลสองตัวจะมีที่เก็บพลังงานเป็นสองเท่าของ[Wireless Terminal](wireless_terminals.md)
