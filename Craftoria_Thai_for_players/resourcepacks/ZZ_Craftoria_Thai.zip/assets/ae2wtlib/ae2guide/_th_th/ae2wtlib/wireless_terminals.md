---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: AE2WTLib Wireless Terminals
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_pattern_encoding_terminal
  - ae2wtlib:wireless_pattern_access_terminal
---

# Wireless Terminals

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

นอกจาก <ItemLink id="ae2:energy_card" /> แล้ว Wireless Terminal ทุกตัวของ AE2WTLib ยังอัปเกรดด้วย <ItemLink id="ae2wtlib:quantum_bridge_card" /> ได้
และรวมเป็น <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ได้

เหมือน <ItemLink id="ae2:wireless_terminal" /> ของ AE2 คือเปิดด้วยปุ่มลัดได้ และใส่ในช่อง curio ได้
(หากติดตั้งม็อดที่รองรับ curio api)

Wireless Terminal เชื่อมต่อได้เหมือน <ItemLink id="ae2:wireless_terminal" /> ปกติ โดยใช้ <ItemLink id="ae2:wireless_access_point" />

## Wireless Universal Terminal

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> คือการรวม Wireless Terminal หลายตัวไว้ในไอเทมเดียว

## Wireless Crafting Terminal

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> คือ Crafting Terminal รุ่นไร้สาย
มี[ฟังก์ชันเพิ่มเติม](wireless_crafting_terminal.md)เมื่อเทียบกับ AE2 ต้นฉบับ

## Wireless Pattern Encoding Terminal

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

<ItemLink id="ae2:pattern_encoding_terminal" /> รุ่นไร้สาย

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## Wireless Pattern Access Terminal

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

<ItemLink id="ae2:pattern_access_terminal" /> รุ่นไร้สาย

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## Addon Terminals

Wireless Terminal ส่วนใหญ่จาก Addon อื่นก็ใช้กับ <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ได้

## เทอร์มินัลที่ใช้ใน Universal Terminal ไม่ได้

<ItemLink id="ae2:wireless_terminal" /> ใช้ใน <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ไม่ได้
เพราะไม่ให้ประโยชน์เหนือกว่า <ItemLink id="ae2:wireless_crafting_terminal" />
และใช้ <ItemLink id="ae2wtlib:quantum_bridge_card" /> ไม่ได้ด้วย
