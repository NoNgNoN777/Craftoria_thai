---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Quantum Bridge Card
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# Quantum Bridge Card

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

Quantum Bridge Card คือ[การ์ดอัปเกรด](ae2:items-blocks-machines/upgrade_cards.md)สำหรับ[Wireless Terminal ของ AE2wtlib](wireless_terminals.md)
ช่วยเชื่อม[Wireless Terminal](wireless_terminals.md)ของคุณเข้ากับ[Quantum Bridge](ae2:items-blocks-machines/quantum_bridge.md)

ใส่ Quantum Bridge Card และ <ItemLink id="ae2:quantum_entangled_singularity" /> ไว้ใน Wireless Terminal
แล้วใส่ Singularity อีกอันไว้ใน[Quantum Bridge](ae2:items-blocks-machines/quantum_bridge.md)ที่ต่อกับเครือข่ายของคุณ

Wireless Terminal ของคุณจะเชื่อมแบบ Quantum เข้าถึงเครือข่ายได้จากทุกที่ แม้ข้ามมิติ (โดยชังก์ที่มีเครือข่ายต้องโหลดอยู่ เช่นใช้ <ItemLink id="ae2:spatial_anchor" />)
และชาร์จพลังงานจากเครือข่ายอัตโนมัติ
(ตรวจให้แน่ใจว่าเครือข่ายมี[ที่เก็บพลังงาน](ae2:items-blocks-machines/energy_cells.md)พอ)

## สูตรคราฟต์

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
