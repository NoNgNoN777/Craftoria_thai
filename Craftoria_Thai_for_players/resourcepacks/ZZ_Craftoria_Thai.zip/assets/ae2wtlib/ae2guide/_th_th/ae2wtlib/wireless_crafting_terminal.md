---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Wireless Crafting Terminal
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
  - ae2:wireless_crafting_terminal
---

# Wireless Crafting Terminal

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> คือรุ่น[ไร้สาย](wireless_terminals.md)ของ <ItemLink id="ae2:crafting_terminal" />
AE2WTLib เพิ่มการ[เติมของ](restock.md)อัตโนมัติจากเครือข่าย ME และให้ Pick Block ดึงไอเทมจากเครือข่าย ME ได้   
เมื่อใส่ <ItemLink id="ae2wtlib:magnet_card" /> จะทำหน้าที่เป็นแม่เหล็กด้วย

รวมกับ[Wireless Terminal](wireless_terminals.md)อื่น ๆ เป็น <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ได้

AE2WTLib เสริมฟังก์ชัน `Pick Block` ของ Minecraft โดยจะดึงไอเทมจากเครือข่ายถ้าหาไม่เจอในช่องเก็บของ
(และจะลองเก็บไอเทมเข้าเครือข่ายถ้าช่องปัจจุบันเต็ม)

## UI

ดู[เทอร์มินัล](ae2:items-blocks-machines/terminals.md)

## อัปเกรด

<ItemLink id="ae2:wireless_crafting_terminal" /> รองรับ[อัปเกรด](ae2:items-blocks-machines/upgrade_cards.md)ต่อไปนี้:

*   <ItemLink id="ae2:energy_card" /> เพิ่มความจุแบตเตอรี่
*   <ItemLink id="ae2wtlib:quantum_bridge_card" /> ทำให้เทอร์มินัลมีระยะไม่จำกัด แม้ข้ามมิติ และชาร์จเทอร์มินัลจากเครือข่าย ME อัตโนมัติ 
*   <ItemLink id="ae2wtlib:magnet_card" /> เพิ่มฟังก์ชันแม่เหล็ก

## สูตรคราฟต์

<RecipeFor id="ae2:wireless_crafting_terminal" />
