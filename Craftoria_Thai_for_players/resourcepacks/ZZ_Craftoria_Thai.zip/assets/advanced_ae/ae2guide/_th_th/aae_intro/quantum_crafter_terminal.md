---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Crafter Terminals
  icon: advanced_ae:quantum_crafter_terminal
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_crafter_terminal
  - advanced_ae:wireless_quantum_crafter_terminal
---

# Quantum Crafter Terminals

<Row gap="20">
<ItemImage id="advanced_ae:quantum_crafter_terminal" scale="4"></ItemImage>
<ItemImage id="advanced_ae:wireless_quantum_crafter_terminal" scale="4"></ItemImage>
</Row>

Quantum Crafter Terminal ช่วยให้ผู้เล่นจัดการ <ItemLink id="advanced_ae:quantum_crafter"/> ทั้งเครือข่ายได้จากจุดเดียว เวอร์ชันไร้สายสะดวกเวลาต้องปรับค่าระหว่างเดินทาง เพียงเชื่อมกับ Grid โดยใส่เข้าไปใน wireless access point ก็พร้อมใช้งาน

<Row gap="20">
<RecipeFor id="advanced_ae:quantum_crafter_terminal" />
<RecipeFor id="advanced_ae:wireless_quantum_crafter_terminal" />
</Row>