---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Advanced Pattern Encoder
  icon: advanced_ae:adv_pattern_encoder
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_encoder
  - advanced_ae:adv_processing_pattern
---

# Advanced Pattern Encoder

เพื่อสอน ME Advanced Pattern Provider ว่าต้องส่งไอเทมของคุณไปที่ใด ต้องใช้อุปกรณ์พิเศษเข้ารหัสข้อมูลนั้น คุณคลิกขวาขณะถืออุปกรณ์เพื่อเปิด GUI ของมัน

<ItemImage id="advanced_ae:adv_pattern_encoder" scale="4"></ItemImage>

ใส่ Processing Pattern ที่เข้ารหัสแล้วลงในช่องซ้าย ระบบจะถอดรหัสและแสดงวัตถุดิบดิบทั้งหมดเป็นรายการ

![PEGui1](../pic/ape_pattern.png)

แต่ละแถวมีชุดปุ่มที่แทนด้านของบล็อกทั้งหมด ที่ส่งวัตถุดิบเข้าไปได้ ถ้าเลือกปุ่ม "A" ไว้ จะส่งเข้าด้านใดก็ตามที่ต่อกับ Pattern Provider โดยตรง ส่วนการเลือกด้านเฉพาะจะบังคับให้ใส่ไอเทมที่ด้านนั้น โปรดทราบว่า advanced pattern ถอดรหัสได้ถูกต้องเฉพาะใน <ItemLink id="advanced_ae:adv_pattern_provider" /> เท่านั้น และจะทำงานเหมือน pattern ปกติ ถ้าใช้กับ pattern provider ชนิดอื่น นอกจากนี้ ถ้าไอเทมแม้ชิ้นเดียวใส่เข้าด้านที่กำหนดไม่ได้ ระบบจะไม่ใส่ไอเทมแบบกำหนดด้านเลย และจะใช้พฤติกรรมของ pattern provider มาตรฐานแทน