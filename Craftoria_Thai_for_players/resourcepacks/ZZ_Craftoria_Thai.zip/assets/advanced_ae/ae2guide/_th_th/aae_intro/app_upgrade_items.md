---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ไอเทมอัปเกรด Advanced Pattern Provider
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_provider_upgrade
  - advanced_ae:adv_pattern_provider_capacity_upgrade
---

# อัปเกรด Advanced Pattern Provider

ไอเทมของ AdvancedAE ที่ให้คุณอัปเกรด pattern provider โดยไม่ต้องย้าย pattern และอัปเกรดทั้งหมด

## Advanced Pattern Provider Upgrade

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

อัปเกรดเหล่านี้ใช้กับ AE Pattern Provider ปกติและ Extended Pattern Provider ของ ExtendedAE ได้ เมื่อใช้กับเครื่องเหล่านี้ จะอัปเกรดเป็นรุ่น advanced โดยคงจำนวนช่องเท่าเดิม ทำให้คุณไม่เสียวัสดุที่ใช้อัปเกรด provider ปกติเป็น extended provider ไปในกระบวนการนี้

## Advanced Pattern Provider Capacity Upgrade

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

Capacity upgrade ใช้อัปเกรด Pattern Provider ปกติเป็น Advanced Pattern Provider แบบ 36 ช่อง pattern ได้โดยตรง
