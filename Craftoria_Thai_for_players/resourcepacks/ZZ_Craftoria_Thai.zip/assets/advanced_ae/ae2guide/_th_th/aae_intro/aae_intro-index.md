---
navigation:
  title: Advanced AE Introduction
  position: 70
---

# Advanced AE!

Advanced AE มุ่งปรับปรุงประสบการณ์การใช้งาน ME System และขยายความเป็นไปได้ของระบบช่วงท้ายเกม ม็อดนี้ให้คุณอัปเกรด pattern provider ให้ส่งไอเทมเข้าด้านที่กำหนดของเครื่องปลายทางได้ และสร้างคอมพิวเตอร์ multiblock ที่รันงานคราฟต์ได้ไม่จำกัดจำนวน โดยแชร์ co-processor ร่วมกันตราบที่ยังมี crafting storage เหลือ พร้อมฟีเจอร์อำนวยความสะดวกอีกมากมาย

![PEGui1](../pic/aae_intro.png)

ดูรายการบล็อกและไอเทมทั้งหมดได้จากหน้าคู่มือเหล่านี้

## Advanced Devices

<CategoryIndex category="advanced devices"></CategoryIndex>

## Advanced Items

<CategoryIndex category="advanced items"></CategoryIndex>

พบปัญหา หรืออยากได้ฟีเจอร์ที่ยังไม่มี
แจ้งได้ที่นี่
[Advanced AE GitHub](https://github.com/pedroksl/AdvancedAE)