---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Throughput Monitor
  icon: advanced_ae:throughput_monitor
categories:
  - advanced items
item_ids:
  - advanced_ae:throughput_monitor
  - advanced_ae:throughput_monitor_configurator
---

# ME Throughput Monitor

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Throughput Monitor เป็น Monitor ชนิดย่อย มีฟังก์ชันเหมือน <ItemLink id="ae2:storage_monitor" /> และเพิ่มมิเตอร์วัดอัตราผ่าน โดยจะติดตามไอเทม/ของเหลวชนิดเดียวและเฝ้าดูการเปลี่ยนแปลงของปริมาณ แล้วแสดงจำนวนต่อวินาทีให้ผู้เล่นเห็น

ไม่ต้องใช้ channel

## การควบคุม

*   คลิกขวาด้วยไอเทม หรือคลิกขวาสองครั้งด้วยภาชนะใส่ของเหลว เพื่อตั้ง Monitor ให้แสดงไอเทม/ของเหลวนั้น
*   คลิกขวาด้วยมือเปล่าเพื่อล้าง Monitor
*   ย่อตัวแล้วคลิกขวาด้วยมือเปล่าเพื่อล็อก Monitor

## Throughput Monitor Configurator

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

Throughput monitor configurator เป็นเครื่องมือที่ใช้เปลี่ยนข้อมูลที่แสดง คลิกขวา Monitor ขณะถือไว้ในมือ จะวนสลับระหว่างสามตัวเลือก

* ไอเทมต่อ tick
* ไอเทมต่อวินาที
* ไอเทมต่อนาที

หมายเหตุ: เมื่อเปลี่ยนโหมด ค่าที่อ่านอาจใช้เวลาสักพักจึงนิ่ง อย่าเชื่อค่าแรก ๆ