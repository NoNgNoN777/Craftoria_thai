---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Computer
  icon: advanced_ae:quantum_core
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_unit
  - advanced_ae:quantum_core
  - advanced_ae:quantum_structure
  - advanced_ae:quantum_accelerator
  - advanced_ae:quantum_multi_threader
  - advanced_ae:quantum_storage_128
  - advanced_ae:quantum_storage_256
  - advanced_ae:data_entangler
---

# Quantum Computer

Quantum computer เป็น crafting computer ชนิดพิเศษ ที่รันคำขอคราฟต์ได้ไม่จำกัดจำนวน ตราบที่มี crafting storage เพียงพอ

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## Quantum Core

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

Quantum Core เป็นหัวใจของ Quantum Computer มี crafting storage 256M และ co-processor thread 8 ตัวในตัวเอง เป็นบล็อกเดียวที่สร้าง quantum computer ที่เสร็จสมบูรณ์ได้ด้วยตัวเอง และให้ประโยชน์ทั้งหมดของ quantum computer อย่างไรก็ตาม ถ้านำไปสร้างเป็น multiblock จะได้คอมพิวเตอร์ที่ทรงพลังกว่ามาก เมื่อใช้เป็นคอมพิวเตอร์เดี่ยว ต้องจ่ายพลังงานผ่านด้านบนหรือด้านล่าง ซึ่งเป็นตำแหน่งของตัวเชื่อมต่อ

## Quantum Storages

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

บล็อกเหล่านี้ขยาย crafting storage ของ quantum core ช่วยเพิ่มจำนวนงานที่ quantum computer รันพร้อมกันได้อย่างมีประสิทธิภาพ มี 2 รุ่น ความจุ 128M และ 256M

## Quantum Data Entangler

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

Data Entangler เป็นบล็อกพิเศษที่มีผลกับบล็อกเก็บข้อมูลทุกตัวใน multiblock ทำให้บล็อกเก็บข้อมูลเก็บข้อมูลในหลายมิติ ส่งผลให้ความจุเพิ่มขึ้น 4 เท่า วางได้เพียงตัวเดียวในแต่ละ quantum computer multiblock

## Quantum Accelerator

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

Quantum Accelerator เพิ่ม co-processor 8 ตัวให้ Quantum Computer multiblock โปรดทราบว่า pattern คราฟต์ทั้งหมดที่ quantum computer รันอยู่ แชร์ co-processor ทั้งหมดร่วมกันได้ จึงควรลงทุนสร้างจำนวนมาก

## Quantum Multi-threader

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

คล้ายกับ Data Entangler multi-threader ทำให้ accelerator รัน thread เพิ่มในมิติแยกกัน คูณกำลัง co-processing ของ accelerator ขึ้น 4 เท่า วางได้เพียงตัวเดียวในแต่ละ quantum computer multiblock

## Quantum Structure

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

บล็อกเหล่านี้เป็นโครงของ quantum computer ใช้เป็นบล็อกก่อสร้างของ quantum computer และเชื่อมทุกอย่างเข้าด้วยกัน

## The multiblock

การสร้าง quantum computer แบบ multiblock ต้องทำตามกฎเหล่านี้
- ขนาดสูงสุดคือ 7x7x7 (ขนาดภายนอก);
- ห้ามมีช่องว่างอยู่ภายใน multiblock ใช้ <ItemLink id="advanced_ae:quantum_unit" />
เติมได้โดยไม่มีประโยชน์เพิ่มเติม;
- ต้องมี <ItemLink id="advanced_ae:quantum_core" /> เพียงตัวเดียวพอดี;
- มี <ItemLink id="advanced_ae:data_entangler" /> ได้ไม่เกินหนึ่งตัว;
- มี <ItemLink id="advanced_ae:quantum_multi_threader" /> ได้ไม่เกินหนึ่งตัว;
- บล็อกทั้งหมดในชั้นนอกสุดต้องเป็น <ItemLink id="advanced_ae:quantum_structure" />;
- ห้ามมีบล็อกภายในที่เป็น <ItemLink id="advanced_ae:quantum_structure" />

## Server Configs

ปรับค่าหลายอย่างได้ผ่าน server config เช่น
- ขนาด multiblock สูงสุด;
- จำนวน co-processor ใน Quantum Accelerator แต่ละตัว;
- จำนวน Quantum Multi-Threader สูงสุด;
- ค่าตัวคูณ thread ของ Multi-Threader;
- จำนวน Data Entangler สูงสุด;
- ค่าตัวคูณความจุของ Data Entangler;

ตรวจสอบขีดจำกัดของอินสแตนซ์ของคุณได้จาก tooltip ของไอเทม