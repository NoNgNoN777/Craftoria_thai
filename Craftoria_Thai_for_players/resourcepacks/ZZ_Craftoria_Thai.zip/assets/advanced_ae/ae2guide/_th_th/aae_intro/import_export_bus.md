---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Import Export Bus
  icon: advanced_ae:import_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:import_export_bus_part
---

# Import Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

Import Export Bus เป็นการผสม <ItemLink id="ae2:import_bus" /> กับ <ItemLink id="ae2:export_bus" /> เข้าด้วยกัน ตั้งฟิลเตอร์เพื่อกำหนดสแตกที่จะส่งออกได้ ส่วนสแตกที่ไม่อยู่ในฟิลเตอร์ถือเป็นสแตกที่นำเข้าได้