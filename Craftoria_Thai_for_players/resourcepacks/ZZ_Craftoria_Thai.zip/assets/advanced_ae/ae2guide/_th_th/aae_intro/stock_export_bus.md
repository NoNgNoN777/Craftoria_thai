---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Stock Export Bus
  icon: advanced_ae:stock_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:stock_export_bus_part
---

# Stock Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

Stock Export Bus ตั้งให้ส่งออกไอเทมที่กรองไว้ตามจำนวนที่กำหนดได้พอดี โดยจะติดตามจำนวนที่มีอยู่ในช่องเก็บของปลายทางและไม่ใส่เกินจำนวนนั้น ในการตั้งค่า ให้เปิด GUI ลากไอเทมที่ต้องการใส่ช่องกรอง แล้วคลิกกลางเพื่อกำหนดจำนวน โปรดทราบว่าไม่ได้ควบคุมเอาต์พุต หมายความว่าจะไม่ดึงไอเทม/ของเหลวส่วนเกินออกจากช่องเก็บของ หากมีเกินจำนวนที่ตั้งไว้