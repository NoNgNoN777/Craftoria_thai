---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Advanced Pattern Provider
  icon: advanced_ae:adv_pattern_provider
categories:
  - advanced devices
item_ids:
  - advanced_ae:adv_pattern_provider
  - advanced_ae:small_adv_pattern_provider
  - advanced_ae:adv_pattern_provider_part
  - advanced_ae:small_adv_pattern_provider_part
---

# ME Advanced Pattern Provider

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

ME Advanced Pattern Provider เป็น <ItemLink id="ae2:pattern_provider" /> ชนิดใหม่ ที่อัปเกรดจากรุ่นมาตรฐานหรือ <ItemLink id="extendedae:ex_pattern_provider" /> ให้กำหนดด้านที่จะส่งไอเทมแต่ละชิ้นใน pattern เข้าไปได้ ส่วนเสริมอันทรงพลังนี้ ทำให้เครื่องจักรที่ต้องการด้านเฉพาะสำหรับวัตถุดิบเฉพาะ ทำงานอัตโนมัติได้ ด้วยบล็อกเดียว ไม่ต้องใช้ท่อ

*มองไปที่ Mekanism นะ*

หากต้องการใช้ฟีเจอร์นี้ คุณต้องใส่ <ItemLink id="advanced_ae:adv_processing_pattern" /> ซึ่งได้จากการใส่ pattern ที่เข้ารหัสแล้วลงใน <ItemLink id="advanced_ae:adv_pattern_encoder" /> แล้วนำรุ่น advanced ออกมา

ยังมีรุ่นขยาย ที่เก็บ pattern ได้ถึง 36 ช่องใน pattern provider ตัวเดียว

![AAEGui](../pic/app_gui.png)
