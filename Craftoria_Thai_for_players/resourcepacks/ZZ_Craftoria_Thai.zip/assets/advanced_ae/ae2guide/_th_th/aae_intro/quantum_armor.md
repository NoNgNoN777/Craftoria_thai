---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Quantum Armor Set
  icon: advanced_ae:quantum_helmet
categories:
  - advanced items
item_ids:
  - advanced_ae:quantum_helmet
  - advanced_ae:quantum_chestplate
  - advanced_ae:quantum_leggings
  - advanced_ae:quantum_boots
  - advanced_ae:quantum_upgrade_base
  - advanced_ae:walk_speed_card
  - advanced_ae:sprint_speed_card
  - advanced_ae:step_assist_card
  - advanced_ae:jump_height_card
  - advanced_ae:lava_immunity_card
  - advanced_ae:flight_card
  - advanced_ae:water_breathing_card
  - advanced_ae:auto_feeding_card
  - advanced_ae:auto_stock_card
  - advanced_ae:magnet_card
  - advanced_ae:hp_buffer_card
  - advanced_ae:evasion_card
  - advanced_ae:regeneration_card
  - advanced_ae:strength_card
  - advanced_ae:attack_speed_card
  - advanced_ae:luck_card
  - advanced_ae:reach_card
  - advanced_ae:swim_speed_card
  - advanced_ae:night_vision_card
  - advanced_ae:flight_drift_card
  - advanced_ae:recharging_card
  - advanced_ae:portable_workbench_card
  - advanced_ae:pick_craft_card
---

# Quantum Armor Set

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

เคยสงสัยไหมว่าการสวมใส่ AE System จะเป็นอย่างไร ตอนนี้ไม่ต้องสงสัยอีกแล้ว Quantum Armor Set เป็นชุดเทคโนโลยีล้ำสมัยแบบล่องหนที่เชื่อมกับระบบ AE2 เพื่อให้เข้าถึงทุกอย่างได้สะดวกระหว่างเดินทาง โดยค่าเริ่มต้นเป็นชุดใช้พลังงานที่ป้องกันได้พอ ๆ กับชุด Netherite สามารถใช้บัฟเฟอร์สร้างโล่พลังงาน ที่ดูดซับความเสียหายได้มาก บูทยังลดความเสียหายจากการตก ส่วน chestplate ช่วยตัดบทลงโทษการขุดขณะบิน แต่พลังที่แท้จริงของชุดนี้ จะปลดล็อกเมื่อคุณใส่อัปเกรดเต็มเท่านั้น

<br/>

## การเชื่อมต่อชุดเกราะ

คุณเชื่อมชิ้นส่วนเกราะเข้ากับระบบทีละชิ้นได้ โดยใส่ลงในช่องที่ตรงกันของ
<ItemLink id="ae2:wireless_access_point" /> ซึ่งปลดล็อกสิทธิพิเศษที่ต่างกันตามชิ้นส่วนเกราะและ upgrade card ที่ติดตั้ง
จะอธิบายต่อไปภายหลัง โปรดทราบว่าเพื่อให้ฟังก์ชันเสริมเหล่านี้ทำงานได้ถูกต้อง คุณต้องอยู่ในระยะ
ของ access point ที่เชื่อมต่อด้วย

<br/>

## การติดตั้งอัปเกรด

หากต้องการติดตั้งอัปเกรด คุณต้องสวมชิ้นส่วนเกราะก่อน แล้วเปิด Quantum Armor Configuration Menu โดยกดปุ่มลัด (ค่าเริ่มต้นคือ N)

![QAGUI](../pic/quantum_armor_config.png)

ในหน้านี้ คุณเพิ่ม/ถอดอัปเกรด เปิด/ปิดอัปเกรด และตั้งค่าของอัปเกรดที่มีตัวเลือกได้

<br/>

## Quantum Upgrade Base Card

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

<ItemLink id="advanced_ae:quantum_upgrade_base" /> ไม่มีความสามารถพิเศษในตัวเอง แต่ใช้เป็นวัตถุดิบคราฟต์ของ upgrade card ทุกใบ

<br/>

## Auto Feeding Card

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_feeding_card" /> ให้คุณเลือกไอเทมเฉพาะที่ใช้เลี้ยงอาหารผู้เล่น เพียงลากไอเทมที่ต้องการใส่ช่องฟิลเตอร์ ถ้าชุดเกราะเชื่อมกับ AE2 grid อยู่ ระบบจะพยายามหาไอเทมเหล่านั้นใน network มาให้เมื่อคุณหิว

<br/>

## Auto Stock Card

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_stock_card" /> ก็ต้องให้ชิ้นส่วนเกราะเชื่อมกับระบบ AE2 และอยู่ในระยะของ access point เช่นกัน การ์ดนี้ให้ตั้งค่าสแตกจำนวนหนึ่ง ให้คงปริมาณที่กำหนดไว้ ในช่องเก็บของของผู้ใช้เสมอ ช่องไม่จำกัดที่หนึ่งสแตก ถ้าต้องการ คุณตั้งให้มีมากกว่าหนึ่งช่องเต็ม อยู่ในช่องเก็บของตลอดเวลาได้

<br/>

## Speed Cards

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

upgrade card เหล่านี้เพิ่มความเร็วการเคลื่อนที่ของผู้สวมชุด ทุกใบตั้งค่าความเร็วที่ต้องการได้ และมีผลกับการเคลื่อนที่ ขณะย่องและขณะบินด้วย ที่ควรรู้คือ อัปเกรดเหล่านี้ใช้ลดความเร็วได้ด้วย เพื่อให้ควบคุมได้ง่ายขึ้น เมื่อมีเอฟเฟกต์เพิ่มความเร็วอื่นอยู่

<br/>

## Height Cards

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

อัปเกรดเหล่านี้เปลี่ยนการเคลื่อนที่แนวตั้ง ให้ตั้งความสูงในการกระโดดให้มากขึ้น หรือช่วยก้าวขึ้นบล็อกได้

<br/>

## Flight Cards

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### Flight Card

<ItemLink id="advanced_ae:flight_card" /> เมื่อติดตั้งจะเปิดใช้การบินแบบ creative ตั้งความเร็วบินได้ด้วยแถบเลื่อนใน UI และได้รับผลบวกจากอัปเกรดความเร็วเดิน/วิ่งด้วย

### Flight Drift Card

<ItemLink id="advanced_ae:flight_drift_card" /> ใช้ได้เฉพาะเมื่อติดตั้ง Flight Card แล้ว และเพิ่มแถบเลื่อนอีกอันสำหรับปรับแรงเฉื่อยของการบินแบบ creative ค่าต่ำจะหยุดเร็วขึ้น และหยุดทันทีเมื่อตั้งค่าเป็น 0

<br/>

## ME Recharging Card

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:recharging_card" /> เปิดใช้การชาร์จแบบไร้สายให้ชิ้นส่วนที่สวมอยู่ ต้องเชื่อมกับ grid และอยู่ในระยะของ access point ถ้าติดตั้งอัปเกรดนี้ใน chestplate จะชาร์จไอเทมในช่องเก็บของด้วย

<br/>

## Portable Workbench Card

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:portable_workbench_card" /> เพิ่ม cell workbench แบบพกพาให้ชุด quantum หากต้องการเปิด ให้กดปุ่มลัดที่ตั้งไว้ ใช้งานเหมือนรุ่นบล็อกทุกประการ

<br/>

## Pick Craft Card

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:pick_craft_card" /> เพิ่มฟีเจอร์ปุ่มลัดใหม่ให้เกราะ เมื่อกดจะพยายามคราฟต์บล็อกที่ผู้เล่นกำลังเล็งอยู่ ฟีเจอร์นี้ต้องเชื่อมกับ grid และมี pattern ที่ตรงกับเป้าหมาย จะมีหน้าต่างป๊อปอัปให้ใส่จำนวนที่ต้องการ แล้วขั้นตอนที่เหลือเหมือนคำขอ auto-craft ปกติทุกประการ

<br/>

## Utilities Cards

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

การ์ดเหล่านี้ให้ประโยชน์ใช้สอยหลายอย่างแก่ผู้สวมชุด เช่น ภูมิคุ้มกันความเสียหายบางประเภทและ night vision โดยเฉพาะ magnet card ที่มีหน้าตั้งค่าให้กำหนดฟิลเตอร์ว่าจะเก็บอะไรหรือไม่เก็บอะไร และตั้งระยะได้

<br/>

## Defensive Cards

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" />
* <ItemLink id="advanced_ae:regeneration_card" />
* <ItemLink id="advanced_ae:evasion_card" />

อัปเกรดเหล่านี้ให้ประโยชน์ด้านการป้องกัน แก่ผู้สวมชุด ในหลายรูปแบบ hp card เพิ่มพลังชีวิตสูงสุด ส่วน regeneration card เพิ่มความเร็วในการฟื้นพลังชีวิต evasion card ให้ภูมิคุ้มกันความเสียหายจากทุกแหล่งโดยมีโอกาสเกิดขึ้น

<br/>

## Offensive Cards

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

อัปเกรดเหล่านี้เพิ่มความสามารถด้านการโจมตีของผู้สวมชุด โดยเพิ่ม Attack Damage และ Attack Speed

<br/>

## Stats Cards

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" />
* <ItemLink id="advanced_ae:reach_card" />

upgrade card เหล่านี้เพิ่มค่าสถานะคงที่ให้ผู้สวมชุด มีผลต่อ luck เพื่อให้ได้ของดรอปดีขึ้น และระยะเอื้อมของบล็อก reach card ตั้งค่าให้เป็นค่าที่ต้องการได้

<br/>

## มีอะไรอีกมากในอนาคต

ชุดอุปกรณ์นี้เปิดตัวเป็นพื้นฐาน โดยมีฟีเจอร์อื่นอีกมากที่วางแผนจะเพิ่มในอนาคต โปรดติดตามต่อไป