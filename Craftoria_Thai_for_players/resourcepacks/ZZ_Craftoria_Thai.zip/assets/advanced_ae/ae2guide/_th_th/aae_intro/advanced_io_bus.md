---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Advanced IO Bus
  icon: advanced_ae:advanced_io_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:advanced_io_bus_part
---

# Advanced IO Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

Advanced IO Bus เป็นเครื่องมือทรงพลังสำหรับจัดการคลังไอเทมภายนอก สร้างได้จากการหลอมรวม
<ItemLink id="advanced_ae:import_export_bus_part"/> เข้ากับ <ItemLink id="advanced_ae:stock_export_bus_part"/> จึงมีความสามารถ
ของทั้งสองตัว นอกจากนี้ ความเร็วพื้นฐานของ Advanced IO Bus ยังสูงกว่า
<ItemLink id="ae2:export_bus"/> 8 เท่า ต้องใช้เวลาสักพักกว่าจะเร่งความเร็วขึ้น แต่จะเร็วมาก
เมื่ออัปเกรดครบ

## การส่งออก

Advanced IO Bus จะส่งออกตามฟิลเตอร์ จนถึงจำนวนคงที่ที่ตั้งไว้แล้วหยุด ทางด้านซ้ายของ UI ยังมีตัวเลือกให้ผู้เล่นเลือกควบคุมปริมาณสต็อกของไอเทมได้

## การนำเข้า

Advanced IO Bus จะนำเข้าทุกอย่างที่ไม่ได้ตั้งฟิลเตอร์ให้ส่งออกด้วย การนำเข้าและส่งออกนับแยกกัน บัสจึงไม่ติดอยู่กับงานใดงานหนึ่ง เมื่อตั้งให้ควบคุมสต็อก บัสจะให้ความสำคัญกับการนำเข้าของที่เกินจำนวนที่ตั้งไว้ก่อน หากยังเหลือจำนวนครั้งในการทำงาน จะนำเข้าของที่ไม่ได้อยู่ในฟิลเตอร์

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>