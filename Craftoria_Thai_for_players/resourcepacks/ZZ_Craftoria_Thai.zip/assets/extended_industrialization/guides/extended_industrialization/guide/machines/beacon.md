---
navigation:
  title: "Electric Beacon"
  icon: "electric_beacon"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:electric_beacon
---

# Electric Beacon

<RecipeFor id="extended_industrialization:electric_beacon" />

Electric Beacon ใช้ยาและให้เอฟเฟกต์แก่ผู้เล่นทุกคนที่อยู่ใกล้ โดยเสีย 256 EU/t ต่อหนึ่งเอฟเฟกต์ ระยะเวลาที่ยาอยู่ใน beacon ขึ้นกับเอฟเฟกต์ที่สั้นที่สุด แล้วลดลงครึ่งหนึ่ง ส่วนใหญ่ยามีเอฟเฟกต์เดียว เช่น ยา Speed 8 นาทีที่ beacon ใช้ จะให้เอฟเฟกต์ในพื้นที่รวม 4 นาที โดยเสีย 256 EU/t ในทำนองเดียวกัน ยา Turtle Master 40 วินาทีจะอยู่ได้แค่ 20 วินาที แต่เสีย 512 EU/t เพราะมีสองเอฟเฟกต์ (Slowness และ Resistance) เนื่องจาก beacon ใช้ยาจนหมด แนะนำให้สร้างระบบอัตโนมัติวนซ้ำด้วย [Brewery](brewery.md) เพื่อให้ beacon ทำงานได้ไม่สิ้นสุด

ระยะของ beacon กว้างกว่า beacon ปกติ โดยขึ้นกับจำนวนชั้นที่อยู่ด้านล่าง ไม่นับ steel casing

| ชั้น | ระยะ |
|--------|-------|
| 1      | 30    |
| 2      | 50    |
| 3      | 70    |
| 4      | 90    |

<GameScene zoom="1.5" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_beacon" />
    <MultiblockShape controller="extended_industrialization:electric_beacon" useBigShape={true} x="-9" y="2" z="-9" />
</GameScene>