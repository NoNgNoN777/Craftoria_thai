---
navigation:
  title: "Machine Chainer"
  icon: "machine_chainer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:machine_chainer
  - extended_industrialization:machine_chainer_relay
---

# Machine Chainer

<GameScene zoom="2" interactive={true} fullWidth={true}>
	<ImportStructure src="machine_chainer_example.nbt" />
	<IsometricCamera yaw="180" pitch="30" />
</GameScene>

Machine Chainer เชื่อมกับเครื่องจักร บาร์เรล หรือบล็อกคลังอื่นที่ติดแท็ก `#extended_industrialization:machine_chainer/linkable` ได้หลายตัวเป็นแนวตรงยาวสูงสุด 64 บล็อก คลังที่เชื่อมจะรวมเป็นคลังร่วมเดียวกับ chainer หัน chainer ไปทิศใดก็ได้ รวมถึงขึ้นและลง

chainer รองรับการส่งไอเทม ของเหลว และพลังงาน แต่การส่งพลังงานจำกัดที่ 3 เท่าของอัตราส่งของสายเคเบิลหนึ่งเส้นในระดับเดียวกัน และไม่สามารถใช้งานพลังงานของเครื่องที่เชื่อมซึ่งแรงดันไม่ตรงกับ chainer

## Machine Chainer Relay

relay คือบล็อกที่ chainer เชื่อมถึงได้ แต่ไม่มีคลัง ใช้เป็นตัวเติมช่องว่างในแนวเครื่องที่ต่อกันได้ โดยไม่ต้องวางเครื่องในช่องว่าง

<RecipeFor id="extended_industrialization:machine_chainer_relay" />