---
navigation:
  title: "Farmer"
  icon: "steam_farmer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steam_farmer
  - extended_industrialization:electric_farmer
---

# Farmer

<Row>
	<RecipeFor id="extended_industrialization:steam_farmer" />
	<RecipeFor id="extended_industrialization:electric_farmer" />
</Row>

Farmer ไม่ใช่เครื่องจักรทั่วไปที่ทำสูตร แต่จะไถและให้น้ำดิน ปลูก ใส่ปุ๋ย และเก็บเกี่ยวพืชผล พืช และต้นไม้ ไม่จำเป็นต้องใช้งานทุกอย่างเพื่อให้ Farmer ทำงาน บางครั้งคุณอาจอยากหลีกเลี่ยงบางงาน เช่น เมื่อทำงานกับต้นไม้ คุณคงไม่อยากให้ Farmer ไถหรือให้น้ำดิน

Farmer จะไม่ทำงานหากพลังงานไม่พอ Steam Farmer ต้องใช้ไอน้ำ 32 EU/t ส่วน Electric Farmer ต้องใช้ 64 EU/t

ดินที่ต้องใช้เป็นส่วนหนึ่งของมัลติบล็อก Farmer แทนด้วยบล็อกใดก็ได้ที่มีแท็ก `#extended_industrialization:farmer_dirt`

## งานที่ทำ

### ไถดิน

เมื่อเปิดไว้ในการตั้งค่ารูปร่างมัลติบล็อก บล็อกดินที่เป็นส่วนของมัลติบล็อกจะถูกเปลี่ยนเป็น farmland เหมือนใช้จอบไถ

### ให้น้ำดิน

เมื่อ Farmer ได้รับน้ำผ่าน input hatch มันจะรักษาให้ farmland ทั้งหมดชุ่มน้ำอยู่เสมอ โดยไม่ต้องวางน้ำไว้ใกล้ ๆ

### ปลูก

เมื่อ Farmer ได้รับไอเทมที่ปลูกได้ใน input hatch จะปลูกลงบนบล็อกที่เหมาะสมในพื้นที่ทำงาน ปลูกได้เฉพาะไอเทมที่มีแท็ก `#extended_industrialization:farmer_plantable`

### ใส่ปุ๋ย

การใส่ปุ๋ยมีเฉพาะ Electric Farmer เมื่อได้รับปุ๋ยเหลวที่รองรับ (ดูได้ใน EMI) ใน input hatch Farmer จะให้ผลคล้ายผงกระดูกกับพืชในพื้นที่ทำงาน ผลคล้ายผงกระดูกนี้ใช้ได้กับพืชที่ปกติใช้ผงกระดูกไม่ได้ เช่น กระบองเพชรและอ้อย

### เก็บเกี่ยว

เมื่อมีพืชที่โตเต็มที่ (เช่นข้าวสาลีโตเต็มที่ หรือต้นกล้าโตเป็นต้นไม้) และมีที่ว่างพอใน output hatch พืชนั้นจะถูกทุบและเก็บเข้าคลัง

ไอเทมที่มีแท็ก `#extended_industrialization:farmer_voidable` มีลำดับความสำคัญต่ำในการเก็บลง output hatch และถ้าไม่มีที่ว่างตอนบล็อกที่เก็บเกี่ยวดรอปของ ไอเทมนั้นจะถูกทิ้งแทน ตัวอย่างคือ <ItemLink id="minecraft:stick" /> และ <ItemLink id="minecraft:apple" /> ซึ่งหมายความว่าคุณล็อกช่องเอาต์พุตของ output hatch ให้เหลือแค่ท่อนไม้และต้นกล้า โดยไม่ต้องห่วงเรื่องเก็บไอเทมเหล่านั้น

## Steam Farmer

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:steam_farmer" />
    <MultiblockShape controller="extended_industrialization:steam_farmer" useBigShape={true} x="-10" z="-10" />
</GameScene>

## Electric Farmer

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_farmer" />
    <MultiblockShape controller="extended_industrialization:electric_farmer" useBigShape={true} x="-12" z="-12" />
</GameScene>