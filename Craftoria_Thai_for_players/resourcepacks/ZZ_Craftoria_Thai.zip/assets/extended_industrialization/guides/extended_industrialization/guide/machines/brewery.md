---
navigation:
  title: "Brewery"
  icon: "electric_brewery"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steel_brewery
  - extended_industrialization:electric_brewery
  - extended_industrialization:blazing_essence_bucket
---

# Brewery

<Row>
	<RecipeFor id="extended_industrialization:steel_brewery" />
	<RecipeFor id="extended_industrialization:electric_brewery" />
</Row>

Brewery ทำงานเหมือนเครื่องจักรปกติ แต่ทำสูตรของ Brewing Stand มีความแตกต่างอยู่บ้าง

Brewery ใช้ Blazing Essence แทน Blaze Powder ทุกครั้งที่ต้มยาหนึ่งชุด จะใช้ Blazing Essence พอดี 1mb

Brewery ต้มยา_ครั้งละ 4 ขวดพอดี_ ต่างจาก Brewing Stand ที่ต้มได้ 1 ถึง 3 ขวด