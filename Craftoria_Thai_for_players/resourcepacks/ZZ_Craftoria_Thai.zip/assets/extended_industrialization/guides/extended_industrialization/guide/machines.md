---
navigation:
  title: "เครื่องจักร"
  position: 10
---

# เครื่องจักร

<SubPages />
