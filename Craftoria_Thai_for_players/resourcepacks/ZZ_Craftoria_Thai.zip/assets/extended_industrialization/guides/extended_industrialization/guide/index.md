---
navigation:
  title: "Extended Industrialization"
  position: 0
---

# Extended Industrialization

<MarginFloatingImage src="assets/logo.png" left="0" right="10" />

Extended Industrialization คือแอดออนของ Modern Industrialization ที่เพิ่มเครื่องจักรและเครื่องมือหลากหลาย

เป้าหมายหลักของ Extended Industrialization คือขยายเนื้อหาของ Modern Industrialization ให้ครอบคลุมมากขึ้น โดยยังคงแนวคิดการออกแบบและการใช้งานเดิม ตัวอย่างเช่น [มัลติบล็อกแบบแบตช์](machines/batching_multiblocks.md) ช่วยให้ขยายโรงงานได้ไกลกว่าเดิม โดยตั้งค่าเครื่องน้อยลงและประหยัดประสิทธิภาพ