---
navigation:
  title: "มัลติบล็อกแบบแบตช์"
  icon: "processing_array"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:large_steam_furnace
  - extended_industrialization:large_steam_macerator
  - extended_industrialization:large_electric_furnace
  - extended_industrialization:large_electric_macerator
  - extended_industrialization:processing_array
---

# มัลติบล็อกแบบแบตช์

มัลติบล็อกบางแบบทำงานเหมือนเครื่องจักรปกติของประเภทนั้น แต่มีตัวคูณกับจำนวนอินพุตที่ประมวลผลพร้อมกันได้ กล่าวคือ มัลติบล็อกที่รันสูตรประเภทหนึ่งเป็นแบตช์ละ Y ได้ จะใช้อินพุตพร้อมกันได้ตั้งแต่ 1 ถึง Y เท่า แล้วผลิตผลลัพธ์ตามขนาดแบตช์ ค่า EU/t ที่เครื่องใช้ก็คูณตามจำนวนแบตช์ที่กำลังรันอยู่ด้วย

จำนวนแบตช์ที่มัลติบล็อกแบบแบตช์รันได้ต่างกันไป หากต้องการดูค่าเฉพาะ ให้ดูทูลทิปของไอเทมเครื่องนั้น

เหมือนเครื่องจักรอื่นทุกประการ เครื่องเหล่านี้รันสูตรได้ไม่เกินหนึ่งสูตรในเวลาเดียวกัน

## Large Furnace

จำนวนแบตช์ที่ Large Electric Furnace รันได้ขึ้นกับคอยล์ที่ใช้ในมัลติบล็อก คล้ายวิธีสร้าง Electric Blast Furnace ขนาดแบตช์ที่คอยล์ให้ในเตาดูได้จากทูลทิปของคอยล์นั้น

<Row>
	<RecipeFor id="extended_industrialization:large_steam_furnace" />
	<RecipeFor id="extended_industrialization:large_electric_furnace" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_furnace" />
    <MultiblockShape controller="extended_industrialization:large_electric_furnace" x="-6" y="-1" z="-6" />
</GameScene>

## Large Macerator

<Row>
	<RecipeFor id="extended_industrialization:large_steam_macerator" />
	<RecipeFor id="extended_industrialization:large_electric_macerator" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_macerator" />
    <MultiblockShape controller="extended_industrialization:large_electric_macerator" x="-6" z="-6" />
</GameScene>

## Processing Array

Processing Array รันแบตช์ของเครื่องคราฟต์ไฟฟ้าที่ไม่ใช่มัลติบล็อกได้ทุกชนิดที่ใส่ไว้ในอินเทอร์เฟซ ขนาดแบตช์ที่ Processing Array รันได้จำกัดด้วยขนาดของมันและจำนวนเครื่องที่ใส่เข้าไป

<RecipeFor id="extended_industrialization:processing_array" />

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:processing_array" />
    <MultiblockShape controller="extended_industrialization:processing_array" useBigShape={true} x="-6" z="-8" />
</GameScene>