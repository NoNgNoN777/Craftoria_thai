---
navigation:
  title: "พลังงานแสงอาทิตย์"
  icon: "lv_solar_panel"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:bronze_solar_boiler
  - extended_industrialization:steel_solar_boiler
  - extended_industrialization:lv_solar_panel
  - extended_industrialization:mv_solar_panel
  - extended_industrialization:hv_solar_panel
  - extended_industrialization:lv_photovoltaic_cell
  - extended_industrialization:mv_photovoltaic_cell
  - extended_industrialization:hv_photovoltaic_cell
---

# พลังงานแสงอาทิตย์

## Solar Boilers

Solar Boiler ทำงานคล้าย Bronze และ Steel Boiler ปกติ แต่ไม่ใช้เชื้อเพลิง แลกกับการที่ต้องได้รับแสงแดดตรงจากด้านบน และผลิตพลังงานได้ครึ่งหนึ่งของ Boiler มาตรฐานประเภทเดียวกัน แน่นอนว่ายังต้องใช้น้ำ

เมื่อเวลาผ่านไป Solar Boiler จะเกิดตะกรันและเสียประสิทธิภาพสูงสุดรวม 33% การใช้ขวานกับ Solar Boiler จะรีเซ็ตตะกรัน หลีกเลี่ยงได้ทั้งหมดโดยป้อน Distilled Water แทนน้ำปกติ

<Row>
	<RecipeFor id="extended_industrialization:bronze_solar_boiler" />
	<RecipeFor id="extended_industrialization:steel_solar_boiler" />
</Row>

## Solar Panels

Solar Panel ผลิตพลังงานเมื่อวางกลางแสงแดดตรงและมีเซลล์โฟโตโวลเทอิก (photovoltaic cell) ระดับเดียวกัน เมื่อเวลาผ่านไปเซลล์จะกร่อนและพังในที่สุด หมายความว่าต้องผลิตเซลล์ไว้ต่อเนื่องเพื่อให้ผลิตพลังงานช่วงกลางวันได้สม่ำเสมอ อายุเซลล์เพิ่มเป็นสองเท่าได้ถ้าป้อน Distilled Water ให้ Solar Panel

<Row>
	<RecipeFor id="extended_industrialization:lv_solar_panel" />
	<RecipeFor id="extended_industrialization:mv_solar_panel" />
	<RecipeFor id="extended_industrialization:hv_solar_panel" />
</Row>