---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Crystal
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# The Entro Crystal

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*"Entro Crystal แสดงสัมพรรคภาพข้ามมิติที่แรงมาก หลังจากฉีด Ender Dust เข้าไปใน Fluix Crystal และสั่นพ้องข้ามกาลอวกาศได้"*

เป็นวัตถุดิบคราฟต์หลักของไอเทมและเครื่องจักร ExtendedAE ส่วนใหญ่ คุณต้องใช้ <ItemLink id="extendedae:entro_seed" /> เปลี่ยน
<ItemLink id="ae2:fluix_block" /> ให้เป็น [Entroized Fluix Budding](./entro_budding.md) แล้วเก็บเกี่ยว Entro Cluster เพื่อรับ Entro Crystal
