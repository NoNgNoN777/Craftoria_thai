---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Canner
    icon: extendedae:caner
categories:
- extended devices
item_ids:
- extendedae:caner
---

# ME Canner

<BlockImage id="extendedae:caner" scale="8"></BlockImage>

ME Canner เป็นเครื่องสำหรับ "บรรจุกระป๋อง" วัสดุ ทั้งของเหลว แก๊สของ Mekanism มานาของ Botania และแม้แต่พลังงาน

ช่องแรกใส่วัสดุที่ใช้บรรจุ ช่องที่สองใส่ไอเทมที่จะถูกบรรจุ

ต้องใช้พลังงานในการทำงาน แต่ละครั้งใช้ 80 AE

![GUI](../pic/caner_gui.png)

โดยปกติบรรจุได้เฉพาะของเหลว ติดตั้ง addon ที่เกี่ยวข้องเพื่อให้บรรจุวัสดุอื่นได้

### Addon ที่รองรับ:
- Applied Flux
- Applied Mekanistics
- Applied Botanics Addon

## คราฟต์อัตโนมัติด้วย ME Caner

มีเฉพาะด้านบนและด้านล่างที่รับพลังงานและเชื่อมต่อกับเครือข่ายได้

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

ตัวอย่างการตั้งค่า ME Canner แบบง่าย ME Canner จะดีดไอเทมที่บรรจุแล้วออกมาเองเมื่อได้รับวัตถุดิบจาก <ItemLink id="ae2:pattern_provider" />

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

Pattern ต้องมีเฉพาะวัสดุที่ใช้บรรจุและภาชนะที่จะบรรจุ ตัวอย่างเช่น

บรรจุถังน้ำ:

![P1](../pic/fill_water.png)

ชาร์จ Energy Tablet (ต้องใช้ Applied Flux):

![P1](../pic/fill_energy.png)


## การถอดออกจากกระป๋อง

ME Canner ยังดึงวัสดุออกจากภาชนะได้ในโหมด Empty คุณต้องสลับอินพุตกับเอาต์พุตใน pattern
