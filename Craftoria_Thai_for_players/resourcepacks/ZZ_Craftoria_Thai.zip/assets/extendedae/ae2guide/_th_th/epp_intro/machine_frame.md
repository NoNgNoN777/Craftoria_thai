---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Machine Frame
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# จุดเริ่มต้นของ ExtendedAE

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

เมื่อสะสม <ItemLink id="extendedae:entro_crystal" /> ได้เพียงพอ ในที่สุดคุณก็คราฟต์ Extended Machine Frame อันแรกได้
โครงเหล่านี้เป็นรากฐานของ ExtendedAE และเครื่องจักรแบบบล็อกส่วนใหญ่ใน ExtendedAE ต้องใช้
