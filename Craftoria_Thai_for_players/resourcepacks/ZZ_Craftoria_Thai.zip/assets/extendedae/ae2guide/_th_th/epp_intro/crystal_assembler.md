---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Crystal Assembler
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# Crystal Assembler

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

อุปกรณ์ขยายเหล่านี้ซับซ้อนเกินกว่าจะคราฟต์ในโต๊ะคราฟต์ คุณจึงต้องใช้ Crystal Assembler คราฟต์ส่วนใหญ่

**หมายเหตุ: ด้านที่มีหน้าจอเชื่อมต่อกับเครือข่ายไม่ได้**

ยังทำสูตรแปลงในโลกบางอย่างได้ด้วย เช่น การแปลง Fluix
