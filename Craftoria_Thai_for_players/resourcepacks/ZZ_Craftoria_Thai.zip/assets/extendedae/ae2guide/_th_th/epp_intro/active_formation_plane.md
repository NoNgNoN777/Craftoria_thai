---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Active Formation Plane
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME Active Formation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME Active Formation Plane คือ <ItemLink id="ae2:formation_plane" /> ที่วางบล็อกหรือทิ้งไอเทมได้อย่างแข็งขัน

คุณไม่ต้องสร้าง subnet ให้มัน ทำงานคล้าย <ItemLink id="ae2:export_bus" /> แต่วางบล็อกแทนการส่งออกไปยังหีบ
