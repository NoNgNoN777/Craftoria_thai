---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Void Cell
    icon: extendedae:void_cell
categories:
- extended items
item_ids:
- extendedae:void_cell
---

# ME Void Cell

เครื่องอัดสสารขนาดพกพาสำหรับใช้ใน drive

<ItemImage id="extendedae:void_cell" scale="4"></ItemImage>

ต้องกำหนด partition ให้ Void Cell บน <ItemLink id="ae2:cell_workbench" /> ก่อนใช้ จะลบทุกอย่างที่
ตรงกับตัวกรอง หรืออัดไอเทมที่ตรงกันเป็น <ItemLink id="ae2:matter_ball" /> หรือ <ItemLink id="ae2:singularity" /> เหมือน <ItemLink id="ae2:condenser" />

คลิกขวาเพื่อเปิด GUI ตั้งค่า

![GUI](../pic/void_cell.png)
