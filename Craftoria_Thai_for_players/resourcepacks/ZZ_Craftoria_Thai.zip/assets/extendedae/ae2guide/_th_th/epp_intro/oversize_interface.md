---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Oversize Interface
    icon: extendedae:oversize_interface
categories:
- extended devices
item_ids:
- extendedae:oversize_interface
- extendedae:oversize_interface_part
---

# ME Oversize Interface

<Row gap="20">
<BlockImage id="extendedae:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME Oversize Interface มีจำนวนช่องเท่ากับ <ItemLink id="extendedae:ex_interface" /> แต่เก็บไอเทมได้มากกว่า 16 เท่าต่อช่อง (ปรับค่าได้) หมายความว่าเก็บได้ 1024 (64 x 16) ชิ้นต่อช่อง

ไอเทมบางชิ้นจากม็อดอื่นตั้งตัวคูณเฉพาะได้
