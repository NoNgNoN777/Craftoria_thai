---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Assembler Matrix
    icon: extendedae:assembler_matrix_frame
categories:
- extended devices
item_ids:
- extendedae:assembler_matrix_frame
- extendedae:assembler_matrix_wall
- extendedae:assembler_matrix_glass
- extendedae:assembler_matrix_pattern
- extendedae:assembler_matrix_crafter
- extendedae:assembler_matrix_speed
---

# Assembler Matrix

<Row>
<BlockImage id="extendedae:assembler_matrix_frame" p:formed="true" p:powered="true" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_wall" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_glass" scale="5"></BlockImage>
</Row>
<Row>
<BlockImage id="extendedae:assembler_matrix_pattern" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_crafter" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_speed" scale="5"></BlockImage>
</Row>

Assembler Matrix เป็นโครงสร้างหลายบล็อก รวม <ItemLink id="ae2:molecular_assembler" /> และ <ItemLink id="ae2:pattern_provider" /> เข้าด้วยกัน
รันงานคราฟต์ได้พร้อมกันหลายงาน (เมื่อมี <ItemLink id="ae2:crafting_accelerator" /> เพียงพอในเครือข่าย ME ของคุณ) และช่วยประหยัด channel

## โครงสร้าง

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/assembler_matrix.snbt"></ImportStructure>
</GameScene>

เป็นทรงสี่เหลี่ยมมุมฉากที่ความยาวแต่ละด้านอยู่ระหว่าง 3 ถึง 7
- ขอบประกอบด้วย Assembler Matrix Frame
- หน้าประกอบด้วย Assembler Matrix Wall/Glass
- ภายในประกอบด้วย Assembler Matrix Pattern/Craft/Speed Core

Assembler Matrix ที่ใช้งานได้ต้องมี Pattern Core อย่างน้อยหนึ่งชิ้นและ Craft Core อย่างน้อยหนึ่งชิ้น ต้องเติมเต็มทั้งหมด ห้ามกลวง เมื่อ Assembler Matrix ก่อตัวสมบูรณ์และมีพลังงาน เส้นบน Assembler Matrix Frame จะเป็นสีน้ำเงิน

## Assembler Matrix Core

Assembler Matrix Core มี 3 แบบ

- Assembler Matrix Pattern Core

Assembler Matrix รับ pattern จาก Pattern Core เท่านั้น Pattern Core แต่ละชิ้นให้ช่อง pattern 36 ช่อง

- Assembler Matrix Craft Core

Assembler Matrix มอบหมายงานคราฟต์ที่ได้รับให้ Craft Core แต่ละชิ้นรันงานคราฟต์ได้พร้อมกัน 8 งาน

- Assembler Matrix Speed Core

เป็น <ItemLink id="ae2:speed_card" /> สำหรับ Assembler Matrix การใช้ Speed Core 5 ชิ้นทำให้ Assembler Matrix ทำงานเต็มความเร็ว
การติดตั้งเกิน 5 ชิ้นไม่ได้เพิ่มความเร็วอีก

## GUI

คลิกขวาที่ Assembler Matrix ที่ก่อตัวและออนไลน์แล้วเพื่อเปิด GUI

![GUI](../pic/assembler_matrix.png)

คุณเพิ่มหรือค้นหา pattern ในนี้ได้ และดูได้ว่ากำลังรันงานคราฟต์กี่งาน
