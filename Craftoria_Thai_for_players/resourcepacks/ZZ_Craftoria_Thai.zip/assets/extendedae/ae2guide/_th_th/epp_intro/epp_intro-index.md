---
navigation:
    title: Extended AE Introduction
    position: 60
---

# ขยายระบบ AE ของคุณ!

Extended AE นำฟีเจอร์ AE บางอย่างจาก 1.7.10/1.12.2 กลับมาสู่ AE รุ่นใหม่

[Extended AE GitHub](https://github.com/GlodBlock/ExtendedAE) 

## ระบบ Entro Crystal
<CategoryIndex category="entro system"></CategoryIndex>

## Extended Foundation
<CategoryIndex category="extended foundation"></CategoryIndex>

## Extended Devices
<CategoryIndex category="extended devices"></CategoryIndex>

## Extended Items
<CategoryIndex category="extended items"></CategoryIndex>
