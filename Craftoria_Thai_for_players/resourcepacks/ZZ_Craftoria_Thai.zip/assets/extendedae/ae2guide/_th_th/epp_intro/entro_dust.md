---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Dust
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Entro Dust

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

คุณได้มาจากการบด <ItemLink id="extendedae:entro_crystal" /> หรือทุบ [Entroized Fluix Budding](./entro_budding.md)

ใช้คราฟต์เครื่องจักร ExtendedAE บางชนิดและ <ItemLink id="extendedae:entro_ingot" />
