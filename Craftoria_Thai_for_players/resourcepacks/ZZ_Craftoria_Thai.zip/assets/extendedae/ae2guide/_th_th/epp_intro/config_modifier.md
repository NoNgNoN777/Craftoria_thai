---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Config Modifier
    icon: extendedae:config_modifier
categories:
- extended items
item_ids:
- extendedae:config_modifier
---

# Config Modifier

Config Modifier เป็นเครื่องมือแก้ไขช่อง config จำนวนมากพร้อมกัน

<ItemImage id="extendedae:config_modifier" scale="4"></ItemImage>

คลิกขวาเพื่อเปิด GUI

## วิธีใช้

Config Modifier แก้ไขช่อง config เช่นของ Interface ได้อย่างรวดเร็วตามการตั้งค่า เช่น ตั้งจำนวนไอเทมที่กำหนดเป็นค่าสูงสุดหรือลบทั้งหมด

คุณคลิกอุปกรณ์เป้าหมาย (บล็อกหรือส่วนย่อย) ในโลกด้วย Config Modifier เพื่อแก้ไข config ของมัน

## การตั้งค่า

มีการตั้งค่าหลักสองอย่างคือ **โหมดการแก้ไข** และ **จำนวนที่ใช้แก้ไข (X)**

คุณคลิกปุ่มเพื่อเปลี่ยนโหมดได้

![GUI](../pic/cm.png)

- Add/Subtract/Multiply/Divide: บวก ลบ คูณ หรือหารจำนวนที่กำหนดด้วย X
- Maximize: ตั้งจำนวนที่กำหนดเป็นค่าสูงสุด
- Minimize: ตั้งจำนวนที่กำหนดเป็นค่าต่ำสุด
- Set: ตั้งจำนวนที่กำหนดเป็น X
- Clear: ล้างไอเทมที่กำหนดทั้งหมด
