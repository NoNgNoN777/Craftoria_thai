---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Drive
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# ME Extended Drive

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

ME Extended Drive คือ <ItemLink id="ae2:drive" /> ที่มีช่องใส่ cell มากกว่า เก็บ storage cell ได้ 20 ชิ้น
