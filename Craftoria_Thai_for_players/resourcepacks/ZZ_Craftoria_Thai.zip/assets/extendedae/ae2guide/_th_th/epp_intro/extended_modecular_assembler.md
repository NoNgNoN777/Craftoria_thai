---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Molecular Assembler
    icon: extendedae:ex_molecular_assembler
categories:
- extended devices
item_ids:
- extendedae:ex_molecular_assembler
---

# Extended Molecular Assembler

<Row gap="20">
<BlockImage id="extendedae:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

Extended Molecular Assembler คือ <ItemLink id="ae2:molecular_assembler" /> ขั้นสูง

รันงานคราฟต์ได้พร้อมกันแปดงาน (หากเครือข่าย ME ของคุณมี <ItemLink id="ae2:crafting_accelerator" />)
และทำงานเร็วกว่าแบบปกติสองเท่า

แต่รองรับเฉพาะงานคราฟต์จาก <ItemLink id="ae2:pattern_provider" /> ดังนั้นคุณใส่ pattern เข้าไปโดยตรงไม่ได้

