---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Tag Storage Bus
    icon: extendedae:tag_storage_bus
categories:
- extended devices
item_ids:
- extendedae:tag_storage_bus
---

# ME Tag Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Tag Storage Bus คือ <ItemLink id="ae2:storage_bus" /> ที่กรองด้วย tag ของไอเทมหรือของเหลวได้ และรองรับตัวดำเนินการตรรกะพื้นฐานบางอย่าง

ตัวอย่างเช่น

- รับเฉพาะแร่ดิบ

c:raw_materials/*

- รับ Ingot และอัญมณีทั้งหมด

c:ingots/* | c:gems/*

