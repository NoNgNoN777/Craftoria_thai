---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Export/Import Bus
    icon: extendedae:ex_import_bus_part
categories:
- extended devices
item_ids:
- extendedae:ex_import_bus_part
- extendedae:ex_export_bus_part
---

# ME Extended Import/Export Bus

<Row gap="20">
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_import_bus.snbt"></ImportStructure>
</GameScene>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_export_bus.snbt"></ImportStructure>
</GameScene>
</Row>

ME Extended Import/Export Bus ทำงานเร็วกว่า <ItemLink id="ae2:import_bus" /> และ <ItemLink id="ae2:export_bus" /> ปกติ
(ตัวคูณความเร็วเริ่มต้นคือ 8 และปรับค่าได้)

และมีช่องอัปเกรดมากกว่าแบบปกติด้วย

