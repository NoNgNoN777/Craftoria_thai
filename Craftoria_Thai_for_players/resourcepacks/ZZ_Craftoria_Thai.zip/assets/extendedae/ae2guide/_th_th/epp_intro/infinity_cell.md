---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Infinity Cell
    icon: extendedae:infinity_water_cell
categories:
- extended items
item_ids:
- extendedae:infinity_water_cell
- extendedae:infinity_cobblestone_cell
---

# ME Infinity Cell

แหล่งน้ำและ Cobblestone แบบง่าย ในรูปแบบ storage cell

<Row>
<ItemImage id="extendedae:infinity_water_cell" scale="4"></ItemImage>
<ItemImage id="extendedae:infinity_cobblestone_cell" scale="4"></ItemImage>
</Row>

เก็บไอเทม/ของเหลวได้ 2.1 พันล้านหน่วย คุณดึง Cobblestone/น้ำออกได้ไม่จำกัด หรือใส่ Cobblestone/น้ำเข้าไปได้ไม่จำกัด
