---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Pattern Modifier
    icon: extendedae:pattern_modifier
categories:
- extended items
item_ids:
- extendedae:pattern_modifier
---

# Pattern Modifier

Pattern Modifier เป็นเครื่องมือแก้ไข pattern จำนวนมากพร้อมกัน

<ItemImage id="extendedae:pattern_modifier" scale="4"></ItemImage>

คลิกขวาเพื่อเปิด GUI

## โหมดคูณ

คุณคูณหรือหารจำนวนอินพุตและเอาต์พุตของ processing pattern ด้วยตัวคูณ x ได้ โดยคลิกปุ่มที่เกี่ยวข้อง

![PM](../pic/pm.png)

Pattern ต้นฉบับ:

![PM1](../pic/pm1.png)

หลังคูณ ×10:

![PM2](../pic/pm2.png)

คลิกปุ่ม Clear เพื่อล้างเนื้อหาของ pattern ทั้งหมดให้กลายเป็น blank pattern ได้ด้วย

### หมายเหตุ

 - ปุ่มหารใช้ได้เฉพาะเมื่อจำนวนที่เกี่ยวข้องหารลงตัว เช่น ปุ่ม ÷2 ใช้ไม่ได้เมื่อ pattern ต้องการ
 Cobblestone 3 ก้อนเป็นอินพุต เพราะ 3 ÷ 2 เท่ากับ 1.5

 - ปุ่มคูณมีเพดานที่ 999999 เพิ่มจำนวนของวัตถุดิบชิ้นเดียวให้เกินค่านี้ไม่ได้

## โหมดแทนที่

แทนที่วัตถุดิบอินพุตหรือเอาต์พุตเฉพาะอย่างใน pattern ด้วยไอเทมอื่น

![PM3](../pic/pm4.png)

ช่อง A คือไอเทมที่จะถูกแทนที่ และช่อง B คือไอเทมที่ใช้แทน

ตัวอย่างเช่น การตั้งค่าต่อไปนี้จะแทนที่ Plank ด้วย Coal

![PM4](../pic/pm6.png)

![PM5](../pic/pm5.png)

คลิกปุ่ม Replace เพื่อสั่งแทนที่

![PM6](../pic/pm7.png)

## โหมดคุณสมบัติ

แก้ไขโหมด Substitutions และ Fluid Substitutions ของ crafting pattern

![PM8](../pic/pm8.png)

## โหมดโคลน

ในโหมดนี้ คุณทำสำเนาของ pattern ใดก็ได้

![PM7](../pic/pm3.png)

