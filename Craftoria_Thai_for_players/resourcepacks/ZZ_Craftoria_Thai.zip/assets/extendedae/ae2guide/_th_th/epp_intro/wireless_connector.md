---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Wireless Connector
    icon: extendedae:wireless_connect
categories:
- extended devices
item_ids:
- extendedae:wireless_connect
- extendedae:wireless_tool
---

# ME Wireless Connector

<Row gap="20">
<BlockImage id="extendedae:wireless_connect" scale="6"></BlockImage>
<ItemImage id="extendedae:wireless_tool" scale="6"></ItemImage>
</Row>

ME Wireless Connector เชื่อมสองเครือข่ายเข้าด้วยกันเหมือน <ItemLink id="ae2:quantum_link" /> แต่มีระยะจำกัดและเชื่อมข้ามมิติไม่ได้ ME Wireless Connector รองรับเฉพาะการเชื่อมต่อแบบหนึ่งต่อหนึ่ง ใช้ <ItemLink id="extendedae:wireless_hub" />
หากต้องการเชื่อมต่อแบบหลายต่อหลาย

## เชื่อม Wireless Connector

ใช้ ME Wireless Setup Kit คลิก Wireless Connector สองตัวที่ต้องการเชื่อม

กด Sneak + คลิกเพื่อล้างการตั้งค่าปัจจุบันของ ME Wireless Setup Kit

ME Wireless Connector เปลี่ยนเท็กซ์เจอร์เมื่อสร้างการเชื่อมต่อสำเร็จ

ME Wireless Connector ที่ยังไม่เชื่อมต่อ

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_off.snbt"></ImportStructure>
</GameScene>

ME Wireless Connector ที่เชื่อมต่อแล้ว

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_on.snbt"></ImportStructure>
</GameScene>

## สี

Wireless Connector ย้อมสีได้เหมือนสายเคเบิล และเชื่อมต่อได้เฉพาะกับสาย/connector สีเดียวกัน

คุณต้องใช้ <ItemLink id="ae2:color_applicator" /> ย้อมสี connector

คุณจึงตั้ง wireless connector ได้แบบนี้

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/wireless_connector_setup.snbt"></ImportStructure>
</GameScene>

## การใช้พลังงาน

ME Wireless Connector ใช้พลังงานมากขึ้นเมื่ออยู่ห่างกันมากขึ้น เนื่องจากเส้นโค้งต้นทุน-ระยะทางไม่เป็นเส้นตรง ค่าพลังงานจึงสูงมากเมื่ออยู่ห่างกันเกินไป

คุณใช้ <ItemLink id="ae2:energy_card" /> ประหยัดพลังงานได้ การ์ดแต่ละใบลดค่าพลังงานลง 10%

