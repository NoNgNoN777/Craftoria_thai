---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Crystal Fixer
    icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# ME Crystal Fixer

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

ME Crystal Fixer ซ่อมแซม Budding Certus Quartz และอัปเกรดได้

ต้องมี <ItemLink id="ae2:charged_certus_quartz_crystal" /> และพลังงานจึงจะทำงาน คลิกขวาด้วย <ItemLink id="ae2:charged_certus_quartz_crystal" /> เพื่อใส่เข้าไป

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
