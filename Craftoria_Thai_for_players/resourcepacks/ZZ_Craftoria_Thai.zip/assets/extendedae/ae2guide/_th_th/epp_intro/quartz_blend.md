---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Quartz Blend
  icon: extendedae:quartz_blend
categories:
  - extended foundation
item_ids:
  - extendedae:quartz_blend
---

# Quartz Blend

<Row>
<ItemImage id="extendedae:quartz_blend" scale="4"></ItemImage>
</Row>

ส่วนผสมของ Quartz, Coal และ Sand หลอมได้ <ItemLink id="ae2:silicon" /> มากกว่าการหลอม
Certus Quartz Dust โดยตรง

