---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Smart Annihilation Plane
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# ME Smart Annihilation Plane

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

ME Smart Annihilation Plane คือ <ItemLink id="ae2:annihilation_plane" /> ที่ทุบบล็อกหรือดูดไอเทมตามช่อง config ของมัน

คุณไม่ต้องสร้าง subnet ให้มัน ทำงานคล้าย <ItemLink id="ae2:import_bus" /> แต่ทุบบล็อกแทนการนำเข้าจากหีบ
