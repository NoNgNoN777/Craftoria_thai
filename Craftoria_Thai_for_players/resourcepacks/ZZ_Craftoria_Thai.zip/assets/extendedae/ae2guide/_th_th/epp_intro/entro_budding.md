---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Budding Entroized Fluix
    icon: extendedae:entro_budding_fully
categories:
- entro system
item_ids:
- extendedae:entro_budding_fully
- extendedae:entro_budding_mostly
- extendedae:entro_budding_half
- extendedae:entro_budding_hardly
- extendedae:entro_cluster_small
- extendedae:entro_cluster_medium
- extendedae:entro_cluster_large
- extendedae:entro_cluster
---

# Budding Entroized Fluix

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/budding_entro.snbt"></ImportStructure>
  <IsometricCamera yaw="195" pitch="30"></IsometricCamera>
</GameScene>

เป็นแหล่งกำเนิด <ItemLink id="extendedae:entro_crystal" /> และคุณสร้าง Budding Entroized Fluix ได้โดยฉีด <ItemLink id="extendedae:entro_seed" /> ใส่ <ItemLink id="ae2:fluix_block" />

กลไกการเติบโตของ Entro Bud คล้ายกับ [Certus Quartz](ae2:items-blocks-machines/budding_certus.md) แต่ Budding Entroized Fluix เสื่อมสภาพหลีกเลี่ยงไม่ได้ และสุดท้ายจะกลายเป็น <ItemLink id="ae2:quartz_block" /> ในทางทฤษฎี คุณได้ <ItemLink id="extendedae:entro_crystal" /> ประมาณ 10 ชิ้นจาก Fully Entroized Fluix โดยไม่ต้องใช้เอนชานต์ Fortune

Budding Entroized Fluix ดรอป <ItemLink id="extendedae:entro_dust" /> **หนึ่งชิ้น** เสมอเมื่อทุบ ไม่ว่าจะอยู่ในสถานะใด Entro Bud ดรอป <ItemLink id="extendedae:entro_shard" /> เมื่อยังโตไม่เต็มที่
