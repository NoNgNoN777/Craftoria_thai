---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Ingredient Buffer
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# ME Ingredient Buffer

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

บล็อกเก็บของที่เก็บเนื้อหาได้ 36 ชนิด ตั้งแต่ไอเทมไปจนถึงของเหลว
