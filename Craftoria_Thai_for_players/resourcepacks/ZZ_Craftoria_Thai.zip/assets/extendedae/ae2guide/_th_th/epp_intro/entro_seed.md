---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Seed
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# Entro Seed

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

เมล็ดเหล่านี้มีพลัง Entro เข้มข้น คลิกขวา <ItemLink id="ae2:fluix_block" /> ด้วย Entro Seed เพื่อเปลี่ยนเป็น [Entroized Fluix Budding](./entro_budding.md)
หรือใช้ <ItemLink id="extendedae:crystal_assembler" /> ฉีดเมล็ดก็ได้ แต่ได้ [Entroized Fluix Budding](./entro_budding.md) เกรดต่ำกว่า
การทำด้วยมือ
