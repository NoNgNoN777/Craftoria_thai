---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Precise Export Bus
    icon: extendedae:precise_export_bus
categories:
- extended devices
item_ids:
- extendedae:precise_export_bus
---

# ME Precise Export Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_export_bus.snbt"></ImportStructure>
</GameScene>

ME Precise Export Bus ส่งออกไอเทมหรือของเหลวตามจำนวนที่กำหนด และจะส่งออกเฉพาะเมื่อภาชนะรับเอาต์พุตทั้งหมดได้ครบ

## ตัวอย่าง

![GUI](../pic/pre_bus_gui1.png)

ส่งออก Cobblestone 3 ก้อนต่อครั้ง และหยุดส่งออกเมื่อ Cobblestone ในเครือข่ายเหลือน้อยกว่า 3

![GUI](../pic/pre_bus_gui2.png)

และหยุดส่งออกเมื่อภาชนะเป้าหมายรับเอาต์พุตทั้งหมดไม่ไหว หีบรับ Cobblestone ได้อีกเพียง 2 ก้อน export bus จึงหยุด
