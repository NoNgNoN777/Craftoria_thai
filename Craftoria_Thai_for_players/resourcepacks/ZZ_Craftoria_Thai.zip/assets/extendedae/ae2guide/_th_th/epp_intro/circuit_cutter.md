---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Circuit Slicer
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# Circuit Slicer

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

ทนความช้าของ Inscriber ไม่ไหวใช่ไหม Circuit Slicer ตัดบล็อกวัสดุเป็น
[Print](ae2:items-blocks-machines/processors.md) ของ processor ได้โดยตรง เร็วกว่า Inscriber สูงสุดเก้าเท่า

**หมายเหตุ: ด้านกระจกที่ไม่มีพอร์ตเชื่อมต่อกับเครือข่ายไม่ได้**

