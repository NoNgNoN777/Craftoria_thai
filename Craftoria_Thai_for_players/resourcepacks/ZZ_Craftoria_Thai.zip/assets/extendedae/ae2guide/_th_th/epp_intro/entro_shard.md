---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Shard
    icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# Entro Shard

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

คุณจะได้ Entro Shard เมื่อทุบ [Entro Bud](./entro_budding.md) ที่ยังโตไม่เต็มที่ Entro Shard แปดชิ้นคราฟต์กลับเป็น
<ItemLink id="extendedae:entro_crystal" /> ได้
