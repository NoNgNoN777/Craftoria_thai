---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Wireless Hub
    icon: extendedae:wireless_hub
categories:
- extended devices
item_ids:
- extendedae:wireless_hub
---

# ME Wireless Hub

<Row gap="20">
<BlockImage id="extendedae:wireless_hub" scale="6"></BlockImage>
</Row>

ME Wireless Hub ทำงานเหมือน <ItemLink id="extendedae:wireless_connect" /> ทุกประการ แต่เชื่อมต่อ hub หรือ connector ได้พร้อมกันสูงสุด 8 ตัว

## การตั้งค่าการเชื่อมต่อ

ME Wireless Hub มี 8 พอร์ต และหาพอร์ตว่างให้เองอัตโนมัติเมื่อคุณเชื่อมด้วย <ItemLink id="extendedae:wireless_tool" />

แต่เมื่อพอร์ตทั้งหมดถูกใช้งานอยู่ คุณต้องตัดการเชื่อมต่อเดิมด้วยตนเองโดยคลิกปุ่ม 'X' ก่อนตั้งการเชื่อมต่อใหม่
