---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Threshold Level Emitter
    icon: extendedae:threshold_level_emitter
categories:
- extended devices
item_ids:
- extendedae:threshold_level_emitter
---

# ME Threshold Level Emitter

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_level_emitter.snbt"></ImportStructure>
</GameScene>

ทำงานเหมือนวงจร reset-set latch ปิดสัญญาณ Redstone เมื่อจำนวนไอเทมในเครือข่ายน้อยกว่า threshold ล่าง และเปิดเมื่อจำนวนมากกว่า threshold บน

ตัวอย่างเช่น สมมติตั้ง threshold ล่างเป็น 100 และ threshold บนเป็น 150

ตอนแรกเครือข่ายว่างเปล่า emitter จึงไม่ทำงาน

เมื่อจำนวนไอเทมเพิ่มเกิน 150 emitter จะส่งสัญญาณ Redstone

เมื่อจำนวนลดลงต่ำกว่า 150 emitter ยังคงส่งสัญญาณอยู่

สุดท้าย เมื่อจำนวนตกต่ำกว่า 100 emitter จะปิด
