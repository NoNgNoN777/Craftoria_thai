---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Precise Storage Bus
    icon: extendedae:precise_storage_bus
categories:
- extended devices
item_ids:
- extendedae:precise_storage_bus
---

# ME Precise Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Precise Storage Bus คือ <ItemLink id="ae2:storage_bus" /> ที่ตั้งขีดจำกัดเป็นตัวเลขได้ และใส่ไอเทมเข้าไปจนถึงขีดจำกัดนั้นเท่านั้น

![GUI](../pic/pre_storage_bus.png)
