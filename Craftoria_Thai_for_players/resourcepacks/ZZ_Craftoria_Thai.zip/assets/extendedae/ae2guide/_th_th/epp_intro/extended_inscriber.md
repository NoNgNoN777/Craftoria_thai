---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Extended Inscriber
    icon: extendedae:ex_inscriber
categories:
- extended devices
item_ids:
- extendedae:ex_inscriber
---

# Extended Inscriber

<Row gap="20">
<BlockImage id="extendedae:ex_inscriber" scale="8"></BlockImage>
</Row>

Extended Inscriber คือ <ItemLink id="ae2:inscriber" /> ขั้นสูง

รันงาน inscribe ได้พร้อมกัน 4 งาน

มีปุ่มสำหรับเปลี่ยนขนาดสแต็กสูงสุดของช่องเก็บของ เหมือน Inscriber ปกติ

แนะนำให้ตั้งขนาดสแต็กเป็น 1 เมื่อใช้ร่วมกับ <ItemLink id="ae2:pattern_provider" /> เพื่อหลีกเลี่ยงปัญหาที่อาจเกิดขึ้น
