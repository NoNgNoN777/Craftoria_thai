---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Extended Pattern Access Terminal
    icon: extendedae:ex_pattern_access_part
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_access_part
- extendedae:wireless_ex_pat
---

# ME Extended Pattern Access Terminal

ME Extended Pattern Access Terminal มีฟีเจอร์เพิ่มเติมสามอย่างเมื่อเทียบกับ <ItemLink id="ae2:pattern_access_terminal" />

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_pattern_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="extendedae:wireless_ex_pat" scale="4"></ItemImage>
</Row>

## ค้นหา Pattern ได้ดีขึ้น

คุณค้นหา pattern ด้วยชื่อวัตถุดิบอินพุต/เอาต์พุตของมันได้

![EPA1](../pic/epa_gui1.png)

## ไฮไลต์ Pattern

บางครั้งหา pattern ที่ต้องการยังยาก เพราะ pattern แสดงเป็นกลุ่มเสมอ Extended Pattern Access Terminal ไฮไลต์ pattern ที่ตรงกันใน GUI ได้

![EPA2](../pic/epa_gui2.png)

## ไฮไลต์ Pattern Provider ในโลก

ในงานคราฟต์ขนาดใหญ่ อาจยากที่จะรู้ว่า Pattern Provider ตัวไหนค้าง Extended Pattern Access Terminal ไฮไลต์ Pattern Provider ในโลกให้ คุณจึงหาเจอได้ง่าย

![EPA3](../pic/epa_gui3.png)

