---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Vacuum Interface
    icon: extendedae:vacuum_interface
categories:
- extended devices
item_ids:
- extendedae:vacuum_interface
---

# ME Vacuum Interface

<Row>
<BlockImage id="extendedae:vacuum_interface" scale="8"></BlockImage>
</Row>

ME Vacuum Interface เก็บไอเทมที่ตกอยู่ในพื้นที่ทำงานโดยอัตโนมัติ และใส่เข้าเครือข่าย ME ที่เชื่อมต่ออยู่โดยตรง ไอเทมที่เครือข่ายรับไม่ได้จะยังอยู่ในโลก

## พื้นที่ทำงาน

![PIC](../pic/vacuum_config.png)

พื้นที่ทำงานเริ่มต้นคือ 5 x 5 x 5 บล็อก โดยมี interface เป็นศูนย์กลาง ใช้ปุ่ม Area Config ปรับขนาดและระยะเลื่อนในแต่ละแกน แต่ละมิติใหญ่ได้สูงสุด 10 บล็อก และเลื่อนพื้นที่ได้สูงสุด 16 บล็อก

![PIC2](../pic/vacuum_working_display.png)

ปุ่ม Show Working Area แสดงพื้นที่ที่ตั้งค่าไว้ในโลก
