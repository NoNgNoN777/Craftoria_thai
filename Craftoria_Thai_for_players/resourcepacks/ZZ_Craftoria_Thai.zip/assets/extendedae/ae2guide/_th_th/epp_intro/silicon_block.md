---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Block of Silicon
  icon: extendedae:silicon_block
categories:
  - extended foundation
item_ids:
  - extendedae:silicon_block
---

# Block of Silicon

<Row>
<BlockImage id="extendedae:silicon_block" scale="8"></BlockImage>
</Row>

บล็อกเก็บของสำหรับ <ItemLink id="ae2:silicon" />
