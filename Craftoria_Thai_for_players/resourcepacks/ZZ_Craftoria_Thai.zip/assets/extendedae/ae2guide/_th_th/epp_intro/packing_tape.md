---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Packing Tape
    icon: extendedae:me_packing_tape
categories:
- extended items
item_ids:
- extendedae:me_packing_tape
- extendedae:package
---

# ME Packing Tape

ME Packing Tape ห่อ ME Device ในโลกให้เป็นไอเทม Packaged Device ได้

<Row>
<ItemImage id="extendedae:me_packing_tape" scale="4"></ItemImage>
<ItemImage id="extendedae:package" scale="4"></ItemImage>
</Row>

## การห่อ

กด Sneak + คลิกขวา ME Device ด้วยเทปเพื่อรับไอเทมห่อจากมัน การตั้งค่าและช่องเก็บของทั้งหมดของอุปกรณ์จะคงอยู่ มีประโยชน์มากเมื่อคุณย้ายระบบ ME

โปรดทราบว่า ME Packing Tape รองรับเฉพาะอุปกรณ์ในรายการ และรายการอุปกรณ์ปรับค่าได้

### รายการเริ่มต้น

|                                      อุปกรณ์                                       |                                 ชื่อ                                  |
|:---------------------------------------------------------------------------------:|:---------------------------------------------------------------------:|
|    <ItemImage id="extendedae:ex_interface_part" scale="3"></ItemImage>     |    <ItemLink id="extendedae:ex_interface_part"></ItemLink>     |
| <ItemImage id="extendedae:ex_pattern_provider_part" scale="3"></ItemImage> | <ItemLink id="extendedae:ex_pattern_provider_part"></ItemLink> |
|       <ItemImage id="extendedae:ex_interface" scale="3"></ItemImage>       |       <ItemLink id="extendedae:ex_interface"></ItemLink>       |
|   <ItemImage id="extendedae:ex_pattern_provider" scale="3"></ItemImage>    |   <ItemLink id="extendedae:ex_pattern_provider"></ItemLink>    |
|            <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>             |            <ItemLink id="ae2:cable_interface"></ItemLink>             |
|         <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>         |         <ItemLink id="ae2:cable_pattern_provider"></ItemLink>         |
|               <ItemImage id="ae2:interface" scale="3"></ItemImage>                |               <ItemLink id="ae2:interface"></ItemLink>                |
|            <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>            |            <ItemLink id="ae2:pattern_provider"></ItemLink>            |
|                 <ItemImage id="ae2:drive" scale="3"></ItemImage>                  |                 <ItemLink id="ae2:drive"></ItemLink>                  |

## การแกะห่อ

คลิกขวาด้วยไอเทมห่อเหมือนวางบล็อกหรือพาร์ตของอุปกรณ์ แล้วอุปกรณ์ที่ห่อไว้จะถูกคืนออกมาจากห่อ
