---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Entro Ingot
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# Entro Ingot

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*"Entro Crystal เปราะเกินกว่าจะใช้ในโครงเครื่อง แต่เราหลอมรวมกับ Gold Ingot เพื่อเพิ่มความเหนียวได้"*

ใช้คราฟต์ <ItemLink id="extendedae:machine_frame" /> และไอเทม ExtendedAE อีกไม่กี่ชนิด
