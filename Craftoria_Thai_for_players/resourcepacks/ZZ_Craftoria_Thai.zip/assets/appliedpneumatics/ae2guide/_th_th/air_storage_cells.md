---
navigation:
  parent: index.md
  title: Air Storage Cells
  icon: appliedpneumatics:air_cell_1k
  position: 20
item_ids:
  - air_cell_1k
  - air_cell_4k
  - air_cell_16k
  - air_cell_64k
  - air_cell_256k
  - air_cell_1m
  - air_cell_4m
  - air_cell_16m
  - air_cell_64m
  - air_cell_256m
  - portable_air_cell_1k
  - portable_air_cell_4k
  - portable_air_cell_16k
  - portable_air_cell_64k
  - portable_air_cell_256k
  - portable_air_cell_1m
  - portable_air_cell_4m
  - portable_air_cell_16m
  - portable_air_cell_64m
  - portable_air_cell_256m
  - air_cell_shell
  - mega_air_cell_shell
---

# Air Storage Cells

<Row>
    <ItemImage id="air_cell_1k" scale="4" />
</Row>

Air Storage Cell ให้เครือข่าย ME เก็บอากาศได้ แต่ละ byte เก็บอากาศได้ 250 mL เมื่อ cell เต็มแล้วยังใส่อากาศเพิ่ม cell จะถูกดีดออกจาก drive และอาจทำให้ drive ระเบิดได้

## Portable Storage Cell
Portable storage cell ใส่ใน drive ได้เหมือน air storage cell ปกติ และทำหน้าที่เป็นถังอากาศที่มีความดันสูงสุด 20 bar ได้ด้วย โดยโต้ตอบกับเครื่องของ PneumaticCraft ได้โดยตรง

## การ์ดอัปเกรดที่ใช้ได้
- [Security Card](upgrades.md): ปกป้อง drive และ storage cell ของคุณ เมื่อเต็มจะปฏิเสธการใส่เพิ่มโดยอัตโนมัติ
- [Vacuum Card](upgrades.md): เมื่อเต็ม อากาศส่วนเกินที่ใส่เข้ามาจะถูกทำลายโดยอัตโนมัติ ปกป้อง drive ของคุณได้เหมือน Security Card
- [Charging Card](upgrades.md): สำหรับ portable storage cell ใช้พลังงานและอากาศที่เก็บไว้ เพื่อชาร์จไอเทมที่ใช้ก๊าซในช่องเก็บของของผู้เล่น  
