---
navigation:
  parent: index.md
  title: Amadron Processing Station
  icon: appliedpneumatics:me_amadron_process_station
  position: 70
item_ids:
  - appliedpneumatics:me_amadron_process_station
  - appliedpneumatics:me_amadron_extended_process_station
  - appliedpneumatics:amadron_pattern
  - appliedpneumatics:amadron_process_upgrade
---

# Amadron Processing Station

<Row>
  <BlockImage id="me_amadron_process_station" scale="4" />
  <BlockImage id="me_amadron_extended_process_station" scale="4" />
  <ItemImage id="amadron_pattern" scale="4" />
  <ItemImage id="amadron_process_upgrade" scale="4" />
</Row>

ประมวลผลคำสั่งซื้อที่มาจาก **Amadron Wireless Terminal** และ **autocrafting ของเครือข่าย ME**  
เมื่อคำสั่งซื้อเข้าคิวแล้ว สถานีจะส่งคำขอ drone ไปยัง Amadron Shopping Center ทุก 200 game tick

Drone ของบริษัท Amadron จะมาเก็บทรัพยากรและส่งสินค้า  
Drone แต่ละตัวจัดการคำสั่งซื้อได้เพียงชนิดเดียว

ระหว่างขั้นตอนนี้ คุณต้องแน่ใจเสมอว่าด้านบนของสถานี **ไม่มีสิ่งกีดขวาง** ไม่เช่นนั้น Drone ของ Amadron อาจไม่ยอมออกปฏิบัติงาน  
หากเกิดเหตุนี้ สถานีประมวลผลของคุณจะอุดตันด้วยทรัพยากรและต้องเคลียร์ด้วยมือ

หากสถานีประมวลผลถูกทำลายขณะที่คิวคำสั่งซื้อยังไม่ว่าง ทรัพยากรของคำสั่งซื้อที่ยังไม่เสร็จทั้งหมดจะถูกส่งคืนเครือข่าย ME  
หากเครือข่าย ME ใช้งานไม่ได้หรือมีที่ว่างไม่พอ ทรัพยากรที่เหลือจะถูกดรอปเป็นไอเทม

## การ์ดอัปเกรดที่ใช้ได้
- **Acceleration Card**: เพิ่มทั้งจำนวน drone สูงสุดที่ส่งได้ต่อรอบ และจำนวนคำสั่งซื้อสูงสุดที่ drone แต่ละตัวประมวลผลได้