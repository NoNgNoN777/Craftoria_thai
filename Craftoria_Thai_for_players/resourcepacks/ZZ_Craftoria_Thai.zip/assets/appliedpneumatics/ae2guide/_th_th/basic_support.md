---
navigation:
  parent: index.md
  title: การรองรับพื้นฐาน
  icon: ae2:guide
  position: 10
---

# การรองรับพื้นฐาน

AE เก็บอากาศได้แล้ว  
Import Bus, Export Bus และ Storage Bus รู้จักภาชนะอากาศได้ทั้งหมด และ UI โต้ตอบกับถังอากาศได้  
นอกจากนี้ยังเพิ่ม **Air P2P** และ **Temperature P2P** ด้วย

<Row>
    <ItemImage id="ae2:import_bus" scale="4" />
    <ItemImage id="ae2:export_bus" scale="4" />
    <ItemImage id="ae2:storage_bus" scale="4" />
    <ItemImage id="air_p2p_tunel" scale="4" />
    <ItemImage id="heat_p2p_tunel" scale="4" />
</Row>

รายละเอียด
- <ItemLink id="ae2:export_bus" />: ส่งอากาศออกไปยังภาชนะอากาศที่เชื่อมอยู่ จำกัดความดันอัตโนมัติ จะไม่ทำให้เป้าหมายระเบิด
- <ItemLink id="ae2:import_bus" />: ดึงอากาศจากภาชนะอากาศที่เชื่อมอยู่ ลดได้ถึง 0 bar แต่ใช้แทน vacuum pump ไม่ได้
- <ItemLink id="ae2:storage_bus" />: ให้เครือข่าย ME รู้จักภาชนะอากาศที่เชื่อมอยู่ ภาชนะความดันลบจะถูกรับรู้เป็น 0 mL
- <ItemLink id="appliedpneumatics:air_p2p_tunel" />: รับอากาศขาเข้าและแบ่งให้ขาออก
- <ItemLink id="appliedpneumatics:heat_p2p_tunel" />: รับความร้อนขาเข้าและแบ่งให้ขาออก