---
navigation:
  parent: index.md
  title: ME Pressure Interface
  icon: appliedpneumatics:me_pressure_interface_block
  position: 40
item_ids:
  - appliedpneumatics:me_pressure_interface_block
---

# ME Pressure Interface

<Row>
  <BlockImage id="me_pressure_interface_block" scale="4" />
</Row>

ME Pressure Interface เป็นวิธีง่าย ๆ ในการจัดการอากาศ  
คุณเพียงตั้ง **ความดันเป้าหมาย** แล้ว Interface จะใส่หรือดึงอากาศจาก **เครือข่าย ME** เพื่อรักษาความดันให้ใกล้ค่าที่ต้องการมากที่สุด

ทางด้านนอก ส่งอากาศผ่าน **ท่อความดันของ PneumaticCraft** ได้ ตามหลักที่อากาศไหลจากความดันสูงไปต่ำตามธรรมชาติ  
มีช่องไอเทมให้ใส่ **ภาชนะอากาศ** เช่น ถังอากาศ Interface จะชาร์จอากาศเข้าหรือดูดอากาศออกจากภาชนะ ขึ้นกับระดับความดันที่สัมพันธ์กัน

## การ์ดอัปเกรดที่ใช้ได้
- **[Volume Card](upgrades.md)**: เพิ่มปริมาตรพื้นฐานของ Pressure Interface ที่ความดันเท่ากัน ปริมาตรที่ใหญ่กว่าหมายถึงเก็บอากาศได้มากกว่า
- **[Security Card](upgrades.md)**: เพิ่มการป้องกันอีกชั้น หากมีความดันถูกป้อนเข้ามากะทันหันมากเกินไป หรือเครือข่าย ME ใช้งานไม่ได้จน Interface เกินเกณฑ์อันตราย Security Card จะป้องกันการระเบิดและระบายอากาศส่วนเกินออก
- **[Vacuum Card](upgrades.md)**: ทำให้ตั้งความดันเป้าหมายเป็นค่าลบได้ ไม่เพียงแทนหน้าที่ของ vacuum pump แต่ยังให้ Interface ดึงอากาศจากโลกผ่านท่อเปิดได้ต่อเนื่อง อัตราจำกัด แต่แทบไม่สิ้นเปลืองทรัพยากร