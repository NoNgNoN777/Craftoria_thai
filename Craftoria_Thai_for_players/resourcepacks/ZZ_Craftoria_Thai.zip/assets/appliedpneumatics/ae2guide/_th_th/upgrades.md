---
navigation:
  parent: index.md
  title: การ์ดอัปเกรดใหม่
  icon: appliedpneumatics:security_card
  position: 80
item_ids:
  - volume_card
  - security_card
  - vacuum_card
  - charging_card
---

# การ์ดอัปเกรดใหม่

<Row>
  <ItemImage id="volume_card" scale="4" />
  <ItemImage id="security_card" scale="4" />
  <ItemImage id="vacuum_card" scale="4" />
  <ItemImage id="charging_card" scale="4" />
</Row>

## Volume Card
<RecipeFor id="volume_card" />  
ใช้ใน **ME Pressure Interface** และ **ME Temperature Interface** เพื่อเพิ่มปริมาตรพื้นฐานหรือความจุความร้อนพื้นฐาน  
- ปริมาตรสูงขึ้น เก็บอากาศได้มากขึ้นที่ความดันเท่าเดิม  
- ความจุความร้อนสูงขึ้น เก็บความร้อนได้มากขึ้นที่อุณหภูมิเท่าเดิม  

## Security Card
<RecipeFor id="security_card" />  
ใช้ใน **ME Pressure Interface** และ **Air Storage Cell**  
- ใน Pressure Interface ป้องกันการระเบิดจากความดันที่สูงเกินไป  
- ใน Air Storage Cell ป้องกันการเติมเกินจนทำให้ cell หลุดออกจาก drive หรือทำให้ drive ระเบิด  

## Vacuum Card
<RecipeFor id="vacuum_card" />  
ใช้ใน **ME Pressure Interface** และ **Air Storage Cell**  
- ใน Pressure Interface ทำให้ตั้งความดันเป้าหมายเป็นค่าลบได้ แทนหน้าที่ของ vacuum pump  
- ใน Air Storage Cell ทำลายอากาศส่วนเกินเมื่อเติมเกิน  

## Charging Card
<RecipeFor id="charging_card" />  
ใช้ใน **Portable Air Storage Cell** ให้ชาร์จไอเทมที่ใช้อากาศในช่องเก็บของของผู้เล่นโดยอัตโนมัติ