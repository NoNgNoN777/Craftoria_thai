---
navigation:
  parent: index.md
  title: ME Temperature Interface
  icon: appliedpneumatics:me_temperature_interface
  position: 50
item_ids:
  - appliedpneumatics:me_temperature_interface
---

# ME Temperature Interface

<Row>
  <BlockImage id="me_temperature_interface" scale="4" />
</Row>

ME Temperature Interface ปรับอุณหภูมิภายในให้ได้ค่าที่ต้องการ โดยใช้อากาศและพลังงานที่เก็บอยู่ใน **เครือข่าย ME**  
ทุก 1 J ของความร้อนที่เปลี่ยนไป จะใช้ **พลังงาน AE** ประมาณ **25** และ **อากาศ 19 mL**

## การ์ดอัปเกรดที่ใช้ได้
- **Acceleration Card**: เพิ่มการเปลี่ยนอุณหภูมิสูงสุดต่อ tick
- **Volume Card**: เพิ่มความจุความร้อนพื้นฐานของ Interface