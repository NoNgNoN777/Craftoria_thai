---
navigation:
  parent: index.md
  title: Amadron Wireless Terminal
  icon: appliedpneumatics:amadron_wireless_terminal
  position: 60
item_ids:
  - appliedpneumatics:amadron_wireless_terminal
---

# Amadron Wireless Terminal

อัปเกรดครั้งใหญ่ของ Amadron Tablet!  
ไม่ใช้อากาศอัดอีกต่อไป แต่ใช้พลังงานแทน ระหว่างช้อปปิ้ง คุณเข้าถึงทรัพยากรทั้งหมดในเครือข่าย ME ของคุณได้

<Row>
  <ItemImage id="amadron_wireless_terminal" scale="4" />
</Row>

หากจะใช้ Amadron Wireless Terminal คุณต้องเชื่อมกับ ME Wireless Access Point อย่างน้อย 1 ตัว และ Amadron Processing Station 1 ตัว  
ผูกได้โดย Shift + คลิกขวาที่ Amadron Processing Station

ภายในหน้าจอ terminal คุณช้อปปิ้งได้เหมือนกับ Amadron Tablet
- คลิกขวา เพื่อเพิ่มจำนวนที่ซื้อ
- Shift + คลิกขวา เพื่อเพิ่มเป็นสองเท่า
- คลิกซ้าย เพื่อลด และ Shift + คลิกซ้าย เพื่อลดครึ่งหนึ่ง

เมื่อเลือกไอเทมที่ต้องการแล้ว เพียงคลิกปุ่ม **Submit Order** ก็เสร็จสิ้นการช้อปปิ้ง

และหากเบื่อการช้อปปิ้งด้วยมือและคำนวณทรัพยากรเอง คุณบันทึกไอเทมที่มีจำหน่ายไม่จำกัดเหล่านั้นเป็น pattern นำไปวางใน Amadron Processing Station แล้วทำออโต้การแลกเปลี่ยนได้เลย