---
navigation:
  title: Applied Pneumatics
  position: 200
---

# Applied Pneumatics

<Row>
  <BlockImage id="me_amadron_process_station" scale="4" />
  <BlockImage id="me_pressure_interface_block" scale="4" />
  <BlockImage id="me_temperature_interface" scale="4" />
</Row>

ม็อดเสริมนี้เป็นสะพานเชื่อม **Applied Energistics 2 (AE2)** กับ **PneumaticCraft: Repressurized (PNC:R)**  
ช่วยให้คุณใช้เครือข่าย ME ควบคุม **อากาศอัด** **อุณหภูมิ** และระบบ **Amadron** ได้

## ภาพรวมฟีเจอร์

- **Air Storage Cells** (1k~256m) — เก็บอากาศอัดไว้ในเครือข่าย ME ได้โดยตรง
- **Portable Air Storage Cells** — ถังอากาศพกพาความจุสูง ความดันสูงสุด 20 bar
- **ME Pressure Interface** — รักษาความดันเป้าหมายโดยโต้ตอบกับเครือข่าย ME
- **ME Temperature Interface** — ใช้อากาศอัดและพลังงาน AE เพื่อรักษาอุณหภูมิเป้าหมาย
- **P2P Tunnels** — ส่งอุณหภูมิและอากาศอัดผ่านช่อง P2P ของ AE
- **Amadron Processing Station** — เชื่อมระบบ Amadron เข้ากับเครือข่าย autocrafting ของ AE
- **สูตรผสานระบบใหม่** — เพิ่มสูตรใหม่ รวมถึงการแลกเปลี่ยนของ Amadron และสูตรของ Assembly Chamber

## ดูเพิ่มเติม

- [การรองรับพื้นฐาน](basic_support.md)
- [Air Storage Cells](air_storage_cells.md)
- [P2P ชนิดใหม่](air_heat_p2p.md)
- [ME Pressure Interface](me_pressure_interface_block.md)
- [ME Temperature Interface](me_temperature_interface_block.md)
- [Amadron Wireless Terminal](amadron_wireless_terminal.md)
- [Amadron Processing Station](me_amadron_process_block.md)
- [การ์ดอัปเกรดใหม่](upgrades.md)
- [สูตรผสานระบบใหม่](new_recipe.md)