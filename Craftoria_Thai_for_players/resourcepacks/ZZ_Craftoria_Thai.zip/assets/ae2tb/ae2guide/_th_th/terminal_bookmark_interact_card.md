---
navigation:
  title: Terminal Bookmark Interact Card
  icon: terminal_bookmark_interact_card
  parent: index.md
  position: 001
categories:
  - ae2tb
item_ids:
  - terminal_bookmark_interact_card
---
# Terminal Bookmark Interact Card
<ItemImage id="ae2tb:terminal_bookmark_interact_card" scale={3}/>


<ItemLink id="ae2tb:terminal_bookmark_interact_card"/> ช่วยให้ terminal ของ AE2 โต้ตอบกับไอเทมที่บุ๊กมาร์กไว้ใน JEI, EMI และ REI ได้โดยตรง

เมื่อติดตั้งการ์ดแล้ว แผงบุ๊กมาร์กจะไม่ใช่แค่รายการอ้างอิงอีกต่อไป แต่กลายเป็นทางลัดเข้าสู่ ME network ของคุณ

## สูตรคราฟต์
<RecipesFor id="ae2tb:terminal_bookmark_interact_card" />


