---
navigation:
  title: "AE2 Tangible Bookmarks"
  position: 80
---

# AE2 Tangible Bookmarks

AE2 Tangible Bookmarks เชื่อมบุ๊กมาร์กจากม็อดรายการไอเทม (JEI/EMI/REI) เข้ากับ terminal ของ AE2

เมื่อใช้ terminal ของ AE2 คุณชี้ไปที่ไอเทมที่บุ๊กมาร์กหรือกดดาวไว้ใน JEI, EMI หรือ REI แล้วขอไอเทมนั้นจาก network ได้ทันที โดยไม่ต้องพิมพ์ค้นหาใน terminal ก่อน

## ไอเทม
- <ItemImage id="ae2tb:terminal_bookmark_interact_card"/>[Terminal Bookmark Interact Card](terminal_bookmark_interact_card.md)

## การตั้งค่า:

- ปุ่มลัดเริ่มต้นดูได้จากหน้าตั้งค่าปุ่มกดหรือแท็บตั้งค่า terminal ของม็อด
- ปุ่มลัดของ EMI ดูได้จากหน้าตั้งค่า (Configuration) ของ EMI
